[   0]Vider la corbeille
[   2]Effacer définitivement toutes les pages de la corbeille?
