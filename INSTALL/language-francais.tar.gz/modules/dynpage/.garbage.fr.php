[   0]La corbeille
[   1]Vider la corbeille
[  11]Récupérer la page
[   7]Name
[   6]Description
[   9]Lorsqu'une page web est effacée, elle est en fait stockée dans la corbeille.\n\nLes pages peuvent être récupérées de la corbeille.\n\nVider la corbeille efface définitivement les pages qui y sont stockées.
