[   0]Dupliquer une page
[   2]Nommer la page
[   4]Nom:
[   5]Description:
[   6]Le nom est requis.
[   7]Une page avec ce nom existe déjà.
[   3]Veuillez saisir le nom et éventuellement la description de la page web.\n\nLe nom est requis et doit être un simple mot en lettres minuscules.
