[   0]Télécharger une image
[   2]Sélectionner une image:
[   1]Les images sont normalement téléchargées à l'aide de l'éditeur html intégré.\n\nCela est le moyen le plus simple d'ajouter une image puisque l'image est automatiquement insérée dans la page web.\n\nMais les images peuvent aussi être téléchargées en dehors de l'éditeur html intégré.\n\nCela n'est pas le moyen recommandé pour ajouter une image dans une page web.\n\nMais cela permet le téléchargement d'images pour les navigateurs qui ne supportent pas l'éditeur html intégré.\n\nIl est aussi possible d'effacer les images téléchargées, mais non utilisées dans les pages web.
[   3]Pour utiliser cette image dans une page web, veuillez utiliser le lien suivant:
[   4]Vous pouvez sélectionner le lien et faire un copier/coller à l'aide d'un clic droit de la souris.
[   5]Effacer les images non utilisées
[   6]Redimensioner à la largeur:
[   7]Lors du téléchargement vers le serveur, une image peut être redimensionée à une certaine largeur.\n\nSi aucune largeur n'est spécifiée. alors l'image n'est pas redimensionée.\n\nLa largeur par défaut est prise de la plus grande largeur d'image dans les préférences.

