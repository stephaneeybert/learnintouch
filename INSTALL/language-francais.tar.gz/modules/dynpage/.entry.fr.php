[   0]Les pages d'entrée
[   1]Pour chaque langue, une page peut être spécifiée comme étant la page d'entrée du site web.\n\nLa page web sera affichée quand un visiteur arrive sur le site web.
[   2]Spécifier la page d'entrée pour la langue
[   3]Langue
[   4]Page web
[   5]La page d'entrée pour les ordinateurs
[   6]La page d'entrée pour les téléphones
