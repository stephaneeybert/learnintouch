[   0]Créer / Renomer une page
[   2]Nommer la page
[   4]Nom:
[   5]Description:
[   6]Le nom est requis.
[   7]Une page avec ce nom existe déjà.
[   8]Cacher la page:
[   9]Par défault une page est visible et est affichée dans le menu de navigation.\n\nMais elle peut être cachée. Dans ce cas, elle n'est pas affichée dans le menu de navigation.\n\nCette fonctionalité offre un moyen facile de cacher une page du site web.
[   3]Une page web doit avoir un nom. \n\nLe nom doit être un simple mot en lettres minuscules.
