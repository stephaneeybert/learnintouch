[   0]Les pages système sécurisées
[   1]Comme pour les pages web, l'accès aux pages système peut aussi être sécurisé.\n\nUne page système sécurisée ne sera plus accessible par les visiteurs.\n\nElle sera uniquement accessible par les utilisateurs qui se seront connecté au site web.
[   2]Spécifier la page d'entrée pour la langue
[   3]Page
[   4]Sécurisée
[   5]La page d'entrée pour les ordinateurs
[   6]La page d'entrée pour les téléphones
[   7]Activer l&#039;accès sécurisé à la page
[   8]Désactiver l&#039;accès sécurisé à la page répertoire
[   9]La page est sécurisée
