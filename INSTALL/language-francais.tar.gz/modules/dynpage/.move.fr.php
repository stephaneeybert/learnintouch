[   0]Déplacer une page web
[   1]Une page web peut être déplacée sous une autre page.\n\nPour déplacer une page web, veuillez sélectionner la page de destination.
[   2]Déplacer sous la page web
[   3]Déplacer sous la racine
[   7]Déplacer la page:
