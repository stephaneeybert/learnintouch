[   0]Effacer les images non utilisées
[   2]Effacer les images?
[   1]Les images non utilisées dans les pages web peuvent être effacées.\n\nIl est préférable de ne pas encombrer le serveur avec des images qui ne sont plus utilisées par le site web.
