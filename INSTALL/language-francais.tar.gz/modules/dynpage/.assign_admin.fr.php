[   0]Assigner un administrateur à un répertoire
[   1]Répertoire:
[   2]Administrateur:
[   3]Un répertoire peut appartenir à un administrateur.\n\nDans ce cas, seul l'administrateur peut acceder au contenu du répertoire.\n\nLes autres administrateurs ne voient pas le répertoire.
[  15]Sélectionner un administrateur
[  25]Parcourir...
