[   0]Effacer une page
[   1]Nom:
[   5]Description:
[   2]Effacer la page?
