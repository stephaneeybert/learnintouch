[   0]Les pages web
[   1]Créer une nouvelle page
[   2]Editer la page
[   3]Mettre la page à la corbeille
[   4]Image
[   5]Répertoires
[   6]La page est aussi un répertoire pour d'autres pages
[   7]Déplacer dans la page
[   8]Déplacer après la page
[   9]Une page web est composée de texte et d'images.\n\nUne page peut être spécifiée comme étant celle par défaut. Elle devient la page par défaut du répertoire.\n\nLa page par défaut du répertoire est utilisée dans la navigation miettes de pain et dans le menu de navigation.\n\nPour le répertoire racine '/', la page par défaut est aussi la page d'accueil du site web.
[  10]Déplacer avant la page
[  11]Renommer la page
[  12]Composer la page
[  13]Dupliquer la page
[  18]Afficher l'aperçu de la page
[  19]Afficher l'adresse web de la page
[  20]L'adresse web de la page est :
[  21]Pour créer un lien pointant vers cette page, copier et coller l'adresse ci-dessus dans la propriété du tag html.
[  22]Répertoire courant:
[  26]Déplacer la page dans un autre répertoire
[  27]Les préférences
[  28]Déplacer la page
[  29]Renommer le répertoire
[  30]Intervertir avec le suivant
[  31]Intervertir avec le précédent
[  32]Les pages web jetées à la corbeille
[  33]Télécharger une image ou une vidéo
[  34]Spécifier les pages d'entrée du site web
[  35]Voir l'arborescence des pages web
[  36]Activer l'accès sécurisé à la page
[  37]Désactiver l'accès sécurisé à la page
[  38]La page est sécurisée
[  39]L'accès sécurisé aux pages prédéfinies
[  40]Spécifier la page d'entrée
[  41]Assigner à un administrateur
[  43]Impriner la page
[  44]Aller à la page
[  70]Chercher:
[  71]Il peut devenir fastidieux d'avoir à naviguer dans les répertoires pour retrouver une page particulière.\n\nPour éviter cela, il est possible de saisir tout ou partie du nom d'une page et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera toutes les pages correspondant au texte recherché.
