[   0]Sécuriser un répertoire
[   1]Répertoire:
[   2]Activer l'accès sécurisé au répertoire?
[   5]Désactiver l'accès sécurisé au répertoire?
[   3]Activer l'accès sécurisé au répertoire
[   4]Désactiver l'accès sécurisé au répertoire
