[   0]Inscription utilisateur
[   1]Les champs avec une etoile * sont obligatoires.
[   2]Adresse email: *
[   3]Prénom: *
[   4]Nom: *
[   5]Mot de passe: *
[   6]Confirmez le mot de passe: *
[   7]Je souhaite recevoir vos emails
[   8]Vous allez recevoir un email contenant votre mot de passe.
[   9]Code de sécurité: *
[  10]Veuillez saisir le code de sécurité affiché.\n\nUn code de sécurité est requis pour s'assurer que l'enregistrement d'un utilisateur est fait par une personne et non pas par un programme.\n\nParce qu'un programme ne peut pas lire un nombre affiché sous forme graphique, seul une vrai personne peut s'inscrire en tant qu'utilisateur.
[  11]Veuillez saisir ce code de sécurité
[  12]Téléphone portable:
[  13]J'accepte les
[  14]termes du service
[  15]Enregistrer
[  16]Votre adresse email aura besoin d'ëtre confirmée. Après votre inscription, veuillez chercher dans votre boite de réception email notre email contenant le lien de confirmation.
