[   0]Changer un mot de passe
[   2]Nom de l'utilisateur:
[   3]Pour assigner un nouveau mot de passe à un utilisateur, tapez et confirmez un mot de passe.
[   4]Nouveau mot de passe:
[   5]Confirmez le mot de passe:
[   6]Veuillez saisir le mot de passe.
[   7]Veuillez saisir une deuxième fois le mot de passe, pour être sur de l'avoir saisi correctement.
[  20]Le mot de passe est requis.
[  21]Les deux mots de passe ne sont pas identiques.\n\nVous devez saisir des mots de passe identiques dans les deux champs.
[  10]Votre nouveau mot de passe a été mis à jour à
[  11]Pensez à utiliser un mémo pour vous aider à vous souvenir de votre mot de passe.\n\nVotre mot de passe est maintenant:
[  12]Salutations
[  43]Le mot de passe doit contenir seulement des caractères alphanumériques, comme:
