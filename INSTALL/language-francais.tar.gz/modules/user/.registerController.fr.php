[   0]Votre mot de passe de
[   1]Votre mot de passe est:
[   2]Vous devez accepter les termes du service.
[   3]Votre adresse email est:
[  33]Le code de sécurité est requis.
[  34]Le code de sécurité est incorrect.
[  37]L'adresse email est requise.
[  38]Le format de l'adresse email est invalide.
[  39]Le prénom est requis.
[  40]Le nom de famille est requis.
[  41]Le mot de passe est requis.
[  42]Les deux mots de passe doivent être identiques.
[  43]Le mot de passe doit contenir seulement des caractères alphanumériques, comme:
[  44]Le suffixe de l'adresse email est invalide.
[  46]Quelqu'un a déjà choisit cette adresse email.\n\nVeuillez choisir une autre adresse email.
[  50]L'utilisateur a été enregistré.
