[   0]Télécharger une image
[   6]Image:
[   3]Nom de l'image:
[   2]Sélectionner une image:
[   7]Effacer l'image?
[   8]Redimensioner à la largeur:
[   9]Lors du téléchargement vers le serveur, une image peut être redimensionée à une certaine largeur.\n\nSi aucune largeur n'est spécifiée. alors l'image n'est pas redimensionée.\n\nLa largeur par défaut est prise de la plus grande largeur d'image dans les préférences.

