[   0]Le profil de l'utilisateur
[   1]L'adresse de l'utilisateur
[   2]Adresse:
[   3]Adresse:
[   4]Code postal:
[   5]Ville:
[   6]Departement:
[   7]Pays:
[   8]Téléphone domicile:
[   9]Fax:
[  10]Téléphone bureau:
[  11]Prénom: *
[  12]Nom: *
[  13]Email: *
[  14]Inscription aux messages sms:
[  15]Profil:
[  16]Inscription aux mailings:
[  17]Téléphone portable:
[  18]Organisation:
[  19]Boite postale:
