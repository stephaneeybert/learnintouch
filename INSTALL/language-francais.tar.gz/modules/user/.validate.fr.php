[   0]Compte utilisateur
[   1]Nom de l'utilisateur:
[   2]Rendre le compte utilisateur permanent?
[   3]Invalider le compte utilisateur?
[   4]Le compte utilisateur est valide jusqu'au:
[   5]Le compte utilisateur n'est pas limité dans le temps.
[   6]Le compte utilisateur n'est plus valide depuis le:
