[   0]Rester connecté pour
[   1]semaine
[   2]cliquer ici
[   3]Connexion
[   4]Votre adresse email n'a pas encore été confirmée. Veuillez chercher dans votre boite de réception email notre email contenant le lien de confirmation.
[   4]semaines
[   5](cookies)
[   6]Cookies\n\nQue sont les cookies et pourquoi en ai-je besoin?\n\nUn cookie est un petit fichier contenant des informations sous forme de texte. Ces informations peuvent être des paramètres de connexion à un site web, des préférences de l'utilisateur ou tout autre type de renseignements.\n\nLorsque vous vous connectez à notre site web, vous pouvez nous demander de nous souvenir de vos paramètres de connexion. Ceci afin de vous éviter d'avoir à saisir vos paramètres à chacune de vos visites. Nous vous envoyons alors un cookie contenant ces paramètres. Le cookie est entreposé dans votre navigateur. \n\nPourquoi votre site web me demande toujours mes paramètres de connexion alors que j'ai autorisé les cookies sur mon navigateur?\n\nVeuillez vérifier que votre navigateur accepte bien les cookies. Voyez ci-dessous les instructions spécifiques pour changer les options de cookies dans votre navigateur. Si le problème persiste, alors cela peut être du à un éventuel programme pare-feu entre votre ordinateur et le Web.\n\nComment puis-je changer les options de mon navigateur pour qu'il accepte les cookies?\n\nLes instructions pour changer les options relatives aux cookies varient en fonction du navigateur que vous utilisez. Veuillez voir ci-dessous pour les détails spécifiques aux navigateurs les plus courants. Vous pouvez aussi vous renseigner sur les cookies en visitant les sites web de Microsoft ou de Netscape.\n\nComment j'autorise les cookies sur Internet Explorer?\n\nAvec Internet Explorer 5.0 et les versions précédentes, les cookies sont dans l'onglet Sécurité de l'option Options Internet du menu Outils.\n\nAvec Internet Explorer 6.0, les cookies sont dans l'onglet Privé de l'option Options Internet du menu Outils.\n\nAvec Netscape Navigator, les cookies sont dans l'option Préférences du menu Edit.\n\n\nBloquer les cookies\n\nVous pouvez bloquer les cookies pour tous les sites web. Vous pouvez aussi bloquer les cookies pour certains sites web seulement.\n\nNB: si vous bloquez les cookies de tous les sites web alors certaines fonctionalités de ces sites web pourront ne plus marcher. Si vous bloquez les cookies de session alors certaines pages et services de ces sites web ne marcheront plus.\n\n\nGénéralités sur les cookies\n\nSelon la loi sur l'information électronique, tous les sites web qui uitlisent les cookies doivent informer leurs visiteurs que :\n\n- Le site web contient des cookies \n- Quel usage ont ces cookies? \n- Comment éviter ces cookies?\n\nIl y a deux types de cookies:\n\n- Cookie: Conserve une information de façon permanente sur le disque dur, est conservé même après que l'ordinateur ait été éteint.\n- Cookie de Session: Conserve une information temporaire en mémoire vive (RAM), disparaît quand le navigateur web est fermé ou que l'ordinateur est éteint\n\n\nNotre site web et les cookies\n\nNotre site utilise les cookies de session pour assurer la conservation d'informations techniques entre les différentes pages web de notre site web, et pour conserver à travers les différentes pages visitées, vos différents choix.
[   7]Les cookies sont utilisés pour que le navigateur web fonctionne bien lors de votre visite sur les pages de notre site web. Le serveur utilise lui aussi des cookies pour sont fonctionnement interne. Aucune information personnelle ou sensible n'est contenue ou utilisée dans nos cookies.\n\nVotre navigateur web doit avoir l'option des cookies de session activée pour que les pages de notre site web fonctionnent correctement. La plupart des navigateurs web ont cette option activée (les cookies de sessions sont très courants). Si cette option n'est pas activée dans votre navigateur web, vous pouvez facilement l'activer vous même. Veuillez pour cela consulter les options ou l'aide de votre navigateur web.
[   8]a une adresse email pas encore confirmée.
[   9]L'adresse email est requise.
[  10]Votre compte utilisateur a expiré depuis le
[  11]Vous pouvez aussi
[  12]Le mot de passe est requis.
[  13]Le nom de connexion ou le mot de passe de l'utilisateur est incorrect.
[  14]pour nous contacter.
[  15]L'adresse email que vous avez utilisé lors de l'inscription, était:
[  16]L'utilisateur avec l'adresse email
[  17]n'est plus valide.
[  20]Auto connexion:
[  21]Cochez cette case pour être reconnu(e) par le système et éviter la procédure de connexion lors de votre prochaine visite.\n\nVous serez alors automatiquement connecté(e) lors de votre prochaine visite.\n\nSi vous utilisez un ordinateur partagé, comme dans un café Internet ou dans une bibliothèque, alors veuillez ne pas cocher cette case.\n\nCela parce que cette option fait usage des cookies.\n\nEtant donné que vos paramètres de connexion seront stockés sur l'ordinateur, dans un fichier texte cookie, activer cette option peut représenter un risque pour la confidentialité de ces paramètres.
[  22]Connexion Utilisateur
[  23]Tapez votre adresse email et votre mot de passe.
[  24]Adresse email:
[  25]Mot de passe:
[  26]Si vous avez oublié votre mot de passe
[  27]cliquez ici
[  28]Pour vous inscrire
