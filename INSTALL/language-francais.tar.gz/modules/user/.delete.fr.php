[   0]Effacer un utilisateur
[   1]Effacer l'utilisateur?
[   3]Nom de l'utilisateur:
[   2]Cet utilisateur est un enseignant. Veuillez effacer l'enseignant avant d'effacer l'utilisateur.
[   4]Effacer l'utilisateur effacera toutes ses inscriptions aux cours et tous ses résultats d'exercices.
[   5]L'utilisateur est inscrit à
[   6]cours.
[   7]L'utilisateur a
[   8]commandes d'achats.
[   9]Effacer l'utilisateur effacera toutes ses commandes d'achats.
