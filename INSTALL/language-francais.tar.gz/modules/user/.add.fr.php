[   0]Enregistrement d'un utilisateur
[   1]Les champs avec une etoile <B>*</B> sont obligatoires.
[   2]Adresse email: *
[   3]Prénom: *
[   4]Nom: *
[   5]Mot de passe: *
[   6]Confirmez le mot de passe: *
[  11]Téléphone portable:
[   9]Code de sécurité: *
[  10]Veuillez saisir le code de sécurité affiché.\n\nUn code de sécurité est requis pour s'assurer que l'enregistrement d'un utilisateur est fait par une personne et non pas par un programme.\n\nParce qu'un programme ne peut pas lire un nombre affiché sous forme graphique, seul une vrai personne peut s'enregistrer en tant qu'utilisateur.
