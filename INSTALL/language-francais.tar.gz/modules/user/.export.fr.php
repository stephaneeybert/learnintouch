[   0]Exporter les utilisateurs
[   1]Exporter tous les utilisateurs dans un fichier texte?
