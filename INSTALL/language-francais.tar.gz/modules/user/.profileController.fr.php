[   0]L'adresse email est requise.
[   1]L'adresse email est invalide.
[   2]Un utilisateur avec cette adresse email existe déjà.\n\nVeuillez choisir une autre adresse email.
[   3]Le numéro de téléphone portable doit être spécifié pour envoyer des messages sms à l'utilisateur.
[  20]Le prénom est requis.
[  21]Le nom est requis.
[  34]Le numéro de téléphone portable ne peut contenir que des chiffres.
[  35]Le numéro de fax ne peut contenir que des chiffres.
[  36]Le numéro de téléphone ne peut contenir que des chiffres.
