[   0]Votre mot de passe de
[   1]Votre nouveau mot de passe est:
[   2]Continuer
[   5]Un email contenant un nouveau mot de passe a été envoyé à:
[   3]Votre adresse email est:
[   9]Mot de passe
[  10]Veuillez saisir votre adresse email...
[  11]Adresse email:
[  12]L'adresse email est requise.
[  13]Le format de l'adresse email est invalide.
[  14]Votre adresse email est inconnu.
