[   0]Profil utilisateur
[   1]Mailings:
[   2]Télécharger une nouvelle photo
[   3]Profil:
[   4]Photo:
[   5]Email:
[   7]Téléphone portable:
[   8]Téléphone domicile:
[   9]Fax:
[  10]Téléphone bureau:
[  11]Organisation:
[  12]Boite postale:
[  13]Adresse:
[  14]Adresse:
[  15]Code postal:
[  16]Ville:
[  17]Département:
[  18]Pays:
[  19]Sms:
[  20](Cochez pour recevoir nos messages sms)
[  21]Sauvegarder
[  22]Changer le mot de passe
[  23]Les champs avec une etoile * sont obligatoires.
[  24](Cochez pour recevoir nos mailings)
[  25]Prénom: *
[  26]Nom: *
[  30]L'adresse est requise.
[  31]Le code postal est requis.
[  32]Le code postal ne peut contenir que des chiffres.
[  33]La ville est requise.
[  34]Le pays est requis.
