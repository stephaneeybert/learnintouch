[   0]Effacer les utilisateurs du dernier import
[   2]Nombre d'utilisateurs du dernier import:
[   1]Effacer les utilisateurs du dernier import?
[   3]Liste des utilisateurs du dernier import
[   4]Il n'y a pas eu d'import.
