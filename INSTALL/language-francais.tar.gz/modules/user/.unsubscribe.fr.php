[   0]Désinscription des mailings
[   1]Votre inscription aux mailings a été désactivée.\n\nVous ne recevrez plus de mailings de notre part tant que vous ne ré-activerez pas votre inscription.\n\nVous pouvez néanmoins à tout moment ré-activer votre inscription.
