[   0]Les pages de redirection de connexion
[   1]Pour chaque langue, une page peut être spécifiée comme étant la page de post connexion utilisateur du site web.\n\nLa page web sera affichée après qu'un visiteur se connecte au site web avec son nom de connexion et son mot de passe.\n\nVeuillez noter qu'il peut être conseillé de ne pas rediriger l'utilisateur vers une page spécifique.\n\nDans ce cas l'utilisateur sera redirigé vers la page qu'il a originellement requis.
[   2]Spécifier la page de post connexion pour la langue
[   3]Langue
[   4]Page web
[   5]La page de post connexion pour les ordinateurs
[   6]La page de post connexion pour les téléphones
[   7]Les pages de connexion expirée
[   8]Pour chaque langue, une page peut être spécifiée comme étant la page de connexion utilisateur expirée du site web.\n\nLa page web sera affichée si la connexion d'un utilisateur a expirée.\n\nLa connexion expire si elle a une date limite de validité, et que cette data a passée.
[   9]Spécifier la page de connexion expirée pour la langue
[  10]Les pages de post connexion
[  11]La page de connexion expirée pour les ordinateurs
[  12]La page de connexion expirée pour les téléphones
