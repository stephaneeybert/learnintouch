[   0]Importer une liste d'utilisateurs
[   1]La liste des utilisateurs à importer doit être stockée dans un fichier texte dont les données sont séparées par un caractère séparateur.\n\nPour créer le fichier avec MS Excel n'utilisez pas le format de fichier Excel '.xls'. A la place, veuillez utiliser le format de fichier '.csv'.\n\nLe caractère séparateur peut être une virgule ',' ou un point-virgule ';' ou un slash '/'.\n\nLe caractère séparateur doit être identique dans toutes les lignes du ficher.\n\nIl ne peut y avoir deux lignes utilisant deux caractères séparateurs différents.\n\nChaque ligne du fichier doit avoir le format suivant:\n\nemail, prénom, nom\n\nUne ligne peut aussi avoir une organisation pour un utilisateur.\n\nDans ce cas la ligne doit avoir le format suivant:\n\nemail, prénom, nom, organisation\n\nUne ligne peut aussi avoir un pays pour un utilisateur.\n\nDans ce cas la ligne doit avoir le format suivant:\n\nemail, prénom, nom, organisation, pays
[   2]Adresse email: *
[   3]Liste des adresses email invalides
[   4]Le fichier texte contenant la liste des utilisateurs à importer, a un format invalide.\n\nLe caractère séparateur est manquant ou est incorrect.\n\nLe caractère séparateur peut être une virgule ',' ou un point-virgule ';' ou un slash '/'.
[   5]Fichier:
[   6]à
[   7]Les utilisateurs importés le
[   8]Ces utilisateurs n'ont pas été importé dans le site web parce que leurs adresses email étaient invalides.
[   9]Liste des adresses email déjà existantes
[  10]Ces utilisateurs n'ont pas été importé dans le site web parce qu'il y a déjà des utilisateurs avec ces adresses email.
[  11]Total:
[  27]Aucun fichier n'a été spécifié.
