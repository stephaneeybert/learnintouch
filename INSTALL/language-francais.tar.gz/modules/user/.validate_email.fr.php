[   0]Validation de l'adresse email
[   1]Votre adresse email est maintenant validée.
[   2]L'utilisateur n'a pas pu être trouvé.
[   3]L'email de validation a expiré.
[   4]Vous pouvez
[   5]pour vous connecter.
[   6]cliquer ici
[   7]pour nous contacter.
[   8]L'utilisateur avec l'id
[   9]n'a pas pu être trouvé lors de la confirmation de son adresse email.
[  10]avait un lien invalide lors de la confirmation de son adresse email.
