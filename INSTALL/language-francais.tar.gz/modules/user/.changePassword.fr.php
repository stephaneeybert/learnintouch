[   0]Changer votre mot de passe
[   1]Adresse email: *
[   2]Mot de passe actuel: *
[   3]Ensuite veuillez saisir et confirmez votre nouveau mot de passe.
[   4]Nouveau mot de passe: *
[   5]Confirmez le mot de passe: *
[   6]Changer le mot de passe
[   9]Votre mot de passe a été mis à jour!
[  20]Le nouveau mot de passe est requis.
[  21]Les deux mots de passe ne sont pas identiques.\n\nVous devez saisir des mots de passe identiques dans les deux champs.
[  25]L'adresse email est requise.
[  27]Le mot de passe actuel est requis.
[  28]Votre adresse email ou votre mot de passe actuel est incorrect.
[  99]Veuillez saisir votre adresse email et votre mot de passe actuel.
