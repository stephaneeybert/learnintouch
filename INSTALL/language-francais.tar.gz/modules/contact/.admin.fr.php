[   0]Les messages
[   1]Email
[   2]Voir le message
[   3]Mettre le message à la corbeille
[   4]Sujet
[   5]Téléphone/Portable
[   6]Les statuts
[   7]Les préférences
[   8]Date/Heure
[   9]Statut:
[  10]Les messages de contact sont les messages reçus par les utilisateurs de votre site web.\n\nCes messages sont souvent des messages de premier contact.\n\nIl est préférable que vos utilisateurs vous contactent à l'aide de ce formulaire, que de publier votre adresse email sur le site web.\n\nPublier une adresse email sur un site web l'expose au spam.\n\nIl est donc conseillé de ne pas publier votre adresse email sur votre site web.\n\nDe plus, ce système de messages vous permet de traiter les messages reçus en les marquant à l'aide de statuts de traitements.
[  11]Effacer tous les messages
[  12]Nom
[  13]Envoyer un email
[  14]Lire le message
[  15]Le formulaire d'exemple à télécharger
[  16]Les références
[  32]Les messages web jetés à la corbeille
