[   0]Effacer les messages
[   1]Statut:
[   2]Effacer tous ces messages?
[   3]Email
[   4]Sujet
[   5]Les messages de contact peuvent être effacés un par un mais cela peut vite devenir astreignant.\n\nUn moyen plus rapide d'effacer plusieurs messages est de sélectionner tous les messages d'un statut particulier, et de les effacer tous.
[   6]Veuillez choisir un statut avant d'effacer tous les messages d'un statut.
[   8]Date/Heure
[  12]Nom
