[   0]Effacer un statut
[   2]Effacer le statut?
[   3]Nom:
[   4]Description:
