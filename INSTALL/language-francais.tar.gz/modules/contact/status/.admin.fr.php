[   0]Les statuts
[   1]Ajouter un statut
[   2]Modifier le statut
[   3]Effacer le statut
[   4]Nom
[  10]Intervertir avec le suivant
[  11]Intervertir avec le précédent
[   9]Les statuts sont utilisés pour gérer les messages de contact.\n\nIls aident en marquant les étapes dans le traitement des messages.\n\nLes statuts peuvent, par exemple, trier les messages arrivant de ceux qui ont déjà été traité, ou de ceux qui sont maintenant archivés, ou de ceux qui devraient être effacés.\n\nLes statuts peuvent être ordonnés en utilisant les flêches haut et bas.\n\nCréez quelques statuts et utilisez les pour trier vos messages.
