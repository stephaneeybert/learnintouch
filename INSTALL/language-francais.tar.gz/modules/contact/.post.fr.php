[   0]Message de Contact
[   1]Prénom:
[   2]Nom:
[   3]Email:
[   4]Organisation:
[   5]Téléphone:
[   6]Sujet:
[   7]Message:
[   8]Veuillez écrire votre adresse email et votre message.\nLes champs obligatoires sont marqués d'une étoile *
[   9]Référence:
[  10]L'adresse email est requise.
[  11]Le format de l'adresse email est invalide.
[  12]Le message est requis.
[  13]Comment vous nous avez connu?
[  14]Envoyer
[  18]Le suffixe de l'adresse email est invalide.
[  15]Nous avons bien reçu votre message.\n\nNotre service clientèle vous contactera sous peu.
[  23]Code de sécurité: *
[  24]Veuillez saisir le code de sécurité affiché.\n\nUn code de sécurité est requis pour s'assurer que l'écriture d'un message de contact est faite par une personne et non pas par un programme.\n\nParce qu'un programme ne peut pas lire un nombre affiché sous forme graphique, seul une vrai personne peut ecrire un message de contact.
[  22]Veuillez saisir ce code de sécurité
[  33]Le code de sécurité est requis.
[  34]Le code de sécurité est incorrect.
