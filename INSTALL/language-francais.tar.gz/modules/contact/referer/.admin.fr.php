[   0]Les références
[   1]Ajouter une référence
[   2]Modifier la référence
[   3]Effacer la référence
[   4]Description
[  10]Intervertir avec la suivante
[  11]Intervertir avec la précédente
[   9]Les références sont utilisées pour offrir dans le formulaire de contact, une liste d'options dans laquelle le visiteur peut choisir comment il a connu le site web.\n\nIl peut être intéréssant de savoir comment les visiteurs ont connu le site web, que cela soit une publicité, un moteur de recherche, un portail web, le bouche à oreille, etc...
