[   0]Le formulaire a été reçu.\n\nMerci pour votre participation!
[   1]Un nouveau formulaire a été envoyé à
[   2]Un visiteur du site web a rempli et envoyé un formulaire à
[   3]Le contenu du formulaire est le suivant:
[   4]Sincères Salutations
