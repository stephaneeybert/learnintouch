[   0]Vider la corbeille
[   2]Effacer définitivement tous les messages de la corbeille?
