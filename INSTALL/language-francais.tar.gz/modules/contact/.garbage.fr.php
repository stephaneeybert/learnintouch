[   0]La corbeille
[   1]Vider la corbeille
[  11]Récupérer le message
[   7]Name
[   6]Description
[   9]Lorsqu'un message est effacé, il est en fait stocké dans la corbeille.\n\nLes messages peuvent être récupérés de la corbeille.\n\nVider la corbeille efface définitivement les messages qui y sont stockés.
