[   0]Effacer un message
[   2]Effacer le message?
[   3]Sujet:
[   4]De:
