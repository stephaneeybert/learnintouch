[   0]Lire un message
[   1]Nom:
[   2]Sujet:
[   3]Message:
[   4]Organisation:
[   5]Téléphone:
[   6]Email:
[   7]Mettre le message à la corbeille
[   8]Référent:
[   9]Vous pouvez mettre à jour le statut du message après avoir lu le message.
[  10]Statut:
