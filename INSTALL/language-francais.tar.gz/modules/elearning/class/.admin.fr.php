[   0]Les classes
[   1]Créer une classe
[   2]Modifier la classe
[   3]Effacer la classe
[   4]Donner un cours aux participants de la classe
[   5]Nom
[   6]Description
[   7]Envoyer un mail à la classe
[   8]Fixer le prochain exercice pour un cours de la classe
[   9]Enseignant:
[  10]Une classe est un groupe de gens participant à un ou plusieurs cours durant une session.\n\nA chaque nouvelle session, la classe a de nouveaux participants.
[  11]Ajouter un participant à la classe
[  12]Les participants de la classe
[  70]Chercher:
[  71]Il peut devenir fastidieux d'avoir à naviguer dans la liste des classes pour retrouver une classe particulière.\n\nPour éviter cela, il est possible de saisir tout ou partie du nom d'une classe et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera toutes les classes correspondant au texte recherché.
