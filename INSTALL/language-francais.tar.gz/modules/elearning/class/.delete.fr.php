[   0]Effacer une classe
[   1]Nom:
[   5]Description:
[   2]Effacer la classe?
[   3]Il y a des inscriptions de participants pour cette classe.\nLes inscriptions de participants ne seront pas effacées.\nCependant, elles ne feront plus partie de la classe.
