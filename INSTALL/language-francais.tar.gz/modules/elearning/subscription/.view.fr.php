[   0]Un cours d'un participant
[   1]Participant:
[   2]Clôturée le:
[   3]Inscrit le:
[   4]Voir la leçon
[   5]Cours:
[   6]Résultats en direct
[   7]Session:
[   8]Le participant ne peut pas encore accéder à cet exercice
[   9]Modifier l'exercice
[  18]Afficher le logo du site web:
[  11]Composer l'exercice
[  12]Il est possible de suivre la progression de l'exercice pendant que le participant répond aux questions.\n\nDans ce cas, les résultats des questions seront affichés au professeur pendant que le participant fait l'exercice.\n\nLe professeur pourra voir une progression graphique de chaque exercice.\n\nLes résultats en direct sont affichés seulement quand le participant est en ligne et en train de faire l'exercice.\n\nSi le participant est inactif alors un voyant se met à clignoter.\n\nSi le participant est absent alors rien n'est affiché.
[  13]Fait
[  14]Indique si et quand le participant a fait le devoir.
[  15]Note
[  16]La note est une lettre ou un texte qui représente la performance du participant.
[  17]Points
[  18]Les points est le total de points pour les réponses correctes données par le participant.\n\nPar défaut, une réponse vaut un point, mais elle peut valoir plusieurs points.
[  19]Réponses
[  20]Le nombre de réponses correctes et le nombre de réponses incorrectes.
[  21]Résultats
[  22]Les résultats sont le nombre de réponses correctes par le nombre de questions.
[  23]Note moyenne du participant
[  24]Suivre et aider le participant
[  25]La note moyenne est la moyenne de toutes les notes des exercices.
[  26]Le tableau partagé
[  71]du
[  72]jusqu'au
[  90]Envoyer les résultats de l'exercice
[  91]Voir l'exercice
[  94]Afficher les résultats de l'exercise
[ 145]Aucune inscription n'a été trouvée.
[ 186]Le graphe des résultats
