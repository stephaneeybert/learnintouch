[   0]Envoyer un mailing
[   1]Session:
[   2]Envoyer le mailing?
[   3]Participant:
[   4]Le corps du message...
[   5]Veuillez vous assurer que des destinataires sont spécifiés.\nLe mailing n'a pas pu être envoyé.
[   6]Classe:
[   7]Le sujet ou le contenu du mailing est vide.\nLe mailing n'a pas pu être envoyé.
[   8]Session:
[   9]Veuillez noter que les utilisateurs qui ont demandé dans leur profil à ne pas recevoir d'emails n'en recevront pas.
[  10]Destinataire:
[  18]Les fichiers attachés...
[  20]Mailing:
[  21]Il est possible de choisir un mailing à envoyer.
[  22]Un mailing est actuellement en train d'être envoyé.\n\nVeuillez attendre qu'il se termine avant d'en envoyer un autre!!
[  25]Le dernier envoi a échoué sur certaines adresses email.\n\nIl vous est possible de ré-envoyer le mailing à la liste des adresses email pour lesquelles l'envoi de l'email a échoué.
