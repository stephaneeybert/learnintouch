[   0]Désinscription
[   1]Désinscription d'un cours
[   2]Il est possible de se désinscrire d'un cours.\n\nDans ce cas, tous les résultats des exercices du cours seront définitivement effacés.
[   3]Désinscrire
[   4]L'inscription est requise.
[   5]Le cours de l'inscription ne permet pas la désinscription.
[   6]Veuillez cocher la case pour confirmer la désinscription.
