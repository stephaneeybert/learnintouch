[   0]Le participant n'a pas encore commencé l'exercice.
