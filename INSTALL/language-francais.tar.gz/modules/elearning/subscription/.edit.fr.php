[   0]Modifier une inscription
[   1]La session est requise.
[   2]Session:
[   3]Classe:
[   4]Utilisateur: *
[   5]Description:
[   6]Au moins un utilisateur est requis.
[   7]Lorsqu'un participant est inscrit à un cours, il peut être suivit par un enseignant.\n\nSi un enseignant est spécifié alors il pourra suivre les résultats de son participant.\n\nL'enseignant pourra être alerté par email lorsque son participant aura fait un exercice.\n\nIl est alors possible de voir tous les cours et participants d'un enseignant.
[   8]Choisir une date dans le calendrier
[   9]Un cours avec ce nom existe déjà.
[  10]Le nombre maximum d'inscriptions a été atteint.\n\nVous ne pouvez pas ajouter plus d'inscriptions.
[  11]Enseignant:
[  12]Lorsqu'un participant est inscrit à un cours, il peut être assigné à une classe.\n\nDans ce cas, il sera possible de contacter le participant par sa classe.\n\nLe participant recevra les messages envoyés à sa classe.
[  13]Une date doit avoir le format
[  14]Une session est une période de temps.\n\nLes cours peuvent être triés par sessions.\n\nDans ce cas, choisir une session n'offrira que les cours de la session.
[  15]Un participant est un utilisateur enregistré dans le site web.\n\nAvant de s'inscrire à un cours, un participant doit être enregistré comme utilisateur dans le site web.\n\nPour enregistrer un nouvel utilisateur dans le site web, aller à 'Les utilisateurs'.
[  16]Ajouter les utilisateurs créés du:
[  17]Il est possible de créer des inscriptions en gros, pour tous les utilisateurs qui ont été créé durant une certaine période, par exemple, suite à un import d'utilisateurs.
[  18]Le cours est requis.
[  19]Cours:
[  20]La classe est requise.
[  21]L'enseignant est requis.
[  22]au:
[  23]La date de début doit être antérieure à la date de fin.
[  24]Date d'ouverture de l'inscription:
[  25]Un cours est une série de leçons et / ou d'exercices.
[  26]Date de clôture de l'inscription:
[  27]Suivre en direct:
[  28]Les exercices d'un cours peuvent peuvent être suivis en direct par un professeur.\n\nIl est alors possible pour le professeur, de suivre sur son ordinateur, la progression de l'exercice pendant que le participant répond aux questions.\n\nLes résultats des questions seront affichés en direct au professeur pendant que le participant fait l'exercice.
