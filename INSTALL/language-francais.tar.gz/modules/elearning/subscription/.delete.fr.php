[   0]Effacer une inscription
[   1]Elève:
[   2]Effacer l'inscription?
[   3]Note: Cela va aussi effacer tous les résultats d'exercices pour cette inscription!
