[   0]Inscription
[   1]Enseignant:
[   2]Classe:
[   3]Session:
[   4]Cours:
[   5]Inscription
[   6]La session est requise.
[   7]Le cours est requis.
[   8]La classe est requise.
[   9]L'enseignant est requis.
[  10]Le nombre maximum d'inscriptions a été atteint.\n\nVeuillez contacter l'école pour créer votre inscription.
[  11]Suivre en direct:
[  12]Les exercices d'un cours peuvent être suivis en direct par un professeur.\n\nIl est alors possible pour le professeur, de suivre sur son ordinateur, la progression de l'exercice pendant que le participant répond aux questions.\n\nLes résultats des questions seront affichés en direct au professeur pendant que le participant fait l'exercice.
[  13]Vous êtes déjà inscrit à ce cours.
[  14]Vous êtes déjà inscrit à ce cours pour cette session.
[  15]Le participant est requis.
