[   0]Donner un cours
[   1]Classe:
[   2]Cours:
[   3]Seuls les participants sélectionnés recevront le course.
[   4]Le cours est requis.
[   6]Aux participants:
[   7]Sélectionner tout
[  10]Il est possible de donner un cours à un ou plusieurs participants.\n\nTous les participants seront alors capables de faire le cours.\n\nPar exemple, il est possible de donner un cours à tous les participants d'une classe.
[  15]Dé-sélectionner tout
