[   0]Les niveaux
[   1]Créer un niveau
[   2]Modifier le niveau
[   3]Effacer le niveau
[   5]Nom
[   6]Description
