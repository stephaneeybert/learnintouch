[   0]Effacer un niveau
[   1]Nom:
[   5]Description:
[   2]Effacer le niveau?
