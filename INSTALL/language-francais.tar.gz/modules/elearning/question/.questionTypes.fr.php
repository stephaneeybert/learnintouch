[   0]Choisir une réponse dans une liste descendante
[   1]... dans une liste de boutons radio [liste horizontale]
[   2]... dans une liste de cases à cocher [TOUTES les réponses correctes sont REQUISES]
[   3]Saisir une réponse dans une question
[   4]... dans une liste de cases à cocher [PLUSIEURS réponses sont ACCEPTÉES]
[   5]... dans une liste de boutons radio [liste verticale]
[   6]Déplacer une réponse... dans sa question
[   7]... dans n'importe quelle question
[   8]... pour ordonner les mots d'une phrase
[   9]... dans un texte à trous
[  10]Saisir une réponse dans un texte à trous
[  11]Choisir une réponse dans un texte à trous
[  12]... sous n'importe quelle question [PLUSIEURS réponses sont ACCEPTÉES]
[  13]Ecrire un texte
