[   0]Après le champ de la réponse
[   1]Dans le champ de la réponse
[   2]A la fin de la question
[   3]Dans une bulle d'aide
[   4]Devant le champ de la réponse
