[   0]Effacer une question
[   1]Question:
[   2]Effacer la question?
[   3]Cette question a déjà été utilisée et a des résultats.\n\nEffacer la question va aussi effacer les résultats détaillés de la question.\n\nMais les résultats des autres questions ne seront pas effacés et les notes et les points de l'exercice seront conservés.
