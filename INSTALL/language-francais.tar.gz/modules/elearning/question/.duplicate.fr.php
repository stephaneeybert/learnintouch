[   0]Dupliquer une question
[   1]Question:
[   5]Points:
[   7]Dupliquer la question?
