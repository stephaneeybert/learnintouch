[   0]Modifier une catégorie
[   4]Nom:
[   5]Description:
[   6]Le nom est requis.
