[   0]Les catégories
[   1]Créer une catégorie
[   2]Modifier la catégorie
[   3]Effacer la catégorie
[   5]Nom
[   6]Description
