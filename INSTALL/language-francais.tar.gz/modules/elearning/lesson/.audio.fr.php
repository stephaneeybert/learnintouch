[   0]Télécharger un fichier audio
[   1]Une leçon peut avoir un fichier audio.\n\nLe fichier audio peut être joué par l'utilisateur.
[   2]Ko.
[   3]Nom du fichier:
[   5]Sélectionner un fichier:
[   6]Fichier audio:
[   7]Effacer le fichier audio?
[  27]Aucun fichier audio n'a été spécifié.
