[   0]Effacer un paragraph
[   1]Paragraph:
[   2]Effacer le paragraph ?
