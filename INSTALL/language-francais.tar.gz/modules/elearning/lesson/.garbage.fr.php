[   0]La corbeille
[   1]Vider la corbeille
[  11]Récupérer la leçon
[   7]Name
[   6]Description
[   9]Lorsqu'une leçon est effacée, elle est en fait stockée dans la corbeille.\n\nLes leçons peuvent être récupérées de la corbeille.\n\nVider la corbeille efface définitivement les leçons qui y sont stockées.
