[   0]Vider la corbeille
[   2]Effacer définitivement toutes les leçons de la corbeille?
