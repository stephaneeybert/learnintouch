[   0]Rechercher une leçon
[   3]Aller à la leçon
[   5]Le cours
[   6]pour la session de
[  10]Imprimer les résultats
[  12]Regarder la video
[  13]Cliquer pour regarder la video
[  14]Exercice:
[  80]Envoyer la leçon
[  91]Faire la leçon
[ 112]Imprimer la leçon
[ 135]Résultats
[ 136]Points
[ 145]Aucune inscription n'a été trouvée.
[ 186]Imprimer le graphe des résultats du cours
