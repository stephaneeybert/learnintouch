[   0]Composer une leçon
[   1]Intervertir avec le paragraphe suivant
[   2]Paragraphe
[   3]Exercice
[   4]Leçon:
[   5]Titre
[   6]Modèle:
[   7]Choisir une rubrique pour le paragraphe...
[   8]Effacer le paragraphe de leçon
[   9]Intervertir avec le paragraphe précédent
[  10]Rubrique
[  11]Imprimer la leçon
[  12]Composer le modèle de leçon
[  13]Ajouter un paragraphe de leçon
[  14]Modifier les instructions de la leçon
[  15]Etes vous sur de vouloir EFFACER ce paragraphe de leçon ?
[  16]Ajouter un paragraphe à la rubrique
[  17]Ajouter un paragraphe
[  18]Modifier la leçon
[  19]Modifier l'instroduction de la leçon
[  20]Modifier le paragraphe
[  21]Modifier le texte du paragraphe
[  29]Une leçon est composée d'une introduction et d'une série de paragraphes.\n\nUn paragraphe de leçon peut être composé d'un titre, d'un en-tête, d'un corps, et d'un pied de paragraphe et d'un lien vers un exercice.\n\nLors d'une leçon, par défaut, tous les paragraphes sont affichés sur une page.
[  34]Voir la leçon
[  41]Télécharger ou effacer une image ou un fichier Flash
[  42]Télécharger ou effacer un fichier audio ou Flash
