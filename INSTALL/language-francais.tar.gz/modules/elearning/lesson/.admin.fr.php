[   0]Les leçons
[   1]Créer une leçon
[   2]Modifier la leçon
[   3]Mettre la leçon à la corbeille
[   4]Nom
[   5]Modifier l'exercice
[   6]Les modèles de leçons
[   7]Insérer ou effacer une image ou un fichier multimédia
[   8]Ajouter la leçon à un cours
[   9]Catégorie:
[  10]Intervertir avec le suivant
[  11]Intervertir avec le précédent
[  12]Composer l'exercice
[  13]Niveau:
[  14]Les niveaux
[  15]Enlever du cours
[  16]Un exercice
[  17]Description
[  18]Exercices
[  19]Enseignant:
[  20]Une leçon peut avoir un exercice dans chacun de ses paragraphes
[  21]Une leçon
[  22]Les cours
[  23]Les catégories
[  24]Vérouiller la leçon
[  25]Dévérouiller la leçon
[  26]Voir la leçon
[  27]Voir l'exercice
[  28]Envoyer par email
[  29]Le système de gestion des cours offre des leçons.\n\nUne leçon peut être composée d'une introduction, d'une image ou d'une animation Flash, d'un fichier audio et d'une série de paragraphes.\n\nUne leçon peut aussi être incluses dans un cours.
[  31]Effacer le dernier cours importé
[  32]Dupliquer la leçon
[  33]Cours:
[  34]Les leçons jetées à la corbeille
[  35]Afficher l'adresse web de la leçon
[  36]L'adresse web de la leçon est :
[  37]Pour créer un lien pointant vers cet leçon, copier et coller l'adresse ci-dessus dans l'attribut href d'un lien.
[  38]Donner un devoir
[  39]Les sujets
[  40]Imprimer la leçon
[  41]Imprimer l'exercice
[  42]Composer la leçon
[  43]Une semaine
[  44]Un mois
[  45]Trois mois
[  46]Six mois
[  47]Un an
[  48]Créé depuis:
[  50]Public
[  51]Protégé
[  52]Les exercices
[  53]Importer un cours, une leçon ou un exercice
[  55]Sujet:
[  56]Pas encore publié
[  57]Précédant
[  58]Suivant
[  59]Sélectionner les leçons d'un certain niveau.
[  60]Statut:
[  61]Sélectionner les leçons d'une certaine catégorie.
[  62]Sélectionner les leçons d'un certain sujet.
[  63]Sélectionner les leçons d'un certain cours.
[  64]Sélectionner les leçons d'un certain statut.
[  65]Sélectionner les leçons d'une certaine période.
[  66]Déplacer après
[  70]Chercher:
[  71]Il peut devenir fastidieux d'avoir à naviguer dans la liste des leçons pour retrouver une leçon particulière.\n\nPour éviter cela, il est possible de saisir tout ou partie du nom d'une leçon et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera toutes les leçons correspondant au texte recherché.
