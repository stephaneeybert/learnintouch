[   0]Modifier l'introduction
[   1]Une leçon peut avoir une introduction.\n\nL'introduction fait partie du contenu de la leçon et est affiché au début de la leçon.
