[   0]Les en-tête de leçons
[   1]Créer un en-tête de leçon
[   2]Modifier le en-tête de leçon
[   3]Effacer le en-tête de leçon
[   5]Nom
[   6]Description
