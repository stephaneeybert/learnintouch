[   0]Effacer un en-tête de leçon
[   1]Nom:
[   5]Description:
[   2]Effacer l'en-tête de leçon?
