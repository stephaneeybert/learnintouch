[   0]Modifier un en-tête de leçon
[   4]Nom:
[   5]Description:
[   6]Le nom est requis.
