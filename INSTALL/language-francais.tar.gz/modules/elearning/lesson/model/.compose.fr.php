[   0]Composer un modèle de leçon
[   1]Ajouter une nouvelle rubrique
[   2]Effacer la rubrique ci-dessus
[   3]Etes vous sur de vouloir EFFACER cette rubrique ?
[   4]Nom:
[   5]Description:
[   6]Le nom est requis.
[   7]Texte de la rubrique:
[   8]Le nom et le texte de la rubrique sont affichés lors de l'affichage d'une leçon. C'est la rubrique pour un ou plusieurs paragraphs de la leçon.\n\nLes paragraphes de leçons sont affichés au sein de rubriques de modèle de leçon.\n\nChaque rubrique peut contenir plusieurs paragraphes.
[   9]Nom de la rubrique:
[  10]Image de la rubrique:
[  11]Intervertir avec la rubrique suivante
[  12]Intervertir avec la rubrique précédente
[  13]Télécharger ou effacer une image ou un fichier Flash
[  14]Instructions:
[  15]Des instructions peuvent être affichées pour guider le créateur de contenu durant la création d'une leçon.\n\nCes instructions sont ici pour aider le créateur de contenu.\n\nElles ne font pas partie du contenu de la leçon et ne sont pas affichées dans la leçon.
