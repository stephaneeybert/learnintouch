[   0]Les modèles de leçons
[   1]Créer un modèle de leçon
[   2]Modifier le modèle de leçon
[   3]Effacer le modèle de leçon
[   4]Composer le modèle de leçon
[   5]Nom
[   6]Description
[   7]Un modèle de leçon est un ensemble de rubriques composant un cadre dans lequel des leçons peuvent être affichées.\n\nSi une leçon a un modèle alors les paragraphes de la leçon sont affichés au sein des rubriques du modèle.\n\nCela permet d'avoir un cadre commun partagé par plusieurs leçons.\n\nUn modèle de leçon aide aussi le créateur de contenu lors de la création d'une nouvelle leçon.\n\nLa création d'une nouvelle leçon est plus facile en suivant un modèle.
[   8]Vérouiller le modèle de leçon
[   9]Dévérouiller le modèle de leçon
