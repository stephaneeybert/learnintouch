[   0]Effacer un modèle de leçon
[   1]Nom:
[   5]Description:
[   2]Effacer le modèle de leçon?
