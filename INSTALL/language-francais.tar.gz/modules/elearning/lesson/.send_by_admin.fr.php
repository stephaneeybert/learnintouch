[   0]Envoyer une leçon
[   1]Nom:
[   2]Envoyer la leçon?
[   3]Description:
[   4]En-tête:
[   5]Email:
[   6]Une leçon vous a été envoyée.
[   7]Salutations
[   8]Une leçon de
[   9]Pour lire la leçon, veuillez cliquer sur son nom:
[  10]Voir le contenu de la leçon...
[  11]Participant:
[  12]Le destinataire peut-être un participant, une classe de participants, ou une simple adresse email.
[  13]Classe de participants:
[  14]Il n'y a pas de participants dans la classe.
[  15]Bonjour
[  16]Veuillez sélectionner une classe de participants, un participant ou saisir une adresse email.
[  38]Le format de l'adresse email est invalide.
[  40]Un destinataire est requis.
