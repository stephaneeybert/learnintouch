[   0]Dupliquer une leçon
[   1]Nom:
[   5]Description:
[   7]Dupliquer la leçon?
[   6]Le nom est requis.
[   9]Une leçon avec ce nom existe déjà.
