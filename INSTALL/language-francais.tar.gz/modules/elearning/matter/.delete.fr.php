[   0]Effacer une matière
[   1]Nom:
[   5]Description:
[   2]Effacer la matière?
[   3]La matière ne peut être effacée car elle est utilisée par des cours.
