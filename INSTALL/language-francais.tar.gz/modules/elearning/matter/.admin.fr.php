[   0]Les matières
[   1]Créer une matière
[   2]Modifier la matière
[   3]Effacer la matière
[   5]Nom
[   6]Description
[   7]Une matière est le type de contenu des cours.\n\nPar exemple, une matière peut être Français ou Anglais, etc...
