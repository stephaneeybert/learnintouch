[  11]Ecrivez un texte.
[  12]Choisissez une réponse pour chaque question.
[  13]Choisissez une ou plusieurs réponses pour chaque question.
[  14]Choisissez toutes les réponses correctes pour chaque question.
[  15]Saisissez une réponse pour chaque question.
[  16]Choisissez une réponse pour chaque trou dans le texte.
[  17]Saisissez une réponse pour chaque trou dans le texte.
[  18]Déplacez une réponse dans sa question.\nCliquer pour effacer la réponse.
[  19]Déplacez une réponse dans les questions.\nCliquer pour effacer la réponse.
[  20]Déplacer les réponses pour assembler une phrase.
[  21]Déplacez une réponse dans chaque trou du texte.\nCliquer pour effacer la réponse.
[  22]Déplacez une réponse ou une image sous les questions.\nCliquer pour effacer la réponse.
