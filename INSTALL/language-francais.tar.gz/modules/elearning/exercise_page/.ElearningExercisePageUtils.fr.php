[   0]Page
[   1]page(s) restante(s)
[   2]Progression:
[   3]Effacer la réponse
[   4]de l'exercice
[   5]Un indice pour vous aider
[   6]Vos réponses sont toutes correctes!
[   7]Vos réponses sont toutes incorrectes.
[   8]Vos réponses sont partiellement correctes.
[   9]La solution est:
[  10]Afficher le texte
[  11]Voir la video
[  12]Aller à la video
[  13]Les solutions sont:
[  14]Cacher le texte
[  15]Vous n'avez pas saisi le nombre attendu de mots!
[  16]Vous avez saisi
[  17]mots sur
[  18]mots.
[  19]Mini clavier: 
[  20]Veuillez cliquer sur une lettre dans le mini clavier
[  21]Insérer la lettre
[  23]Aucune réponse n'a été donnée.
