[   1]Questions de l'exercice
[   2]Solutions de l'exercice
