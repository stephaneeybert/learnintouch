[   0]Modifier les instructions d'une page de questions
[   3]Instructions:
[   4]Nom:
[   5]Des instructions sur comment faire l'exercice peuvent être affichées au début d'une page de questions.\n\nCes instructions sont ici pour aider le participant à répondre aux questions de la page.\n\nElles ne sont pas supposées faire partie du contenu du cours.
[  12]Re-initialiser les instructions
