[   0]Dupliquer une page d'exercice
[   1]Page d'exercice:
[   7]Dupliquer la page d'exercice?
