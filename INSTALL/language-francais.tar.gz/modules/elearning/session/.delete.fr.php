[   0]Effacer une session
[   1]Participant:
[   2]Effacer la session?
[   3]Du
[   4]Au
[   5]La session ne peut pas être effacée parce qu'elle a des inscriptions de participants.
[   6]La session ne peut pas être effacée parce qu'elle a des cours.
[   7]La session ne peut pas être effacée parce qu'elle a des classes.
[   8]Cliquer ici pour voir les cours de la session.
[   9]Cliquer ici pour voir les classes de la session.
