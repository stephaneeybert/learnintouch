[   0]Les sessions
[   1]Créer une session
[   2]Modifier la session
[   3]Effacer la session
[   4]Cours
[   5]Statut
[   6]Date d'ouverture
[   7]Date de clôture
[   8]Statut:
[   9]Manuellement clôturée
[  10]Une session est une période de temps.\n\nElle peut durer de quelques semaines à quelques mois ou plus.\n\nUne fois qu'un cours est créé, il peut alors être offert dans des sessions successives.\n\nUn participant peut s'inscrire à une session d'un cours.\n\nPar exemple, un participant peut s'inscrire à la session de septembre pour le cours de "Français pour débutants".
[  11]Les cours de la session
[  12]Pas encore ouverte
[  13]Clôturée automatiquement
[  14]Actuellement ouverte
[  15]Il y a d'autres cours pour la session
[  16]Une session doit avoir au moins un cours.\n\nElle peut aussi avoir plusieurs cours.\n\nLes cours de la session, s'il y en a plus d'un, sont affichés dans la liste des cours d'une session.
[  17]Le statut d'une session représente le cycle de vie de la session.\n\nLes cours d'une session ne sont accessibles aux participants que lorsque la session est ouverte.
[  18]Classe
[  19]Pas encore ouverte
[  20]Ouverte
[  21]Clôturée
[  22]Une session peut avoir une ou plusieurs classes.\n\nLes classes de la session, s'il y en a plus d'une, sont affichées dans la liste des classes d'une session.
[  23]Les cours
Nom
[  25]Nom
