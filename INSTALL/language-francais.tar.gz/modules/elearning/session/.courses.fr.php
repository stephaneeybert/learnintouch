[   0]Les cours d'une session
[   1]Session:
[   2]Ajouter un cours:
[   3]Tous les cours ne sont pas nécessairement programmés pour les même sessions.\n\nCertains cours peuvent être programmés pour une session pendant que d'autres seront programmés pour une autre session.\n\nUne session peut avoir un ou plusieurs cours.\n\nSi une session a plusieurs cours alors tous ces cours commencent et se terminent en même temps.
[   4]Cours
[   5]Retirer le cours de la session
[   6]Les sessions
[   7]Date d'ouverture:
[   8]Il doit d'abord y avoir des cours pour pouvoir créer une session.
[   9]Les cours
[  10]Date de clôture::
[  11]Créer un cours...
