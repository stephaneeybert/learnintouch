[   0]Inscription d'enseignant
[   1]En devenant un enseignant, vous pourrez créer vos propres cours, leçons et exercices, et les offrir à vos participants.
[   2]Je souhaite être un enseignant:
[   3]S'enregistrer comme enseignant
[   4]Vous devez vous inscrire pour être un enseignant.
[   5]Vous êtes déjà un enseignant.
