[   0]Modifier une leçon
[   1]Annuler l'opération
[   3]Le nom est requis.
[   4]Le cours est requis.
[   5]Une leçon avec ce nom existe déjà.
[   6]Nom: *
[   7]Valider l'opération
[   8]Description:
[   9]Cours: *
[  10]Vous n'avez pas le droit de modifier cette leçon.
