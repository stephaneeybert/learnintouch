[   0]Une leçon est composée d'une introduction et d'une série de paragraphes.\n\nUn paragraphe de leçon peut être composé d'un titre, d'un en-tête, d'un corps, et d'un pied de paragraphe et d'un lien vers un exercice.\n\nLors d'une leçon, par défaut, tous les paragraphes sont affichés sur une page.
[   1]Modifier le texte du paragraphe
[   2]Les cours du professeur
[   3]Ajouter un paragraphe
[   4]Effacer la leçon et tous ses paragraphes
[   5]Effacer le paragraphe
[   6]Modifier le paragraphe
[   7]Télécharger ou effacer une image ou un fichier Flash
[   8]Modifier les instructions
[   9]Composer une leçon
[  10]Leçon:
[  26]Imprimer la leçon
[  27]Télécharger ou effacer un fichier audio ou Flash
[  34]Voir la leçon
[  40]Modifier la leçon
[  41]Télécharger ou effacer une image ou un fichier Flash
[  42]Télécharger ou effacer un fichier audio ou Flash
[  43]Modifier l'introduction
[  52]Imprimer le paragraphe
