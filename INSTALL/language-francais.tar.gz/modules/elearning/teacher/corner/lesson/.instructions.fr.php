[   0]Modifier les instructions d'une leçon
[   1]Instructions:
[   2]Annuler l'opération
[   4]Nom:
[   5]Description:
[   7]Valider l'opération
[  11]Des instructions sur comment faire la leçon peuvent être affichées au début d'une leçon.\n\nCes instructions sont ici pour aider le participant à faire la leçon.\n\nElles ne sont pas supposées faire partie du contenu de la leçon.
[  12]Vous n'avez pas le droit d'utiliser cette leçon.
