[   0]Effacer une leçon
[   1]Nom:
[   2]Effacer la leçon?
[   3]Cette leçon a des exercices qui ont déjà été utilisé et ont des résultats.\n\nEffacer la leçon ne va PAS effacer les exercices.\n\nLes exercices et les résultats seront conservés.
[   4]Effacer les exercices:
[   5]Description:
[   6]Les paragraphes de la leçon peuvent avoir des exercices.\n\nIl est possible d'effacer ces exercices avec la leçon.
[   7]Un exercice
[   8]Les exercices:
[  10]Annuler l'opération
[  11]Vous n'avez pas le droit d'effacer cette leçon
