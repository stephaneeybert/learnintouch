[   0]Modifier le texte du paragraphe
[   1]Annuler l'opération
[  11]Vous n'avez pas le droit d'utiliser ce paragraphe.
