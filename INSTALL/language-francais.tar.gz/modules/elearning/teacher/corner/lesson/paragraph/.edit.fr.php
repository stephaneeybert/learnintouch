[   0]Modifier un paragraphe de leçon
[   1]Rubrique:
[   2]Leçon: *
[   3]Le titre du paragraphe est requis.
[   4]Titre: *
[   6]Lien d'exercice:
[   7]Texte du lien d'exercice:
[   8]Par défaut, le lien vers un exercice affiche le nom de l'exercice.\n\nMais il est possible d'afficher un autre texte de lien vers l'exercice.
[   9]Il est possible d'afficher en bas de chaque paragraphe, un lien vers un exercice.\n\nUne leçon peut ainsi devenir un point d'entrée vers un ensemble d'exercices relevant de la leçon.
[  11]Un paragraphe peut être placé dans la rubrique d'un modèle de leçon.\n\nUn paragraphe peut aussi avoir un lien vers un exercice.\n\nUne leçon peut ainsi devenir un point d'entrée vers un ensemble d'exercices relevant de la leçon.
[  20]Annuler l'opération
[  21]Valider l'opération
[  22]Il est possible de déplacer le paragraph dans une autre leçon.\n\nPour choisir une leçon, veuillez saisir tout ou partie du nom d'une leçon et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera toutes les leçons correspondantes au texte recherché.
[  23]Video:
[  24]Une video d'un service comme YouTube, Vimeo ou autre, peut être affichée dans la page de question.\n\nLa video est insérée dans la page, par un copier/coller de son code html.
[  25]Url video:
[  26]La video peut aussi être accessible avec un lien html.\n\nDans ce cas, la video est affichée dans une nouvelle page sur le site web hébergeant la video.
