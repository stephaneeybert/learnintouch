[   0]Modifier l'introduction
[   1]Annuler l'opération
[   2]Vous n'avez pas le droit d'utiliser cette leçon.
[   3]Une leçon peut avoir une introduction.\n\nL'introduction fait partie du contenu de la leçon et est affiché au début de la leçon.
