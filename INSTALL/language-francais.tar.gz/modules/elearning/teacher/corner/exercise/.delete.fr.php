[   0]Effacer un exercice
[   1]Nom:
[   2]Effacer l'exercice?
[   3]Cette exercice a déjà été utilisée et a des résultats.\n\nEffacer l'exercice va aussi effacer les résultats détaillés de chaque question.\n\nMais les notes et les points de l'exercice seront conservés.
[   5]Description:
[   8]L'exercice est utilisé dans les leçons suivantes:
[   9]L'exercice doit être supprimé de ces leçons avant de pouvoir être effacé.
[  10]Annuler l'opération
[  11]Vous n'avez pas le droit d'effacer cet exercice.
