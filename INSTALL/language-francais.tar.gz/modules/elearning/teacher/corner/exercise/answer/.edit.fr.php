[   0]Modifier une réponse
[   2]Question:
[   4]Réponse:
[   9]Vous n'avez pas le droit d'utiliser cet exercice.
[  10]Explication:
[  11]L'explication peut être spécifique à chaque réponse.\n\nSi une explication est donnée pour une réponse alors elle remplace celle donnée pour la question.\n\nUne explication à propos de la question peut être affichée sous chaque résultat de question.\n\nElle peut donner au participant une information supplémentaire à propos de la solution à la question et l'aider à comprendre son erreur éventuelle.\n\nUn exemple d'explication pourrait être:\n\n'Eventually' est un faux ami. Bien que vous puissiez penser que la traduction soit 'éventuellement', elle est en fait 'finalement'.\n\nPour afficher, la réponse donnée par le participant, au sein du texte d'explication, veuillez utiliser la séquence de trois points d'intérogation '???'.\n\nL'explication est ainsi saisie comme:\n\n'Eventually' est un faux ami. Bien que vous puissiez penser que la traduction soit '???', elle est en fait 'finalement'.
[  15]Enregistrer l'explication
[  21]Valider l'opération
[  22]Annuler l'opération
