[   0]Effacer une réponse
[   1]Réponse:
[   2]Effacer la réponse?
[   3]Cette réponse a déjà été utilisée et a des résultats.\n\nEffacer la réponse va aussi effacer les résultats détaillés de la réponse.\n\nMais les résultats des autres réponses ne seront pas effacés et les notes et les points de l'exercice seront conservés.
[  10]Annuler l'opération
[  11]Vous n'avez pas le droit d'effacer cette réponse.
