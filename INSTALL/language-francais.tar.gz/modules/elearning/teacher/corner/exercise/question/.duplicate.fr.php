[   0]Dupliquer une question
[   1]Question:
[   5]Points:
[   7]Dupliquer la question?
[  10]Annuler l'opération
[  11]Vous n'avez pas le droit d'utiliser cet exercice.
