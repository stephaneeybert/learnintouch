[   0]Dupliquer une page d'exercice
[   1]Page d'exercice:
[   7]Dupliquer la page d'exercice?
[  10]Annuler l'opération
[  11]Vous n'avez pas le droit d'utiliser cet exercice.
