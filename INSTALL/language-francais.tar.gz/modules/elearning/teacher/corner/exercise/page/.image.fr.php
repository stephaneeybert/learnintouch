[   0]Télécharger une image
[   1]Une page de questions peut avoir une image.\n\nL'image est affichée sous le nom et la description de la page.
[   2]Sélectionner une image:
[   3]Nom de l'image:
[   4]Valider l'opération
[   6]Image:
[   7]Effacer l'image?
[   8]Annuler l'opération
[  11]Vous n'avez pas le droit d'utiliser cet exercice.
[  27]Aucune image n'a été spécifiée.
[   8]Redimensioner à la largeur:
[   9]Lors du téléchargement vers le serveur, une image peut être redimensionée à une certaine largeur.\n\nSi aucune largeur n'est spécifiée. alors l'image n'est pas redimensionée.\n\nLa largeur par défaut est prise de la plus grande largeur d'image dans les préférences.

