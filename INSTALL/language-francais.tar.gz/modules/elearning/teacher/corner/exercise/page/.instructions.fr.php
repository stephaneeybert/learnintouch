[   0]Modifier les instructions d'une page de questions
[   2]Annuler l'opération
[   4]Nom:
[   7]Valider l'opération
[  10]Des instructions sur comment faire l'exercice peuvent être affichées au début d'une page de questions.\n\nCes instructions sont ici pour aider le participant à répondre aux questions de la page.\n\nElles ne sont pas supposées faire partie du contenu du cours.
[  11]Vous n'avez pas le droit d'utiliser cet exercice.
[  12]Re-initialiser les instructions
