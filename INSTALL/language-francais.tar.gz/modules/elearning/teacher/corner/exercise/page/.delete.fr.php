[   0]Effacer une page de questions
[   1]Page de questions:
[   2]Effacer la page de questions?
[   3]Cette page de questions a déjà été utilisée et a des résultats.\n\nEffacer la page de questions va aussi effacer les résultats détaillés de chaque question de la page.\n\nMais les résultats des autres pages de questions ne seront pas effacés et les notes et les points de l'exercice seront conservés.
[  10]Annuler l'opération
[  11]Vous n'avez pas le droit d'effacer cette page de questions.
