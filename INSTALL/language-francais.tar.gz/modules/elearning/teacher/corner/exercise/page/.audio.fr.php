[   0]Télécharger un fichier audio
[   1]Une page de questions peut avoir un fichier audio.\n\nUn fichier audio est un fichier qui peut être envoyé sur l'Internet pour diffuser du contenu audio.
[   2]Ko.
[   3]Nom du fichier:
[   4]Valider l'opération
[   5]Sélectionner un fichier:
[   6]Fichier audio:
[   7]Annuler l'opération
[   8]Effacer le fichier audio?
[  11]Vous n'avez pas le droit d'utiliser cet exercice.
[  27]Aucun fichier audio n'a été spécifié.
