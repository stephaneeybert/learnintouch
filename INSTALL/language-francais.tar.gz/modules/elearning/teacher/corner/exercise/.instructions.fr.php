[   0]Modifier les instructions d'un exercice
[   1]Instructions:
[   2]Annuler l'opération
[   4]Nom:
[   5]Description:
[   7]Valider l'opération
[  11]Des instructions sur comment faire l'exercice peuvent être affichées au début d'un exercice.\n\nCes instructions sont ici pour aider le participant à faire l'exercice.\n\nElles ne sont pas supposées faire partie du contenu de l'exercice.
[  12]Vous n'avez pas le droit d'utiliser cet exercice.
