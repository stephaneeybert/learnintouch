[   0]Modifier un exercice
[   1]Annuler l'opération
[   3]Le nom est requis.
[   4]Le cours est requis.
[   5]Un exercice avec ce nom existe déjà.
[   6]Nom: *
[   7]Valider l'opération
[   8]Description:
[   9]Cours: *
[  10]Vous n'avez pas le droit de modifier cet exercice.
[  11]La durée maximale doit être un nombre de minutes
[  12]Durée maximale:
[  13]Par défaut, les exercices n'ont pas de durée maximale.\n\nLes participants peuvent prendre tout leur temps pour faire un exercice.\n\nIl est aussi possible d'avoir une durée maximale identique pour tous les exercices.\n\nEt il est enfin possible d'avoir une durée maximale spécifique à un exercice de façon à avoir des exercices avec des durées maximales différentes.\n\nLa durée est exprimée en minutes.
[  20]Onglets en numéros de page:
[  21]Par défaut, les onglets des pages d'un exercice sont affichés en utilisant les noms des pages de questions.\n\nMais il est possible d'afficher les onglets, en, ou avec, des numéros de pages.
[  22]Cacher le clavier des lettres spéciales:
[  23]Par défaut, lors de l'affichage d'une page de questions qui demande au participant de saisir les réponses, une série de lettres est affichée en haut de la page.\n\nCes lettres sont celles qui peuvent manquer sur le clavier de l'ordinateur utilisé par le participant.\n\nIl est possible de cacher ce clavier sur écran.
[  53]En numéros de pages
[  54]Avec des numéros de pages.
