[   0]Ajouter une leçon à un cours
[   1]Un cours est composé d'une série de leçons et/ou exercices.\n\nUn cours peut avoir un nombre illimité de leçons et/ou exercices.
[   2]Cours:
[   3]La leçon est déjà assignée à ce cours.
[   4]Nom:
[   5]Description:
[   6]Le cours est requis.
[   7]Valider l'opération
[   8]Annuler l'opération
[  10]Vous n'avez pas le droit d'utiliser ce cours.
[  11]Vous n'avez pas le droit d'utiliser cette leçon.
