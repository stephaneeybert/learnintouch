[   0]Enlever une leçon d'un cours
[   1]Lorsqu'une leçon est enlevée d'un cours, la leçon n'est pas effacée.\n\nElle est simplement enlevée de la liste des leçons composant le cours.\n\nLa leçon peut toujours être utilisée par d'autres cours.
[   2]Cours:
[   4]Nom:
[   5]Description:
[   6]Valider l'opération
[   7]Annuler l'opération
[  10]Vous n'avez pas le droit d'utiliser ce cours.
[  11]Vous n'avez pas le droit d'utiliser cette leçon.
