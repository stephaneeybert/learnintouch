[   0]Effacer une information sur le cours
[   4]Titre:
[   5]Information:
[   6]Valider l'opération
[   7]Annuler l'opération
[  10]Vous n'avez pas le droit d'utiliser ce cours.
