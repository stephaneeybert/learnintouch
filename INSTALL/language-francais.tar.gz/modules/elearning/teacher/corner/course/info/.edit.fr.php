[   0]Créer ou modifier une information sur le cours
[   1]Vos cours, vos leçons, vos exercices...
[   2]Ajouter une information sur le cours
[   3]Le titre est requis.
[   6]Titre: *
[   7]Valider l'opération
[   8]Information:
[  10]Vous n'avez pas le droit de modifier ce cours.
[  13]Annuler l'opération

