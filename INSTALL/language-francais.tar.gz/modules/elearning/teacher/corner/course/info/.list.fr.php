[   0]L'information sur le cours
[   1]Modifier l'information sur le cours
[   2]Ajouter une information sur le cours
[   3]Les cours du professeur
[  10]Effacer l'information sur le cours
[  24]L'information sur le cours est composée d'une série de titres et de textes associés.\n\nL'information sur le cours est une description détaillée du contenu du cours.\n\nElle peut contenir plusieurs pages chacune composée d'un titre et d'un text.\n\nElle permet au participant d'en savoir plus sur le cours avant de s'inscrire.
[  25]Vous n'avez pas encore créé d'information sur le cours.
[  26]Vous pouvez créer une information sur le cours en
[  27]cliquant ici
