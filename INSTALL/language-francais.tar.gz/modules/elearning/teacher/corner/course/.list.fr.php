[   0]Les cours du professeur
[   1]Ajouter une leçon
[   2]Ajouter un cours
[   3]Modifier l'exercice
[   4]Composer l'exercice
[   5]Modifier la leçon
[   6]Composer la leçon
[   7]Modifier le cours
[   8]Ajouter un exercice
[   9]Enlever du cours
[  10]Effacer l'exercice
[  11]Effacer la leçon
[  12]Voir l'exercice
[  13]Voir la leçon
[  14]Imprimer l'exercice
[  15]Imprimer la leçon
[  16]Envoyer par email
[  17]Ajouter la leçon à un cours
[  18]Ajouter l'exercice à un cours
[  19]Déplacer après
[  20]Un cours
[  21]Une leçon du cours
[  22]Un exercice du cours
[  23]Un exercice de la leçon
[  24]Un cours est composé d'une série de leçons et exercices.\n\nPar exemple, un cours peut être "Français pour débutants".\n\nAvant d'ajouter des leçons et des exercices à un cours, le cours doit être créé.\n\nVeuillez cliquer sur l'icône pour ajouter un cours.
[  25]Vous n'avez pas encore créé de cours.
[  26]Vous pouvez
[  27]créer un cours.
