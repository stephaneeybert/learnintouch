[   0]Ajouter un exercice à un cours
[   1]Un cours est composé d'une série d'exercices et/ou de leçons.\n\nUn cours peut avoir un nombre illimité d'exercices et/ou de leçon.
[   2]Cours:
[   3]L'exercice est déjà assigné à ce cours.
[   4]Nom:
[   5]Description:
[   6]Le cours est requis.
[   7]Valider l'opération
[   8]Annuler l'opération
[  10]Vous n'avez pas le droit d'utiliser ce cours.
[  11]Vous n'avez pas le droit d'utiliser cet exercice.
