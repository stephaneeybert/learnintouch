[   0]Modifier un enseignant
[   1]Utilisateur:
[   2]Un enseignant est un utilisateur du système.\n\nPour créer un nouvel enseignant, veuillez d'abord créer un utilisateur.\n\nEnsuite veuillez choisir cet utilisateur nouvellement créé pour être un enseignant.
[   3]L'utilisateur est requis.
[   4]Cet utilisateur est déjà un enseignant.
[   5]Ajouter un utilisateur
[  15]Sélectionner un utilisateur
[  25]Parcourir...
