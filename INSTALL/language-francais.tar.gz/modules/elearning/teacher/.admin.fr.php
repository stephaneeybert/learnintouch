[   0]Les enseignants
[   1]Créer un enseignant
[   2]Seul un enseignant avec le privilège super administrateur peut accéder à cette page.
[   3]Effacer l'enseignant
[   8]Nom
[   9]Email
[  10]Les enseignants sont les personnes qui enseignent aux participants.\n\nLes enseignants sont choisis parmis les utilisateurs du site web.\n\nPour créer un nouvel enseignant, veuillez d'abord créer un utilisateur.
[  70]Chercher:
[  71]Il peut devenir fastidieux d'avoir à naviguer dans la liste des enseignants pour retrouver un enseignant particulier.\n\nPour éviter cela, il est possible de saisir tout ou partie du nom d'un enseignant et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera tous les enseignants correspondant au texte recherché.
