[   0]Importer un cours
[   1]Nom:
[   2]Description:
[   3]Un cours avec ce nom existe déjà.
[   4]Une matière doit être choisie pour importer le cours.
[   5]Importer dans la matière:
[   6]Une matière doit être choisie pour importer le cours.\n\nLe cours importé aura la matière choisie.
[   7]Exercice:
[   8]Le cours n'a pas pu être accédé.
[   9]Leçon:
[  10]Le cours a été importé avec succès.
[  11]Le cours n'a pas pu ëtre importé.
[  13]Cours:
[  14]Voir le cours importé
