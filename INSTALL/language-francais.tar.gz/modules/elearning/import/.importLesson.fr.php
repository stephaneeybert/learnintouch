[   0]Importer une leçon
[   1]Nom:
[   2]Description:
[   3]Une leçon avec ce nom existe déjà.
[   4]La leçon n'a pas pu être accédée.
[   5]La leçon a été importée avec succès.
[   6]La leçon n'a pas pu ëtre importée.
[   7]Leçon:
[   8]Voir la leçon importée
