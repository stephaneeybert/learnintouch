[   0]Import de cours
[   1]Cours
[   2]Description
[   3]Les sites web d'où vous pouvez importer du contenu
[   4]Importer le cours et toutes ses leçons et exercices
[   5]Site web exportateur:
[   6]Les sites web qui peuvent importer votre contenu
[   7]Matière:
[   8]Enregistrez un site web d'où vous pouvez importer du contenu
[   9]Sélectionnez un site web d'où vous pouvez importer du contenu
[  10]Il est possible d'importer des cours d'un site web.\n\nLa liste affiche tous les cours qui peuvent être importés depuis un site web.\n\nLe site web doit d'abord être enregistré comme un site web exportateur.\n\nLors de l'import d'un cours, le cours lui même et tout son contenu est importé.
[  11]Element de cours
[  12]Importer la leçon ou l'exercice
[  13]Cours:
[  14]Chercher:
[  15]Au lieu de sélectionner une matière et un cours, il est possible de saisir tout ou partie du nom d'un cours, d'une leçon ou d'un exercice, et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera tous les cours, leçons et exercices correspondant au texte recherché.
[  16]Sélectionnez une matière pour afficher ses cours.
[  17]Sélectionnez un cours pour afficher ses leçons et exercices.
[  18]Exercice
[  19]Leçon
[  20]Le texte recherché doit contenir au moins 4 caractères.
[  21]Autres:
[  22]Il est possible de consulter les autres exercices et leçons, y compris ceux et celles qui n'appartiennent pas à un cours.
