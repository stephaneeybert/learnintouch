[   0]Importer un exercice
[   1]Nom:
[   2]Description:
[   3]Un exercice avec ce nom existe déjà.
[   4]L'exercice n'a pas pu être accédé.
[   5]L'exercice a été importé avec succès.
[   6]L'exercice n'a pas pu ëtre importé.
[   7]Exercice:
[   8]Voir l'exercice importé
