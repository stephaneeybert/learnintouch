[   0]Les scorings
[   1]Créer un scoring
[   2]Modifier le scoring
[   3]Effacer le scoring
[   4]Les plages
[   5]Nom
[   6]Description
[   7]Un scoring est l'évaluation du niveau d'un participant à l'aide des résultats de un exercice.\n\nSi un scoring est spécifié pour un exercice alors un message correspondant au niveau est affiché à la fin de l'exercice.\n\nUn scoring est composé de plusieurs messages qui sont associés à des pourcentages de réponses correctes.
