[   0]Modifier un scoring
[   1]Score requis:
[   2]Il est possible de spécifier un score requis.\n\nDans ce cas, un message félicitant ou encourageant le participant sera affiché dans les résultats du scoring.\n\nLe score requis est exprimé en pourcentage.
[   4]Nom:
[   5]Description:
[   6]Le nom est requis.
