[   0]Les plages de scoring
[   1]Créer une plage
[   2]Modifier la plage
[   3]Effacer la plage
[   4]Conseil de l'école
[   5]Haut
[   6]Niveau du participant
[   7]Proposition de cours
[   8]Scoring:
[   9]Un scoring est composé de plusieurs plages.\n\nChaque plage correspond à un pourcentage de réponses correctes.\n\nLe message dans chaque plage est découpé en trois parties, un texte sur le niveau du participant, un texte sur un conseil de l'école au participant, et un texte sur une proposition pour un cours.\n\nSeule la première partie du message est requise.
[  10]Page web
