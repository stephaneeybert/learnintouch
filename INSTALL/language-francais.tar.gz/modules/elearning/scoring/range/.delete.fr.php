[   0]Effacer une plage de scoring
[   1]Max:
[   5]Score:
[   4]Conseil:
[   6]Proposition:
[   2]Effacer la plage de scoring?
