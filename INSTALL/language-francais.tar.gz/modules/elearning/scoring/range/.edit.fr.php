[   0]Modifier une plage de scoring
[   1]Conseil de l'école:
[   2]Proposition de cours:
[   3]Le message du score est requis.
[   4]Haut:
[   5]Niveau du participant:
[   6]Le pourcentage du haut de la plage est requis.
[   7]Texte du lien:
[   8]Le texte du lien est le texte du lien vers la page web.
[   9]Le niveau du participant est un texte qui donne une estimation du niveau du participant.\n\nIl peut plus ou moins féliciter le participant en fonction de la plage du scoring.
[  10]Le conseil est un texte qui indique ce que le participant devrait faire.\n\nC'est une recommendation générale qui exprime le besoin du participant.\n\nIl pourrait mentionner des noms de cours ou niveaux officiels.
[  11]La proposition de cours est un texte qui propose au participant un cours de l'école, suivant le conseil qui lui a été précédemment donné.\n\nC'est la réponse au besoin du participant.\n\nC'est une invitation à une inscription à un cours.
[  12]Le pourcentage du haut de la plage doit être compris entre 1 et 100.
[  13]Scoring:
[  14]Une plage est décrite par deux valeurs.\n\nSeule la valeur haute de la plage a besoin d'être spécifiée.\n\nLa valeur basse de la plage étant la valeur haute de la plage précédente.\n\nLa valeur doit être un nombre compris entre 1 et 100.
[  15]Page web:
[  16]Un lien vers une page web affichée en dessous des messages de scoring permet d'offrir au participant, plus d'information relative à la proposition du scoring.
[  17]Sélectionner une page du site web
[  18]Parcourir...
