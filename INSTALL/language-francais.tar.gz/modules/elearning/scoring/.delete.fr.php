[   0]Effacer un scoring
[   1]Nom:
[   5]Description:
[   2]Effacer le scoring et toutes ses plages?
[   3]Le scoring ne peut être effacé car il est utilisé par des exercices.
