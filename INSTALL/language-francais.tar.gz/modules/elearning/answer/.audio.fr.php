[   0]Télécharger un fichier audio
[   6]Fichier audio:
[   3]Nom du fichier:
[   5]Sélectionner un fichier:
[   7]Effacer le fichier audio?
[  27]Aucun fichier audio n'a été spécifié.
[   1]Une réponse peut avoir un fichier audio.\n\nLe fichier audio est joué en cliquant sur le lecteur audio.\n\nUn fichier audio est un fichier qui peut être envoyé sur l'Internet pour diffuser du contenu audio.
[   2]Ko.
