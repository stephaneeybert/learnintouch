[   0]Les cours
[   1]Ajouter un cours
[   2]Modifier le cours
[   3]Effacer le cours
[   4]Nom
[   5]Importable
[   6]Le cours peut être importé par d'autres sites web
[   7]Insérer ou effacer une image ou un fichier multimédia
[   8]Les leçons
[   9]Les exercices
[  10]Restreindre aux super administrateurs
[  11]Autoriser pour tous les administrateurs
[  12]Les leçons du cours
[  13]Les exercices du cours
[  14]Utilisateur:
[  15]Un cours peut aussi être créé par un utilisateur.\n\nDans ce cas, il est possible de n'afficher que les cours d'un utilisateur.\n\nVeuillez noter qu'un utilisateur n'est pas un administrateur.
[  16]Auto inscription
[  17]Description
[  18]Les participants peuvent s'inscrire au cours par eux-mëme
[  19]Donner le cours aux participants d'une classe
[  20]Modifier l'information de cours
[  21]Les sessions
[  22]Dupliquer le cours
[  28]Envoyer par email
[  29]Un cours est composé d'une série de leçons et d'exercices.\n\nPar exemple, un cours peut être "Français pour débutants".\n\nLes cours peuvent être triés par matière.
[  33]Matière:
[  34]Les matières
[  53]Importer un cours, une leçon ou un exercice
[  70]Chercher:
[  71]Il peut devenir fastidieux d'avoir à naviguer dans la liste des cours pour retrouver un cours particulière.\n\nPour éviter cela, il est possible de saisir tout ou partie du nom d'un cours et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera tous les cours correspondant au texte recherché.
