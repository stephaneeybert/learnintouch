[   0]Enlever un exercice d'un cours
[   1]Lorsqu'un exercice est enlevé d'un cours, l'exercice n'est pas effacé.\n\nIl est simplement enlevé de la liste des exercices composant le cours.\n\nL'exercice peut être utilisé par d'autres cours.
[   2]Cours:
[   4]Nom:
[   5]Description:
[   9]Le cours est vérouillé est ne peut pas être mis à jour.
