[   0]Envoyer un cours
[   1]Nom:
[   2]Envoyer le cours?
[   3]Description:
[   4]Texte:
[   6]Un cours vous a été envoyé.
[   7]Salutations
[   8]Un cours de
[   9]Pour faire le cours, veuillez cliquer sur son nom:
[  11]Participant:
[  12]Le destinataire peut-être un participant, une classe de participants, ou une simple adresse email.
[  13]Classe de participants:
[  14]Il n'y a pas de participants dans la classe.
[  15]Bonjour
[  16]Veuillez sélectionner une classe de participants ou un participant, ou saisissez une adresse email.
[  40]Un destinataire est requis.
