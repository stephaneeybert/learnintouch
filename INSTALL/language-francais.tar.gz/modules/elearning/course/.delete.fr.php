[   0]Effacer un cours
[   1]Nom:
[   2]Effacer le cours?
[   3]Le cours ne peut pas être effacé parce que des sessions sont programmées pour ce cours.
[   4]Le cours ne peut pas être effacé parce qu'il contient des leçons et / ou des exercices.
[   5]Description:
[   6]Le cours ne peut pas être effacé parce que des participants se sont inscrit à ce cours.
[   7]Ignorer les inscriptions de participants:
[   8]Par défaut, un cours ne peut pas être effacé si des participants se sont inscrit au cours.\n\nMais il est possible d'effacer un cours et modifier toutes les inscriptions de participants.\n\nDans ce cas, les inscriptions de participants ne seront pas supprimées.
[   9]Le cours est vérouillé est ne peut pas être effacé.
[  10]Le cours est utilisé par
[  11]inscriptions de participants.
[  12]Ignorer les leçons et / ou les exercices:
[  13]Si le cours contient des leçons et / ou des exercices alors ceux-ci seront retirés du cours mais ne seront pas supprimées.
