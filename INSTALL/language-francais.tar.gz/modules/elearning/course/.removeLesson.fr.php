[   0]Enlever une leçon d'un cours
[   1]Lorsqu'une leçon est enlevée d'un cours, la leçon n'est pas effacée.\n\nElle est simplement enlevée de la liste des leçons composant le cours.\n\nLa leçon peut toujours être utilisée par d'autres cours.
[   2]Cours:
[   4]Nom:
[   5]Description:
[   9]Le cours est vérouillé est ne peut pas être mis à jour.
