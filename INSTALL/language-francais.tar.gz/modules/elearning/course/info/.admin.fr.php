[   0]Modifier l'information de cours
[   1]Intervertir avec l'information suivante
[   3]Titre
[   4]Cours:
[   8]Effacer l'information de cours
[   9]Intervertir avec l'information précédente
[  15]Etes vous sur de vouloir EFFACER cette information de cours ?
[  17]Ajouter une information de cours
[  20]Modifier l'information de cours
[  29]L'information sur le cours est composée d'une série de titres et de textes associés.
