[   0]Composer un article
[   1]Extrait:
[   4]Le titre est requis.
[   6]Titre:
[  23]L'information sur le cours est une description détaillée du contenu du cours.\n\nElle peut contenir plusieurs pages chacune composée d'un titre et d'un text.\n\nElle permet au participant d'en savoir plus sur le cours avant de s'inscrire.
