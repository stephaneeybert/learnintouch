[   0]Afficher l'information sur le cours
[   1]Cacher l'information sur le cours
