[   0]Ajouter une leçon à un cours
[   1]Un cours est composé d'une série de leçons et/ou exercices.\n\nUn cours peut avoir un nombre illimité de leçons et/ou exercices.
[   2]Cours:
[   3]La leçon est déjà assignée à ce cours.
[   4]Nom:
[   5]Description:
[   9]Le cours est vérouillé est ne peut pas être mis à jour.
