[   0]Dupliquer un cours
[   1]Nom:
[   5]Description:
[   7]Dupliquer le cours?
[   6]Le nom est requis.
[   9]Un cours avec ce nom existe déjà.
