[   0]Effacer un devoir d'un participant
[   1]Participant:
[   2]Exercice:
