[   0]Effacer les devoirs clôturés d'un participant
[   1]Participant:
[   2]Effacer les devoirs clôturés ?
