[   0]Donner un devoir
[   1]Classe:
[   2]Exercice:
[   3]Seuls les participants sélectionnés recevront le devoir.
[   4]L'exercice est requis.
[   5]Participant:
[   6]Aux participants:
[   7]Sélectionner tout
[   8]Une seule fois:
[   9]Par défaut, un participant peut faire et refaire un devoir plusieurs fois.\n\nMais il est possible de ne lui permettre de faire le devoir qu'une seule fois.\n\nDans ce cas, le participant ne pourra pas faire le devoir une seconde fois.\n\nMême si le participant peut faire le devoir plus d'une fois, ses résultats ne sont pas sauvegardés à nouveau.\n\nLes résultats des devoirs ne sont sauvegardés que la première fois que le participant les fait.
[  10]Il est possible de donner un devoir à un ou plusieurs participants.\n\nTous les participants seront alors capables de faire le devoir.\n\nPar exemple, il est possible de donner un devoir à tous les participants d'une classe.
[  11]Date d'ouverture:
[  12]Si une date d'ouverture est spécifiée alors le devoir ne sera pas disponible avant la date d'ouverture.
[  13]Date de clôture:
[  14]Si une date de clôture est spécifiée alors le devoir ne sera pas disponible après la date de clôture.
[  15]Dé-sélectionner tout
[  21]Une date doit avoir le format
[  34]La date de clôture doit être postérieure à la date d'ouverture.
