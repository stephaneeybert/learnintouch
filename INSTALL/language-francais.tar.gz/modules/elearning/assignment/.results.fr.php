[   0]Les résultats des devoirs
[   1]Les résultats des devoirs sont affichés en direct.
[   2]Classe:
[   3]Suggérer un devoir à la classe
[   4]Exercice
[   5]Modifier le devoir de classe
[   6]Effacer le devoir de classe
[   7]Suivre en direct
[   8]Il est possible de suivre la progression de l'exercice pendant que le participant répond aux questions.\n\nDans ce cas, les résultats des questions seront affichés au professeur pendant que le participant fait l'exercice.\n\nLe professeur pourra voir une progression graphique de chaque devoir ainsi que de l'ensemble de tous les devoirs.
[   9]Fait
[  10]Une seule fois
[  11]Réponses / Questions
[  12]Ouverture
[  13]Clôture
[  14]Par défaut, un participant peut faire et refaire un devoir plusieurs fois.\n\nMais il est possible de ne lui permettre de faire le devoir qu'une seule fois.\n\nDans ce cas, le participant ne pourra pas faire le devoir une seconde fois.
[  15]La note est une lettre ou un texte qui représente la performance du participant.
[  16]Résultats en direct
[  17]Il est possible de suivre la progression de l'exercice pendant que le participant répond aux questions.\n\nDans ce cas, les résultats des questions seront affichés au professeur pendant que le participant fait l'exercice.\n\nLe professeur pourra voir une progression graphique de chaque exercice.\n\nLes résultats en direct sont affichés seulement quand le participant est en ligne et en train de faire l'exercice.\n\nSi le participant est inactif alors un voyant se met à clignoter.\n\nSi le participant est absent alors rien n'est affiché.
[  18]Participant
[  19]Note
[  20]Voir les résultats
[  21]Note moyenne du participant:
[  22]Effacer le résultat
[  23]Composer l'exercice
[  24]Voir le participant
[  25]Participant:
[  26]Copilote avec le participant
[  27]Les réponses est le nombre de réponses données par le participant, incluant celles correctes et celles incorrectes.\n\nLes questions est le nombre de questions pour l'exercice.
[  28]Indique quand le participant a fait le devoir.
[  29]Session:
[  30]Si une session est sélectionnée alors seuls les devoirs que les participants ont fait durant la session seront affichés.\n\nLes devoirs que les participants n'ont pas fait durant la session ne seront pas affichés, même si ils étaient supposés être fait à ce moment.
[  31]Les devoirs
[  32]Depuis:
[  33]Les plages de résultats
[  34]Points
[  35]Les points est le total de points pour les réponses correctes données par le participant.\n\nPar défaut, une réponse vaut un point, mais elle peut valoir plusieurs points.
[  36]Résultats
[  37]Les résultats sont le nombre de réponses correctes par le nombre de questions.
[  38]Réponses
[  39]Le nombre de réponses correctes et le nombre de réponses incorrectes.
[  40]Le graphe des résultats
[  41]La note moyenne est la moyenne de toutes les notes des exercices.
[  42]Note moyenne des participants:
[  43]Une semaine
[  44]Un mois
[  45]Trois mois
[  46]Six mois
[  47]Un an
[  48]Le tableau partagé
