[   0]Le participant n'a pas encore commencé l'exercice.
[   1]L'inscription du participant n'a pas pu être trouvée.
[   2]Le participant n'a pas pu être trouvé.
