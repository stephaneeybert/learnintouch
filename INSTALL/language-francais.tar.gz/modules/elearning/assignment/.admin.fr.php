[   0]Les devoirs
[   1]Un participant peut recevoir des devoirs à faire.\n\nUn devoir est un exercice que le participant doit faire.
[   2]L'inscription n'est pas actuelement ouverte.
[   3]Donner un devoir
[   4]Exercice
[   5]Modifier le devoir
[   6]Effacer le devoir
[   7]Résultats en direct
[   8]Il est possible de suivre la progression de l'exercice pendant que le participant répond aux questions.\n\nDans ce cas, les résultats des questions seront affichés au professeur pendant que le participant fait l'exercice.\n\nLe professeur pourra voir une progression graphique de chaque devoir.\n\nLes résultats en direct sont affichés seulement quand le participant est en ligne et en train de faire l'exercice.\n\nSi le participant est inactif alors un voyant se met à clignoter.\n\nSi le participant est absent alors rien n'est affiché.
[   9]Participant
[  11]Fait 
[  12]Ouverture
[  13]Clôture
[  15]Indique si et quand le participant a fait le devoir.
[  16]Si une date d'ouverture est spécifiée alors le devoir ne sera pas disponible avant la date d'ouverture.
[  17]Si une date de clôture est spécifiée alors le devoir ne sera pas disponible après la date de clôture.
[  18]Participant:
[  19]Classe:
[  20]Les résultats des devoirs
[  21]Statut:
[  22]Par défaut, tous les devoirs sont affichés.\n\nMais il est possible de n'afficher que ceux qui sont disponibles maintenant, ceux qui seront disponibles prochainement ou ceux qui sont clôturés.
[  23]Effacer les devoirs clôturés
[  24]Suivre et aider le participant
[  25]En cours
[  26]Prochainement
[  27]Clôturé
[  28]Voir les résultats
