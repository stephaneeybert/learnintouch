[   0]Envoyer un exercice
[   1]Nom:
[   2]Envoyer l'exercice?
[   3]Description:
[   4]Texte:
[   5]Email:
[   6]Un exercice vous a été envoyé.
[   7]Salutations
[   8]Un exercice de
[   9]Pour faire l'exercice, veuillez cliquer sur son nom:
[  10]Voir le contenu de l'exercice...
[  11]Participant:
[  12]Le destinataire peut-être un participant, une classe de participants, ou une simple adresse email.
[  13]Classe de participants:
[  14]Il n'y a pas de participants dans la classe.
[  15]Bonjour
[  16]Veuillez sélectionner une classe de participants ou un participant, ou saisissez une adresse email.
[  38]Le format de l'adresse email est invalide.
[  40]Un destinataire est requis.
