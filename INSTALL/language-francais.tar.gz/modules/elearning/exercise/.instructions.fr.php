[   0]Modifier les instructions d'un exercice
[   1]Instructions:
[   4]Nom:
[   5]Description:
[  11]Des instructions sur comment faire l'exercice peuvent être affichées au début d'un exercice.\n\nCes instructions sont ici pour aider le participant à faire l'exercice.\n\nElles ne sont pas supposées faire partie du contenu de l'exercice.
