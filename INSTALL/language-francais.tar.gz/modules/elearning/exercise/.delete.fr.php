[   0]Effacer un exercice
[   1]Nom:
[   2]Effacer l'exercice?
[   3]Cette exercice a déjà été utilisée et a des résultats.\n\nEffacer l'exercice va aussi effacer les résultats détaillés de chaque question.\n\nMais les notes et les points de l'exercice seront conservés.
[   4]L'exercice est vérouillé est ne peut pas être effacé.
[   5]Description:
[   6]L'exercice est utilisé dans les cours suivants:
[   7]L'exercice doit être supprimé de ces cours avant de pouvoir être effacé.
[   8]L'exercice est utilisé dans les leçons suivantes:
[   9]L'exercice doit être supprimé de ces leçons avant de pouvoir être effacé.
