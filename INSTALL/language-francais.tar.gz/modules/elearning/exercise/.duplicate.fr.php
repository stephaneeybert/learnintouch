[   0]Dupliquer un exercice
[   1]Nom:
[   5]Description:
[   7]Dupliquer l'exercice?
[   6]Le nom est requis.
[   9]Un exercice avec ce nom existe déjà.
