[   0]Composer l'exercice
[   1]Intervertir avec la page de questions suivante
[   2]Pages de questions
[   3]Ajouter une page de questions à l'exercice
[   4]Exercice:
[   5]Effacer la page et toutes ses questions
[   6]Modifier la page de questions
[   7]Télécharger ou effacer une image ou un fichier Flash
[   8]Modifier les instructions de l'exercice
[   9]Intervertir avec la page de questions précédente
[  10]Modifier le texte de la page de questions
[  11]Question à choix multiple 
[  12]Saisissez une réponse
[  13]Ecoute audio
[  14]Dupliquer la question
[  15]Ajouter une question à la page de questions
[  16]Modifier les instructions de la page de questions
[  17]Voir la page de questions
[  18]Intervertir avec la réponse suivante
[  19]Intervertir avec la réponse précédente
[  20]Modifier la question
[  21]Effacer la question et toutes ses réponses
[  22]Ajouter une réponse à la question
[  23]Modifier la réponse
[  24]Effacer la réponse
[  25]Spécifier comme une solution à la question
[  26]Imprimer l'exercice
[  27]Télécharger ou effacer un fichier audio ou Flash
[  28]Spécifier les pages de questions suivantes
[  29]Un exercice peut être composé d'une introduction suivie de plusieurs pages de questions.\n\nUne page de questions peut être composée d'un texte, d'une image ou d'une animation Flash, d'un fichier audio et d'une série de questions.\n\nLors d'un exercice, par défaut, chaque page de questions est affiché sur une page séparée, l'une après l'autre.
[  30]Intervertir avec la question suivante
[  31]Intervertir avec la question précédente
[  32]Points
[  33]Spécifier comme PAS une solution à la question
[  34]Voir l'exercice
[  35]Indice
[  36]Compréhension écrite
[  37]Expression écrite
[  38]Compréhension orale
[  39]Type
[  40]Modifier l'exercice
[  41]Télécharger ou effacer une image ou un fichier Flash
[  42]Télécharger ou effacer un fichier audio ou Flash
[  43]Modifier l'introduction
[  44]Le nombre de questions est inférieur au nombre de marqueurs d'emplacements dans le texte de la page.
[  45]Le nombre de marqueurs d'emplacements
[  46]Conserver l'ordre existant des questions
[  47]Réordonnner les questions dans l'ordre chronologique de leur création
[  48]Dupliquer la page de l'exercice
[  49]Les réponses ordonnées sont différentes de la question.
[  50]Pour une phrase à ordonner, toutes les réponses doivent être des solutions.
[  51]La question a besoin de plus d'une réponse.
[  52]Imprimer la page de l'exercice
[  53]Déplacer dans la question
[  54]Déplacer après la réponse
[  55]Déplacer avant la réponse
[  56]Déplacer dans la page de questions
[  57]Déplacer après la question
[  58]Déplacer avant la question
[  59]Déplacer après la page de questions
[  60]Déplacer avant la page de questions
[  61]dans le texte de la page est inférieur au nombre de questions
