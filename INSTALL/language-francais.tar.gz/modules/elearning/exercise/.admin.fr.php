[   0]Les exercices
[   1]Créer un exercice
[   2]Modifier la leçon
[   3]Mettre l'exercice à la corbeille
[   4]Nom
[   5]Composer la leçon
[   6]Les catégories
[   7]Insérer ou effacer une image ou un fichier multimédia
[   8]Ajouter l'exercice à un cours
[   9]Catégorie:
[  10]Intervertir avec le suivant
[  11]Intervertir avec le précédent
[  12]Composer l'exercice
[  13]Niveau:
[  14]Les niveaux
[  15]Enlever du cours
[  16]Une leçon
[  17]Description
[  18]Exercices
[  19]Enseignant:
[  20]Une leçon peut avoid un exercice dans chacun de ses paragraphes
[  21]Un exercice
[  22]Les cours
[  23]Ajouter l'exercice à une leçon
[  24]Vérouiller l'exercice
[  25]Dévérouiller l'exercice
[  26]Voir l'exercice
[  27]Voir la leçon
[  28]Envoyer par email
[  29]La plate-forme de cours est utilisée pour créer des cours, les offrir aux participants, enregistrer leurs résultats et faciliter la communication entre les participants et leurs enseignants.\n\nUn exercice peut être composé d'un texte, d'une image ou d'une animation Flash, d'un fichier audio et d'une série de pages de questions.\n\nUn exercice peut aussi être inclus dans un cours.
[  31]Effacer le dernier cours importé
[  32]Dupliquer l'exercice
[  33]Cours:
[  34]Les exercices jetées à la corbeille
[  35]Afficher l'adresse web de l'exercice
[  36]L'adresse web de l'exercice est :
[  37]Pour créer un lien pointant vers cet exercice, copier et coller l'adresse ci-dessus dans l'attribut href d'un lien.
[  38]Donner un devoir
[  39]Les sujets
[  40]Imprimer l'exercice
[  41]Imprimer la leçon
[  42]Modifier l'exercice
[  43]Une semaine
[  44]Un mois
[  45]Trois mois
[  46]Six mois
[  47]Un an
[  48]Créé depuis:
[  50]Public
[  51]Protégé
[  52]Les leçons
[  53]Importer un cours ou un exercice
[  55]Sujet:
[  56]Pas encore publié
[  57]Précédant
[  58]Suivant
[  59]Sélectionner les exercices d'un certain niveau.
[  60]Statut:
[  61]Sélectionner les exercices d'une certaine catégorie.
[  62]Sélectionner les exercices d'un certain sujet.
[  63]Sélectionner les exercices d'un certain cours.
[  64]Sélectionner les exercices d'un certain statut.
[  65]Sélectionner les exercices d'une certaine période.
[  66]Déplacer après
[  70]Chercher:
[  71]Il peut devenir fastidieux d'avoir à naviguer dans la liste des exercices pour retrouver un exercice particulière.\n\nPour éviter cela, il est possible de saisir tout ou partie du nom d'un exercice et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera tous les exercices correspondant au texte recherché.
