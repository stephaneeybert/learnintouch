[   0]Ajouter un exercice à une leçon
[   1]Une leçon est composée d'une série de paragraphes.\n\nChaque paragraphe d'une leçon peut afficher un lien vers un exercice.
[   2]Paragraphe de leçon:
[   4]Nom:
[   5]Description:
[   6]Le paragraphe de la leçon est requis.
