[   0]Télécharger un fichier audio
[   6]Fichier audio:
[   3]Nom du fichier:
[   5]Sélectionner un fichier:
[   7]Effacer le fichier audio?
[  27]Aucun fichier audio n'a été spécifié.
[   1]Un exercice peut avoir un fichier audio.\n\nLe fichier audio est joué avant que l'utilisateur ne réponde aux questions de l'exercice.
[   2]Ko.
