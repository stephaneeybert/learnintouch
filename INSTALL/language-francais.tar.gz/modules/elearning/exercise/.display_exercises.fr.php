[   0]Les exercices
[   1]Chercher:
[   2]Il peut devenir fastidieux d'avoir à naviguer dans la liste des exercices pour retrouver un exercice particulière.\n\nPour éviter cela, il est possible de saisir tout ou partie du nom d'un exercice et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera tous les exercices correspondant au texte recherché.
[   3]Niveau:
[   4]Sélectionner les exercices d'un certain niveau.
[   5]Cours:
[   6]Sélectionner les exercices d'un certain cours.
[   7]Catégorie:
[   8]Sélectionner les exercices d'une certaine catégorie.
[   9]Sujet:
[  10]Sélectionner les exercices d'un certain sujet.
[  11]Rechercher des exercices...
[  12]Une leçon du cours
[  13]Un exercice du cours
[  14]Un exercice
[  15]Un exercice de la leçon
[  16]Les leçons et exercices d'un cours
