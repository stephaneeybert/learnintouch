[   1]Exercice
