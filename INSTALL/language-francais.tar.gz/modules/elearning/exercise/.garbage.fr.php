[   0]La corbeille
[   1]Vider la corbeille
[  11]Récupérer l'exercice
[   7]Name
[   6]Description
[   9]Lorsqu'un exercice est effacé, il est en fait stocké dans la corbeille.\n\nLes exercices peuvent être récupérés de la corbeille.\n\nVider la corbeille efface définitivement les exercices qui y sont stockés.
