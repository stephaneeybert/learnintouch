[   0]Vider la corbeille
[   2]Effacer définitivement tous les exercices de la corbeille?
