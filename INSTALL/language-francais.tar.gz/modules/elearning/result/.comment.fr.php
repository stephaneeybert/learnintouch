[   0]Ecrire un commentaire
[   1]Cacher le commentaire:
[   2]Par défaut le commentaire peut être lu par le participant.\n\nMais si le commentaire est sensible, il est possible de le cacher afin que le participant ne puisse pas le lire.\n\nDans ce cas, seul l'enseignant pourra voir le commentaire.
[   3]Envoyer le commentaire:
[   4]Commentaire:
[   5]Le commentaire peut être envoyé au participant.
[   6]Apres qu'un exercice a été fait, il est possible pour un enseignant d'ecrire un commentaire sur les résultats de l'exercice.
