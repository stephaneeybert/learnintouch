[   0]Nom de l'exercice:
[   1]Vous avez
[   2]Les résultats de votre exercice à
[   3]Date:
[   4]Description:
[   5]Un exercice de
[   6]a été fait
[   7]Le visiteur
[   8]a fait l'exercice
[   9]Le visiteur
[  10]Les résultats de l'exercice peuvent aussi être vus en
[  11]cliquer ici
[  12]cliquant ici
[  13]peut être contacté à
[  14]L'exercice avait une durée de
[  15]L'exercice a été fait en
[  16]Le visiteur a laissé le message:
[  17]Résultats d'exercice
[  18]Un commentaire sur vos résultats d'exercice à
[  20]Résultats de cours
[  21]Point(s)
[  22]point(s) pour
[  23]Classe:
[  24]Participant:
[  25]Faire l'exercice
[  26]réponse(s) correcte(s) sur
[  27]questions
[  28]Commentaire:
[  29]Vous n'avez pas répondu à
[  30]Vous avez répondu à
[  31]participant(s)
[  32]Vous pouvez
[  33]envoyer un commentaire de résultats
[  34]au participant.
[  35]Un enseignant a écrit le commentaire suivant:
[  36]Salutations
[  37]sur vos résultats pour l'exercice:
[  38]Le participant est inactif
[  39]Le participant a fini l'exercice
[  40]Note
[  41]La note est une lettre ou un texte qui représente la performance du participant.\n\nChaque note correspond à une plage de pourcentages.
[  42]Résultats
[  43]Les résultats sont le nombre de réponses correctes par le nombre de questions.
[  44]Points
[  45]Les points est le total de points pour les réponses correctes données par le participant.\n\nPar défaut, une réponse vaut un point, mais elle peut valoir plusieurs points.
