[   0]Envoyer les résultats de l'exercice
[   1]Nom:
[   3]Description:
[   4]Texte:
[   5]Email:
[   2]Envoyer les résultats de l'exercice?
[  10]Fait par:
[  25]Le:
[  19]Des résultats de l'exercice
[  20]Cher(e)
[  13]vous a envoyé les résultats de l'exercice:
[  18]Salutations
[   7]Email du destinataire:
[  17]Veuillez saisir l'adresse email du destinataire.
[   8]Nom du destinataire:
[  16]Vous pouvez saisir le nom du destinataire.
[  11]Email de l'expéditeur:
[  15]Vous pouvez saisir votre adresse email pour laisser votre contact au destinataire.
[  12]Nom de l'expéditeur:
[  14]Vous pouvez saisir votre nom pour signer l'envoi.
[  23]Message:
[  24]Vous pouvez saisir un message.
[  21]L'adresse email de l'expéditeur est requise.
[  39]Le format de l'adresse email de l'expéditeur est invalide.
[  45]Le suffixe de l'adresse email de l'expéditeur est invalide.
[  40]L'adresse email du destinataire est requise.
[  38]Le format de l'adresse email du destinataire est invalide.
[  44]Le suffixe de l'adresse email du destinataire est invalide.
