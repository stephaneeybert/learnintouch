[   0]Envoyer les résultats d'exercice
[   1]De l'exercice:
[   3]Fait par:
[   4]Le:
[   5]À:
[   2]Envoyer les résultats de l'exercice?
[   8]Exercice
[   6]Les résultats de l'exercice vous ont été envoyé.
[   9]Pour faire l'exercice, veuillez cliquer sur son nom:
[   7]Salutations
[  40]L'adresse email est requise.
[  38]Le format de l'adresse email est invalide.
[  10]Voir le contenu de l'exercice...
