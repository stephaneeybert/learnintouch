[   0]Effacer tous les résultats d'une inscription
[   1]Nom:
[   5]Inscription:
[   2]Effacer tous les résultats d'une inscription?
[   3]Email:
