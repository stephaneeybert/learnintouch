[   0]Les résultats des exercices
[   1]Note
[   2]Effacer tous les résultats de l'exercice
[   3]Effacer le résultat
[   4]Classe
[   5]Exercice
[   6]Imprimer les résultats
[   7]Enseignant:
[   8]Depuis:
[   9]Exercice:
[  10]Effacer tous les résultats de l'inscription
[  11]Session:
[  12]Participant:
[  13]Voir les résultats
[  14]Ecrire et envoyer un commentaire
[  15]La note est une lettre ou un texte qui représente la performance du participant.
[  16]L'exercice a été fait le
[  17]Exercice
[  18]Note moyenne du participant:
[  19]Les plages de résultats
[  20]Le participant s'est enregistré le
[  21]La note moyenne est la moyenne de toutes les notes des exercices.
[  22]Le participant n'est pas enregistré
[  23]Cours:
[  24]Classe:
[  25]Sans session
[  26]Note moyenne des participants:
[  27]Points
[  28]Envoyer par email
[  29]Les points est le total de points pour les réponses correctes données par le participant.\n\nPar défaut, une réponse vaut un point, mais elle peut valoir plusieurs points.
[  30]Résultats
[  31]Participant
[  32]Cours
[  33]L'inscription du participant
[  34]Les résultats sont le nombre de réponses correctes par le nombre de questions.
[  35]Réponses
[  36]Le nombre de réponses correctes et le nombre de réponses incorrectes.
[  37]Le graphe des résultats
[  43]Une semaine
[  44]Un mois
[  45]Trois mois
[  46]Six mois
[  47]Un an
[  48]Depuis:
[  70]Chercher:
[  71]Il peut devenir fastidieux d'avoir à naviguer dans la liste des résultats pour retrouver un résultat particulier.\n\nPour éviter cela, il est possible de saisir tout ou partie du nom d'une personne ou d'une adresse email et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera toutes les personnes correspondant au texte recherché.
