[   0]Modifier une plage de résultats
[   1]Note:
[   2]Haut:
[   3]La note est requise.
[   4]Chaque note est associée à une plage qui correspond à un pourcentage de réponses correctes.\n\nLa note peut être une lettre, comme A, B, C, etc... ou elle peut être un texte court, comme Très bien, Bien, etc...
[   6]Le pourcentage du haut de la plage est requis.
[  12]Le pourcentage du haut de la plage doit être compris entre 1 et 100.
[  14]Une plage est décrite par deux valeurs.\n\nSeule la valeur haute de la plage a besoin d'être spécifiée.\n\nLa valeur basse de la plage étant la valeur haute de la plage précédente.\n\nLa valeur doit être un nombre compris entre 1 et 100.
