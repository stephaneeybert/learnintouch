[   0]Les plages de résultats
[   1]Créer une plage
[   2]Modifier la plage
[   3]Effacer la plage
[   4]Note
[   5]Haut
[   9]Par défaut, les résultats d'exercices sone affichés en nombres de réponses correctes données par le participant.\n\nMais le nombre de réponses correctes n'est pas toujours la représentation la plus expressive.\n\nAfficher les résultats par une note, en utilisant une lettre ou un mot, peut être plus expressif.\n\nChaque note est associée à une plage qui correspond à un pourcentage de réponses correctes.\n\nPar exemple, la note 'A' peut être donnée pour un pourcentage de réponses correctes de 80 à 100, la note 'B' peut être donnée pour un pourcentage de réponses correctes de 60 à 79, etc...
