[   0]Effacer une plage de résultats
[   1]Max:
[   5]Note:
[   2]Effacer la plage de résultats?
