[   0]Effacer les résultats d'un exercice
[   1]Nom
[   5]Exercice:
[   2]Effacer les résultats de l'exercice?
[   3]Email
