[   0]Envoyer un commentaire
[   1]Envoyer un commentaire de résultat au participant.
[   2]Le commentaire a été envoyé au participant.
[   3]Envoyer
[   4]Commentaire:
[   5]Le commentaire est requis.
[   6]Apres qu'un exercice a été fait, il est possible pour un enseignant d'ecrire un commentaire sur les résultats de l'exercice.\n\nLe commentaire sera envoyé au participant et sauvegardé dans les résultats.
[   7]Vous n'êtes pas autorisé à voir ces résultats d'exercice.
