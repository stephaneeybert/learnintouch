[   0]Les résultats d'un exercice
[   1]Note
[   2]Exercice:
[   3]Fait:
[   4]L'exercice avait une durée de
[   5]L'exercice a été fait en
[   6]Imprimer les résultats
[   7]Message:
[   8]La note est une lettre ou un texte qui représente la performance du participant.
[   9]Points
[  10]Compréhension écrite
[  11]Expression écrite
[  12]Compréhension orale
[  13]Total
[  14]Aucun exercice n'a été trouvée pour les résultats.\n\nLes résultats ont été effacé.
[  15]Les points est le total de points pour les réponses correctes données par le participant.\n\nPar défaut, une réponse vaut un point, mais elle peut valoir plusieurs points.
[  16]Commentaire:
[  17]Ecrire et envoyer un commentaire
[  18]Un exercice
[  19]Effacer le résultat
[  20]point(s)
[  21]Solution(s):
[  22]Point(s):
[  23]Résultats 
[  24]Les résultats sont le nombre de réponses correctes par le nombre de questions.
[  25]Réponses
[  26]Le nombre de réponses correctes et le nombre de réponses incorrectes.
[  27]Participant:
[  28]Envoyer par email
[  29]Email:
[  30]Résultats en direct:
[  31]Il est possible de suivre la progression de l'exercice pendant que le participant répond aux questions.\n\nDans ce cas, les résultats des questions seront affichés au professeur pendant que le participant fait l'exercice.\n\nLe professeur pourra voir une progression graphique de chaque exercice.\n\nLes résultats en direct sont affichés seulement quand le participant est en ligne et en train de faire l'exercice.\n\nSi le participant est inactif alors un voyant se met à clignoter.\n\nSi le participant est absent alors rien n'est affiché.
