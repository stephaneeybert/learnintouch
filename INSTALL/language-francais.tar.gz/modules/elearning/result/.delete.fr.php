[   0]Effacer les résultats de l'exercice
[   1]Participant:
[   5]Exercice:
[   2]Effacer le résultat de l'exercice?
