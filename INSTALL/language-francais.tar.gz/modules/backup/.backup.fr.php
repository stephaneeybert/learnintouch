[   0]Sauvegarder le site web
[   1]Sauvegarde de la base de données dans un fichier archive.\n\nLe fichier archive a un format gzip.\n\nPour l'ouvrir sur un système Windows, veuillez utiliser un utilitaire comme WinZip.\n\nPour l'ouvrir sur un système Unix/Linux/OSX, veuillez utiliser les commandes gzip et tar.
[  15]Démarrer la sauvegarde
[   2]Structure des tables:
[   3]Données des table:
[   5]Format:
[   4]Une sauvegarde a été lancée.\n\nLe fichier de sauvegarde sera disponible dans quelques minutes.
[   6]Insert complet:
[  13]Si le champ est coché, alors les ordres SQL CREATE TABLE servant à recréer la structure des tables, sont inclus dans le fichier de sauvegarde.
[  12]Si le champ est coché, alors les ordres SQL INSERT servant à recréer les données des tables, sont inclus dans le fichier de sauvegarde.
[  11]Le fichier de sauvegarde peut avoir un format INSERT ou CVS. \n\nLe format INSERT remplit le fichier de sauvegarde avec des ordres SQL INSERT. \n\nLe format CVS remplit le fichier de sauvegarde avec des valeurs séparées par des virgules. \n\nNotez que le fichier au format CVS peut être lu par un tableur, comme MS Excel. \n\nLe format INSERT est recommandé pour une sauvegarde.
[  10]Si le champ est coché, alors les noms de champs apparaissent dans les ordres SQL INSERT.
