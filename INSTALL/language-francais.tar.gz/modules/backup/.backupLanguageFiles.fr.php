[   0]Sauvegarder les fichiers de langue
[   1]Sauvegarde des fichiers de langue dans un fichier archive.\n\nLe fichier archive a un format tar.\n\nPour l'ouvrir sur un système Windows, veuillez utiliser un utilitaire comme WinZip.\n\nPour l'ouvrir sur un système Unix/Linux/OSX, veuillez utiliser les commandes tar.
[  15]Démarrer la sauvegarde
[   8]Un problème est apparut et les fichiers de langue n'ont PAS pu être sauvegardés.
[   9]Contactez le responsable du site web
[   2]Langue:
