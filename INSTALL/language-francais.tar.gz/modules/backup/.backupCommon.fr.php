[   0]Sauvegarder la base de données
[   7]La base de données commune n'a PAS été sauvegardée
[   8]Un problème est apparut et la base de données commune n'a PAS été sauvegardée.
[   9]Contactez le responsable du site web
[  10]Seul un super administrateur peut sauvegarder la base de données commune.
