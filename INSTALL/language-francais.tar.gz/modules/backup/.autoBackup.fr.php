[   8]Un problème est apparut et la base de données n'a PAS pu être sauvegardé.
[   9]Contactez le responsable du site web
[   1]Sauvegarde du site web
[   2]Une sauvegarde du site web a été faite.
[   3]La sauvegarde peut être téléchargée à
[   4]cette page
