[   0]Exporter une table
[   1]Exporter une table dans un fichier texte CSV.
[   2]Tables:
[   8]Un problème est apparut et la table n'a PAS pu être exporté.
[   9]Contactez le responsable du site web
[  12]Les données du site web sont stockées dans un ensemble de tables d'une base de données.\n\nCes données peuvent être utiles à d'autres applications que le site web.\n\nLes données contenues dans chaque table de la base de données peuvent ainsi être exportées dans un fichier texte.\n\nCe fichier texte a un format CSV, lui permettant d'être lu par un tableur, comme par exemple MS Excel.
