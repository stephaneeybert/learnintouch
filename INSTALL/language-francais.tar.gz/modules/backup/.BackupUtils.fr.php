[   0]Envoyer un email à la sauvegarde automatique:
[   1]Lorsqu'une sauvegarde du site web est faite automatiquement, il est possible d'envoyer un email à l'adresse email du site web.\n\nL'email contient un lien vers la page offrant le fichier de sauvegarde en téléchargement.\n\nCela rappelle à l'administrateur du site web qu'une sauvegarde vient juste d'être faite.
[   2]Jamais
[   3]Chaque semaine
[   4]Chaque mois
[   5]Toujours
