[   0]Effacer un fichier de sauvegarde
[   1]Fichier:
[   2]Effacer le fichier?
[   3]Aucun fichier n'a été spécifié.
