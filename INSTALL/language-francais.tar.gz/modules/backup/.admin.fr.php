[   0]Les sauvegardes du site web
[   1]Créer un fichier de sauvegarde
[   2]Taille
[   3]Effacer le fichier de sauvegarde
[   4]Sauvegarde de la base de données
[   5]Date
[   6]Sauvegarde du site web:
[   7]Exporter une table de la base de données
[   8]Télécharger le fichier
[   9]Sauvegarder la base de données commune
[  10]Le répertoire contenant les fichiers de backup n'a pu être ouvert.
[  11]Sauvegarder les fichiers de langue
[  12]Une sauvegarde totale du contenu du site web peut être créee et téléchargée.\n\nCela permet la conservation en lieu sûr du contenu du site web.\n\nUne sauvegarde automatique des données du site web est faite tous les jours.\n\nLes données du site web sont stockées dans une base de données et dans un répertoire.\n\nLe texte est stocké dans une base de données, et les fichiers, comme les images, les fichiers audios, etc... sont stockés dans le répertoire.\n\nComme ces données peuvent représenter une somme assez importante de travail, en créer une copie de sauvegarde peut s'avérer une bonne chose à faire!\n\nFaire une sauvegarde des données du site web est un processus en deux temps.\n\nPremièrement, il faut créer un fichier de sauvegarde.\n\nLe fichier de sauvegarde apparaitra en haut de la liste des fichiers de sauvegardes.\n\nDeuxièmement, il faut télécharger le fichier de sauvegarde en clickant sur son nom.\n\nAprès que le téléchargement soit terminé, une copie du fichier de sauvegarde repose maintenant dans votre ordinateur.\n\nC'est une trés bonne chose de toujours avoir en permanence un fichier de sauvegarde à jour!
[  13]La sauvegarde est en préparation...
[  14]Les préférences
[  15]Taille:
