[   0]Télécharger un fichier favicon
[   3]Nom du fichier:
[   2]Sélectionner un fichier:
[   7]Effacer le fichier?
[  10]Un favicon est un fichier affiché devant le nom du site web dans le navigateur.\n\nIl est aussi affiché devant le nom du site web dans la liste des signets du navigateur.\n\nUn fichier favicon n'est pas exactement un fichier image.\n\nIl a un format de fichier spécifique et doit être nommé favicon.ico\n\nPour afficher un favicon, veuillez créer un fichier favicon.ico et le télécharger vers le serveur.\n\nLa largeur de l'image doit être un multiple de 8 et inférieure à 256 et la hauteur de l'image doit être inférieure à 256.
