[   0]Télécharger un logo d'application iPhone / iPod
[   1]Image:
[   2]Sélectionner un fichier:
[   3]Nom du fichier:
[   7]Effacer le fichier?
[  10]Un logo d'application est une image affichée comme une icône dans un iPhone ou un iPod.\n\nCliquer sur l'image démarre l'application.\n\nL'image doit avoir un format .png avec une largeur de 57 et une hauteur de 57.
