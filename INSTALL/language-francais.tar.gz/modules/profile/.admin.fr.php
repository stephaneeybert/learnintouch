[   0]Le profil
[   1]Le profil du site web est un ensemble d'informations utilisées pour décrire et identifier le site web.\n\nCes informations sont aussi utilisées pour identifier le site web en cas de communication avec les utilisateurs visitant le site web.\n\nElles sont souvent utilisées par les moteurs de recherche pour référencer le site web.\n\nIl est important que ces informations sont correctes.
[   2]Télécharger le logo du site web
[   3]Télécharger le fichier favicon du site web
[   4]Nom
[   5]Valeur
[   6]Télécharger le plan d'accès
[   7]Télécharger l'icône d'application iPhone/iPod
[  10]Les préférences
