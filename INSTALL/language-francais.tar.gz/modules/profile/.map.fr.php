[   0]Télécharger une carte
[   3]Nom de l'image:
[   1]Image:
[   2]Sélectionner une image:
[   7]Effacer l'image?
[  10]La carte d'accès est utilisée pour aider les gens à localiser les locaux de la société ou de l'organisation.\n\nHabituelement, une telle carte peut être trouvée dans le site web du répertoire téléphonique.
