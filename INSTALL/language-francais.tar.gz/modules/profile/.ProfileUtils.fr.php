[   1]Nom du site web:
[   2]Adresse:
[   3]Facebook API key:
[   4]L'identifiant Facebook API key est un identifiant unique attribué par Facebook lors de l'enregistrement d'une nouvelle application dans la plate-forme Facebook.\n\nIl se trouve dans le site web www.facebook.com à http://www.facebook.com/developers/apps.php -> API Key\n\nPour créer une application Facebook, veuillez aller à la page http://www.facebook.com/developers/apps.php et vous assurer que l'information suivante est spécifiée:La Site URL devrait être : http://[votre nom de domaine]/engine/system/social/facebook/\n- La Canvas Page devrait être : http://apps.facebook.com/[votre nom d'application]/\n- La Canvas URL devrait être : http://[votre nom de domaine]/engine/system/social/facebook\n\nAprès cela, vous devez rafraichir les modèles de votre site web.
[   5]Facebook application secret:
[   6]Téléphone:
[   7]Fax:
[   8]Adresse email du site web:
[   9]Nom du webmestre:
[  10]Adresse email du webmestre:
[  11]L'identifiant Facebook application secret est un identifiant unique attribué par Facebook lors de l'enregistrement d'une nouvelle application dans la plate-forme Facebook.\n\nIl se trouve dans le site web www.facebook.com à http://www.facebook.com/developers/apps.php -> Application Secret\n\nAprès cela, vous devez rafraichir les modèles de votre site web.
[  12]L'adresse postale de la société ou de l'organistation.
[  13]Facebook application id:
[  14]L'identifiant Facebook application id est un identifiant unique attribué par Facebook lors de l'enregistrement d'une nouvelle application dans la plate-forme Facebook.\n\nIl se trouve dans le site web www.facebook.com à http://www.facebook.com/developers/apps.php -> Application ID\n\nAprès cela, vous devez rafraichir les modèles de votre site web.
[  15]Description pour sites web sociaux:
[  16]Une brève description du contenu et/ou de l'objectif du site web utilisée lors de la publication de messages sur les sites web sociaux comme Facebbok.
[  17]Droit d'auteur:
[  18]Le numéro de téléphone de la société ou de l'organistation.
[  19]Le numéro de fax de la société ou de l'organistation.
[  20]Référencement du site web
[  21]Il est important d'aider les moteurs de recherche à référencer le site web.\n\nUne partie de l'activité des moteurs de recherche est de lire le titre, la description et les mots clés détaillant l'objet du site web.
[  22]Titre:
[  23]Le titre du site web est affiché dans la bordure haute de la fenètre du navigateur et est utilisé comme signet.\n\nSi aucun titre n'est spécifié alors le nom de domaine du site web est utilisé comme titre.\n\nAfficher un titre de site web peut être plus informatif qu'un nom de domaine.\n\nLe titre peut aussi être utilisé par certains moteurs de recherche pour référencer le site web.
[  24]Description:
[  25]Une brève description du contenu et/ou de l'objectif du site web.\n\nLa description est utilisée par les moteurs de recherche pour référencer le site web.
[  26]Mot-clés:
[  27]Quelques mots clé sur le contenu et/ou les objectifs du site web.\n\nLes mots clés sont utilisés par les moteurs de recherche pour référencer le site web.
[  28]Google Analytics:
[  29]Google Analytics est un service offert par Google pour suivre les visiteurs d'un site web.\n\nPour ouvrir un compte, un morceau de code source fournit par Google Analytics, doit être inclus dans le site web.\n\nVeuillez copier et coller ce code source dans ce champ.\n\nVeuillez ensuite vérifier qu'il apparait dans le site web.\n\nPour cela, allez sur le site web, faites un clic droit et sélectionnez l'option de menu pour voir le code de la page.\n\nGoogle Analytics est disponible à http://www.google.com/analytics/features.html\n\nAprès cela, vous devez rafraichir les modèles de votre site web.
[  30]Termes du service:
[  31]Les termes du service est un message aux utilisateurs du site web.\n\nLes termes du service sont affichés sur la page d'enregistrement d'un utilisateur.\n\nIl est aussi recommandé d'afficher sur le site web, un lien vers la page des termes du service.
[  32]Message d'invitation:
[  33]Il est possible, pour un visiteur du site web, d'envoyer par email un message d'invitation à tous ses amis.\n\nBien que le visiteur puisse saisir le message, un texte peut être suggéré au visiteur.
[  34]Regarde ce site web
[  35]Twitter id:
[  36]L'identifiant Twitter est le nom de connexion d'un compte Twitter.
[  37]LinkedIn API Key:
[  38]L'identifiant LinkedIn API Key est un identifiant unique attribué par LinkedIn lors de l'enregistrement d'une nouvelle application dans la plate-forme LinkedIn.\n\nIl se trouve dans le site web www.linkedin.com à https://www.linkedin.com/secure/developer -> Add New Application\n\nAprès cela, vous devez rafraichir les modèles de votre site web.
[  39]Google Api Key:
[  40]L'identifiant Google Api Key est un identifiant unique attribué par Google lors de l'enregistrement d'une nouvelle application dans la plate-forme Google.\n\nIl est obtenu après l'enregistrement du site web.
[  41]Google Client Id:
[  42]L'identifiant Google Client Id est un identifiant unique attribué par Google lors de l'enregistrement d'une nouvelle application dans la plate-forme Google.\n\nIl est obtenu après l'enregistrement du site web.
[  43]Google Client Secret:
[  44]L'identifiant Google Client Secret est un identifiant unique attribué par Google lors de l'enregistrement d'une nouvelle application dans la plate-forme Google.\n\nIl est obtenu après l'enregistrement du site web.
[  45]\n\nEnregistrement du site web à Google:\nVeuillez aller à la Google console https://code.google.com/apis/console/\nVeuillez cliquer dans le menu à gauche sur l'élément "Services" et activer le service "Google+ API".\nVeuillez cliquer dans le menu à gauche sur l'élément "API Access"\nVeuillez cliquer sur le bouton "Create an OAuth 2.0 client ID"\nDans le champ "Product name:" veuillez saisir le nom de votre site web.\nDans le champ "Product logo:" veuillez coller l'url vers l'image du logo de votre site web.\nL'url vers l'image du logo de votre site web est:
[  46]\nVeuillez cliquer sur le bouton "Update" pour afficher votre logo.
[  47]\n\nEnregistrement du site web à Twitter:\nVeuillez aller à la page https://dev.twitter.com/apps\nVeuillez cliquer sur le bouton "Create a new application".\nVeuillez remplir le formulaire.
[  48]\nDans le champ "Redirect URIs:" veuillez saisir l'url de connexion dans votre site web, qui est:
[  49]\nVeuillez cliquer sur le bouton "Next".\nVeuillez sélectionner l'option "Web application".\nDans le champ "Hostname", veuillez sélectionner le protocol "http://" et saisir le nom de domaine de votre site web.\nVeuillez cliquer sur le bouton "Create client ID".\nVeuillez copier et coller les valeurs "Client ID" et "Client secret" dans le profil de votre site web.
[  50]Twitter consumer key:
[  51]La Twitter consumer key est donnée par Twitter lors de l'enregistrement d'une application.
[  52]Twitter consumer secret:
[  53]Le Twitter consumer secret est donné par Twitter lors de l'enregistrement d'une application.
[  54]\nDans le champ "Callback URL:" veuillez saisir l'url de connexion dans votre site web, qui est:
[  55]\nVeuillez copier et coller les valeurs "Twitter consumer key" et "Twitter consumer secret" dans le profil de votre site web.
[  56]Javascript dans le body:
[  58]Mail SMTP Host:
[  59]Le nom de host du serveur SMTP. Le fournisseur mandrill.com est une solution possible.
[  60]Mail SMTP Port:
[  61]Le numéro de port du serveur SMTP.
[  62]Mail SMTP Nom d'utilisateur:
[  63]Le nom d'utilisateur pour le serveur SMTP.
[  64]Mail SMTP Mot de passe:
[  65]Le mot de passe pour le serveur SMTP.
[  57]Il est possible d'insérer du javascript à la fin de l'élément body de la page.
[ 101]Le nom du site web peut être un nom de société ou d'organistation.
[ 108]L'adresse email du site web est utilisée pour toute les communications par email avec les utilisateurs et les administrateurs du site web.\n\nIl est donc important de saisir une adresse email valide.
[ 109]Le prénom et le nom de famille du webmestre.\n\nLe webmestre est la personne en charge du site web.
[ 110]L'adresse email du webmestre est utilisée pour rendre compte au webmestre des problèmes survenant sur le site web.\n\nIl est donc important de saisir une adresse email valide.\n\nBien qu'il soit préférable que le webmestre ai sa propre adresse email, cette adresse email peut être la même que celle du site web.
[ 111]Les noms meta suivants sont utilisés dans la section HTML HEAD du site web.\n\nCes informations sont utilisées pour identifier le site web.
[ 117]La notice des droits d'auteur protegeant le contenu et matériel du site web.\n\nIl est recommandé d'afficher une notice de droits d'auteur lors de la publication de matériel sur un site web.
