[   0]Télécharger un logo
[   1]Image:
[   2]Sélectionner une image:
[   3]Nom de l'image:
[   4]Url de l'image:
[   7]Effacer l'image?
[  10]Le logo du site web est utilisé pour identifier le web site.\n\nIl peut, par exemple, être utilisé dans une signature, lors de l'envoi d'un email aux utilisateurs.
