[   0]Les formats de photos
[   1]Créer un format
[   2]Modifier le format
[   3]Effacer le format
[   5]Nom
[   6]Description
