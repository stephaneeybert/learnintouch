[   0]Effacer un format
[   1]Nom:
[   5]Description:
[   2]Effacer le format?
[   3]Le format est utilisé par des photos.\n\nEffacer d'abord les photos pour pouvoir ensuite effacer le format.
