[   0]Modifier un format
[   4]Nom:
[   1]Prix:
[   3]Si le prix est spécifié alors il est le prix unitaire pour toutes les photos dans le format.
[   5]Description:
[   6]Le nom est requis.
[   2]Le nom est déjà utilisé par un autre format de photo.
