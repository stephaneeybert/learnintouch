[   0]Effacer une photo
[   1]Référence:
[   3]Description:
[   2]Effacer la photo?
[   6]Image:
