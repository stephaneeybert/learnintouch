[   0]Télécharger un album
[   1]Les images 'gif' ne sont pas supportées.\n\nCe format d'image est protégé par un brevet.\n\nVeuillez transformer vos images 'gif' en images 'jpg'.
[   2]Sélectionner un fichier:
[   3]Le nom du fichier archive est incorrect.\n\nUn nom de fichier doit être composé des lettres a-zA-Z seulement.
[   4]Un album de photos avec le nom
[   5]existe déjà.
[   6]Remplacer l'album existant
[   7]Ajouter à l'album existant
[   8]Album existant:
[   9]Description:
[  10]La description est affichée lorsque le curseur de la souris passe au dessus de la photo.\n\nToutes les photos téléchargées auront la même description.
[  11]Mots-clés:
[  12]Une photo peut avoir des mots-clés.\n\nCeux-ci sont des labels qui peuvent aider à catégoriser une photo et rendre sa recherche plus facile.\n\nUn mot-clé doit être un mot.\n\nChaque mot-clé doit être séparé par un espace.\n\nToutes les photos téléchargées auront les mêmes mots-clés.
