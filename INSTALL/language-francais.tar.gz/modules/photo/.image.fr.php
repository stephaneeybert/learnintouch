[   0]Télécharger une image
[   6]Image:
[   5]Album:
[   3]Nom de l'image:
[   2]Sélectionner une image:
[   8]Il n'y a actuellement pas d'albums de photos.\n\nVeuillez créer un album de photo avant d'insérer des photos.
[   4]Veuillez sélectionner un album de photos pour télécharger la photo.\n\nUne photo doit appartenir à un album de photos.\n\nSi aucun album de photos n'est sélectionné alors la photo ne peut pas être téléchargée.
[   1]Les images 'gif' ne sont pas supportées.\n\nCe format d'image est protégé par un brevet.\n\nVeuillez transformer vos images 'gif' en images 'jpg'.
[   7]Redimensioner à la largeur:
[   9]Lors du téléchargement vers le serveur, une image peut être redimensionée à une certaine largeur.\n\nSi aucune largeur n'est spécifiée. alors l'image n'est pas redimensionée.\n\nLa largeur par défaut est prise de la plus grande largeur d'image dans les préférences.

