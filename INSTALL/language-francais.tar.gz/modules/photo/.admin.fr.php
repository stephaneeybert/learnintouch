[   0]Les albums de photos
[   1]Créer une photo
[   2]Modifier la photo
[   3]Effacer la photo
[   4]Télécharger un album complet
[   5]Les formats de photos
[   6]Les albums
[   7]Changer l'image
[   9]Album:
[  10]Intervertir avec le suivant
[  11]Intervertir avec le précédent
[  12]Référence:
[  13]Les albums de photos permettent l'affichage de photos.\n\nLes photos sont rangées dans des albums et elles peuvent être affichées dans des diaporamas.
[  14]Nom:
[  20]Les préférences
[  70]Chercher:
[  71]Il peut devenir fastidieux d'avoir à naviguer dans la liste des photos pour retrouver une photo particulière.\n\nPour éviter cela, il est possible de saisir tout ou partie de la référence, du nom, de la description, du commentaire, du prix d'une photo et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera toutes les photos correspondant au texte recherché.
