[   0]Sélectionner un album de photos
[   1]Cycle de photos d'un album:
[   2]List de photos d'un album:
