[   0]Album photo:
[   1]Aucun album de photos n'a été trouvé.
[   2]Voir l'album photo
[   3]Cycle de photos:
[  52]Recherche détaillée dans la liste des albums de photos
[ 101]Retour à la liste des albums de photos
