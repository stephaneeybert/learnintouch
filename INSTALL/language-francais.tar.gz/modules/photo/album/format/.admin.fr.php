[   0]Les formats de photos d'un album
[   1]Ajouter un format à l'album
[   2]Modifier le format
[   3]Effacer le format
[   4]Les formats de photos
[   5]Nom
[   7]Prix
[   8]Album photo:
[   9]Les formats d'un album sont utilisés pour spécifier les prix des photos pour un format donné d'un album donné.\n\nLes photos d'un album ont un prix identique par format.
