[   0]Effacer un format d'un album
[   4]Album:
[   1]Prix:
[   2]Effacer le format de l'album?
[   5]Format:
[   8]Le format choisi est déjà utilisé par un autre album.\n\nVeuillez choisir un autre format.
