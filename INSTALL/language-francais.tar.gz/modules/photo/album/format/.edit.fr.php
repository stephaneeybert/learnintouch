[   0]Modifier un format
[   4]Album:
[   1]Prix:
[   3]Le prix d'une photo pour toutes les photos dans le format pour l'album.
[   5]Format:
[   6]Le prix est requis.
[   7]Le format est requis.
[   2]Le prix doit être numérique.
[   8]Le format choisi est déjà utilisé par un autre album.\n\nVeuillez choisir un autre format.
