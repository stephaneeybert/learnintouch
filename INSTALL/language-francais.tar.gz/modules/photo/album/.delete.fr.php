[   0]Effacer un album
[   1]Nom:
[   5]Event:
[   2]Effacer l'album?
[   4]Effacer les photos de l'album
[   6]Confirmer:
[   3]L'album contient des photos.\n\nEffacer d'abord les photos pour pouvoir ensuite effacer l'album.
