[   0]Les albums de photos
[   1]Créer un album
[   2]Modifier l'album
[   3]Effacer l'album
[   4]Lieu
[   5]Nom
[   6]Event
[   7]Date
[   8]Les formats de photos de l'album
[   9]Les photos de l'album
[  10]Intervertir avec le suivant
[  11]Intervertir avec le précédent
[  12]Télécharger un album complet
