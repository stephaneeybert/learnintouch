[   0]Modifier un album
[   2]Le nom est déjà utilisé par un autre album photo.
[   3]Lieu:
[   4]Nom:
[   5]Event:
[   6]Le nom est requis.
[   7]Si le prix est spécifié alors il est le prix unitaire pour toutes les photos de l'album.
[   8]Date de publication:
[   9]Prix:
[  10]Cacher:
[  11]L'album de photos peut être caché.\n\nDans ce cas, il ne sera pas affiché dans la liste des albums.
[  12]Pas de diaporama:
[  13]Par défaut, les photos sont affichées dans un diaporama lors d'un clic sur une photo.\n\nMais il est possible de ne pas les afficher dans un diaporama.\n\nDans ce cas les photos seront simplement affichées dans un format large.
[  14]Pas de zoom:
[  15]Par défaut, les photos sont zoomables.\n\nMais il est possible de ne pas afficher un zoom de la photo dans sa taille originelle lorsque la souris passe au dessus de la photo.\n\nVeuillez noter que cela n'a de sens que si la photo originelle est plus grande que celle affichée.
[  21]Une date doit avoir le format
