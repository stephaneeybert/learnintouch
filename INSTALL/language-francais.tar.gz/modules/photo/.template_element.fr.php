[   0]Un cycle de photos d'un album
[   1]Album de photos:
