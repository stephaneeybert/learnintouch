[   0]Modifier une photo
[   1]Prix:
[   2]Commentaire:
[   3]La description est affichée lorsque le curseur de la souris passe au dessus de la photo.
[   4]Une photo peut avoir un prix de vente.\n\nSi les photos sont mises en vente alors un prix doit être déterminé pour chaque photo.\n\nAfin d'éviter d'avoir à saisir le prix de chaque photo lors de la mise en vente d'un album de photos, il est possible de spécifier le prix des photos par format d'un album de photo, par album de photo et par format de photo.\n\nLe prix d'une photo est ainsi déterminé dans l'ordre suivant:\n\n1- Le prix spécifié pour la photo.\n2- Autrement, le prix spécifié pour le format de l'album contenant la photo.\n3- Autrement, le prix spécifié pour l'album contenant la photo.\n4- Autrement, le prix spécifié pour le format de la photo.
[   5]Album:
[   6]Référence:
[   7]Description:
[   8]Adresse web:
[   9]Le commentaire est affiché en dessous de la photo.
[  10]La référence est affichée en dessous de la photo.
[  11]Une photo peut avoir une adresse web.\n\nDans ce cas, cliquer sur la photo ouvre une nouvelle fenètre du navigateur affichant un site web ou une page web.
[  12]Nom:
[  13]Une photo peut avoir un nom.
[  14]Format:
[  15]Veuillez sélectionner un album de photos pour la photo.\nUne photo doit appartenir à un album de photos.
[  16]Mots-clés:
[  17]Une photo peut avoir des mots-clés.\n\nCeux-ci sont des labels qui peuvent aider à catégoriser une photo et rendre sa recherche plus facile.\n\nUn mot-clé doit être un mot.\n\nChaque mot-clé doit être séparé par un espace.
[  21]Une adresse web doit commencer avec la séquence 'http://' ou 'www'.
