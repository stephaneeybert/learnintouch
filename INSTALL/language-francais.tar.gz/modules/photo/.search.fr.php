[   0]Rechercher
[   5]Référence:
[  13]Texte:
[  14]Il est possible de rechercher un album de photos contenant un texte particulier.\n\nLe résultat de la recherche affiche les albums de photos dont le nom, l'évènement ou le lieu contienent le texte saisi.
[  15]Il est possible de rechercher un album de photos en utilisant une référence de photo.
[  16]Il est possible de rechercher les albums de photos qui ont été publiés depuis une certaine période.
[  21]Choisir...
[  29]Retour à la liste des albums de photos
[  43]Une semaine
[  44]Un mois
[  45]Trois mois
[  46]Six mois
[  47]Un an
[  48]Depuis:
