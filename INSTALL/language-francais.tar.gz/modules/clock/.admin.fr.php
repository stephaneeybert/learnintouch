[   0]Le réglage de l'heure
[   1]Il se peut que votre heure locale soit différente de l'heure du système.\n\nDans ce cas, vous pouvez spécifier le décallage horaire entre votre heure locale et l'heure du système.\n\nVeuillez choisir le décallage horaire pour obtenir une heure locale correcte.
[   2]L'heure du système:
[   3]corrigée par le décallage horaire de:
[   4]donne l'heure locale:
[   5]et la date locale:
[   6]Les préférences
