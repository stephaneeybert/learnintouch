[   1]Le format d'affichage de la date:
[   2]La langue de la date:
[   3]La date peut être affichée dans un format utilisant des mots pour le jour et le mois.\n\nDans ce cas, la langue par défaut du site web est utilisé pour afficher la date.\n\nMais il est possible de choisir une autre langue pour l'affichage de la date.\n\nVeuillez noter que cette langue n'est pas utilisée par l'interface d'administration du site web.
[  10]Le format de l'heure:
[  27]Le format numérique de la date:
[  32]Le format numérique de la date est seulement utilisé dans l'interface d'administration du site web.\n\nLe format numérique de la date n'est pas utilisé dans les pages du site web.\n\nIl offre aux administrateurs du site web un format de leur choix.\n\nIl y a un format pour le type de date Americain et un format pour le type de date Européen.
[  33]Il y a un large choix de formats de date.\n\nThe format de date choisit est utilisé pour afficher la date sur les pages du site web.\n\nIl n'est pas utilisé par les administrateurs dans l'interface d'administration du site web.
[  35]Il y a plusieurs choix de format de l'heure.
