[   0]Réinitialiser les images
[   1]Réinitialiser les images?
