[   0]Réinitialiser une image (téléphone)
[   6]Image:
[   7]Réinitialiser l'image?
