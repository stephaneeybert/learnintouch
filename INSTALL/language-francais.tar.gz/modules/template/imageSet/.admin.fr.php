[   0]Les images de navigation
[   1]Sur certaines pages, le site web affiche des images de navigation.\n\nIl est possible de remplacer ces images par défaut par des images personalisées.\n\nPour personaliser le jeu d'images sélectionné, veuillez simplement télécharger un fichier image pour chaque image du jeu.\n\nChaque image personalisée remplacera l'image standard du jeu sélectionné.
[   2]Télécharger une image
[   3]Réinitialiser les images
[   4]Ordinateur
[   5]Insérer ou effacer une image pour ordinateur
[   6]Réinitialiser l'image pour ordinateur
[   7]Réinitialiser l'image pour téléphone
[   8]Téléphone
[   9]Insérer ou effacer une image pour téléphone
