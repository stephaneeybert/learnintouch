[   0]Télécharger une image (téléphone)
[   2]Sélectionner une image:
[   3]Nom de l'image:
[   6]Image:
[   7]Effacer l'image?
[  27]Aucune image n'a été spécifiée.
