[   0]Réinitialiser une image (ordinateur)
[   6]Image:
[   7]Réinitialiser l'image?
