[   0]Recherche...
[   1]Un journal
[   2]Les documents offerts en téléchargement
[   3]Une personne
[   4]Un article de journal
[   5]Une page web
[   6]Le cycle d'images clients
[   7]Une photo
[   8]Le cycle des liens favoris
[   9]Le cycle de photos d'un album
[  10]L'enregistrement de l'adresse email d'un visiteur
[  11]Les références clients
[  12]Le livre d'or
[  13]Les gens
[  14]Les liens favoris
[  15]L'enregistrement du numéro SMS d'un visiteur
[  16]La recherche de photos
[  17]Les photos d'un album
[  18]Un document
[  19]Le formulaire de contact
[  20]Le coin du prof
[  21]L'édition du profil de l'utilisateur
[  22]Un exercice
[  23]La connexion de l'utilisateur
[  24]Le changement du mot de passe de l'utilisateur
[  25]Le formulaire du livre d'or
[  26]Le désabonnement de l'utilisateur
[  27]L'enregistrement de l'utilisateur
[  28]La déconnexion de l'utilisateur
[  29]Les publications
[  30]Les journaux
[  31]Les langues
[  32]Une publication
[  33]Le moteur de recherche
[  34]Les articles de la boutique
[  35]Un article de la boutique
[  36]Toutes les commandes d'achats d'un utilisateur
[  37]L'envoi du mot de passe de l'utilisateur
[  38]La liste des enseignants
[  39]Le panier d'achats
[  40]La recherche des articles de la boutique
[  41]La sélection d'articles de l'utilisateur
[  42]Les albums de photos
[  43]Un formulaire
[  44]Les résultats d'un exercice
[  45]L'entrée du site web
[  46]La post-connexion utilisateur
[  47]Modèle des fenètres popup:
[  48]Les fenètres popup peuvent être affichées dans leur propre modèle.\n\nCela permet un affichage qui est différent du modèle principal du site web.
[  49]Aperçu du modèle avec du contenu brouillon:
[  50]Rafraîchir le modèle
[  51]Lors de l'affichage de l'aperçu du modèle, par défaut le modèle est vide et n'affiche pas de page web.\n\nMais il est possible d'afficher du contenu brouillon dans l'aperçu du modèle.\n\nCela permet d'avoir un aperçu du modèle plus réaliste.
[  52]Le modèle a été rafraîchi!
[  53]Rafraîchissement du modèle en cours...
[  54]Les participants d'un enseignant
[  55]Une leçon
[  56]Les devoirs d'un participant
[  57]Les inscriptions au cours d'un participant
[  58]La notice des termes du service
[  59]Enregistrer
[  60]Inscription
[  61]Laissez nous votre numéro de téléphone portable (SMS)
[  63]Numéro:
[  64]L'invitation d'amis
[  65]Modèle des fenètres popup (téléphone):
[  66]Nos exercices et nos cours
[  67]Nos leçons et nos cours
