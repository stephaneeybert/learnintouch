[   0]Un élément de modèle
[   1]Ajouter une langue 
[   2]en
[   3]Effacer l'élément
[   4]Langue
[   7]Un élément de modèle est du contenu affiché dans un modèle de site web.
[  10]Image/Texte
[  13]Pour toutes les langues
[  14]Fermez la fenètre
[  15]pour la langue
[  22]Modifier l'élément
