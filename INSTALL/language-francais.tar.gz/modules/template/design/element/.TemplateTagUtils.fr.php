[   0]Le lien de navigation
[   1]La barre de navigation
[   2]Les éléments du milieu de la barre de navigation
[   3]Le menu de navigation
[   4]Le menu d'en-tête
[   5]Les menus
[   6]Les éléments des sous menus
[   7]Les separateurs d'éléments
[   8]Les éléments sans menu
[   9]Les pages web
[  10]Les miettes de pain des pages web
[  11]L'arborescence des pages web
[  12]Le texte
[  13]Un article
[  14]La date
[  15]L'heure
[  16]L'animation Flash
[  17]Le sélecteur de langues
[  18]Un drapeau
[  19]La connexion utilisateur
[  20]Le nom de connexion
[  21]Le mot de passe
[  22]Le bouton de validation
[  23]Le lien inscription
[  24]Le lien connexion
[  25]Le lien profil
[  26]Le lien mot de passe
[  27]Le lien déconnexion
[  28]L'inscription email
[  29]Le cycle d'images
[  30]Un texte
[  31]Un libellé de champ
[  32]Une champ de saisie
[  33]La dernière mise à jour
[  34]Le journal
[  35]Le titre
[  36]L'image d'en-tête
[  37]Le titre d'article
[  38]Une date de publication
[  39]Le logo rss
[  40]L'adresse du site web
[  41]Le contenu de la page
[  42]Les images des éléments
[  43]L'image du lien de navigation
[  44]L'images d'un drapeau
[  45]La bordure de l'image d'en-tête
[  46]La bordure d'un champ de saisie
[  47]Le téléphone du site web
[  48]Le moteur de recherche
[  49]La source RSS
[  50]Le champ de recherche
[  51]La bordure du champ
[  52]Un article
[  53]Les éléments du milieu du menu d'en-tête
[  54]Les images des éléments du menu d'en-tête
[  55]Les images des éléments des menus
[  56]Le premier élément de la barre de navigation
[  57]Le dernier élément de la barre de navigation
[  58]La page courante
[  59]Le titre d'un article
[  60]Le titre de la source RSS
[  61]Le premier élément du menu d'en-tête
[  62]Le dernier élément du menu d'en-tête
[  63]L'image d'un article
[  64]La bordure de l'image d'un article
[  65]Le titre du menu
[  66]Une image
[  67]Le fax du site web
[  68]La notice des droits d'auteur du site web
[  69]L'élément
[  70]Le titre pour la recherche d'évènements
[  71]Un label pour la recherche d'évènements
[  72]Un bouton radio pour la recherche d'évènements
[  73]Un champ de saisie pour la recherche d'évènements
[  74]La période pour la recherche d'évènements
[  75]Les articles
[  76]Le lien d'affichage pour la recherche d'évènements
[  77]La boite de recherche d'évènements
[  78]Un message de résultat
[  79]Une liste select pour la recherche d'évènements
[  80]Le lexique
[  81]Le lien pour lire la suite
[  82]L'extrait d'un journal
[  83]Le calendrier
