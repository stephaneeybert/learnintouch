[   0]Composer le style d'un élément
[   1]Effacer le style du tag
[   3]Fermer la page
[   4]Compose the style
[   5]Etes vous sur de vouloir SUPPRIMER le style ?
