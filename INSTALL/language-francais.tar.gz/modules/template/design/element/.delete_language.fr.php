[   0]Effacer la langue
[   1]Langue:
[   2]Effacer la langue?
[   3]Pour toutes les langues
