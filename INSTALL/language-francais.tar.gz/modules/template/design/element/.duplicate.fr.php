[   0]Dupliquer un élément
[   1]Type:
[   2]Veuillez choisir un conteneur dans lequel dupliquer l'élément.
[   3]Conteneur:
[   4]Le conteneur de destination qui va recevoir l'élément.
[   7]Dupliquer l'élément?
