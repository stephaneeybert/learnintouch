[   0]Composer le style de
[   1]Effacer le style du tag
[   3]Veuillez vous assurer que la page contient du contenu avant de composer son style.\n\nPar exemple, pour un journal, veuillez vérifier que celui ci est publié.\n\nOu pour une galerie de photos, veuillez vérifier qu'elle contient quelques photos.\n\nPour chaque page, assurez vous que la page affiche du contenu avant de vouloir éditer son style.
[   4]Composer le style pour
[   5]Etes vous sur de vouloir SUPPRIMER le style ?
