[   1]Effacer le style
[   0]Effacer le style d'une page
[   2]Fermer la fenètre
[   3]Effacer le style de la page:
[   4]Il n'y a pas de style à effacer.
