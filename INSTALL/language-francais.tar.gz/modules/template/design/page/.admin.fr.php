[   0]Composer le style des pages pré-formatées
[   1]Composer le style de la page
[   4]Effacer le style de la page
