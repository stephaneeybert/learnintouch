[   0]La page
[   1]Le titre
[   2]Une ligne de commentaire
[   3]Un message d'avertissement
[   4]Un libellé pour un champ de formulaire
[   5]Le contenu d'une bulle d'aide
[   6]Le bouton de validation
[   7]Le bouton d'annulation
[   8]Le contenu d'un email
[   9]Des icones
