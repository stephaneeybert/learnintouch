[   1]Composer le style intérieur du modèle
