[   0]Composer un modèle
[   1]Supprimer un élément
[   2]Type de modèle:
[   3]Ajouter un élément
[   4]Intervertir avec le suivant
[   5]Intervertir avec le précédent
[   6]Modèle:
[   7]Styler le conteneur
[   8]Un modèle est composé de conteneurs, chacun contenant une série d'éléments.\n\nUn conteneur est ici représenté par un carré noir.\n\nLes éléments sont les objets de base servant à la construction du modèle.\n\nIl y a différents types d'éléments.\n\nCertains éléments sont des liens de navigations.\n\nD'autres affichent du contenu.\n\nPour composer un modèle, veuillez simplement ajouter des éléments dans les conteneurs.\n\nEnsuite, veuillez éditer le contenu des éléments.\n\nEnfin, veuillez composer le style des éléments.
[   9]Styler l'élément
[  10]Styler le modèle
[  11]Composer l'élément
[  12]Afficher l'aperçu du modèle
[  13]Etes vous sur de vouloir SUPPRIMER ?
[  14]Styler les pages pré-formatées
[  15]Styler l'intérieur du modèle
[  16]Intervertir avec le suivant
[  17]Les conteneurs doivent tous avoir une largeur exprimée dans la même unité, soit en pixels, soit en pourcentage.
[  18]Intervertir avec le précédent
[  19]Supprimer un conteneur
[  20]Ajouter un conteneur
[  21]Ajouter une rangée de conteneurs
[  22]Déplacer vers la rangée suivante
[  23]Déplacer vers la rangée précédente
[  24]Afficher l'aperçu du conteneur
[  25]Afficher l'aperçu de l'élément
[  26]Dupliquer l'élément
[  27]Cacher l'élément
[  28]Afficher l'élément
[  29]Intervertir la rangée avec la précédente
[  30]Intervertir la rangée avec le suivante
[  31]hérite du modèle:
[  32]Les rangées de conteneurs devraient avoir la même largeur totale.
[  33]La rangée
[  34]de conteneurs devrait avoir la même largeur totale que la rangée de son modèle parent.
