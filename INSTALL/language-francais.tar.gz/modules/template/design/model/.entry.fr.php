[   0]Spécifier les modèles du site web
[   1]Modèle d'accueil pour ordinateur:
[   2]Modèle d'accueil pour téléphone:
[   3]Modèle par défaut pour ordinateur:
[   4]Modèle par défaut pour téléphone:
[   5]Le contenu du site web est affiché au sein de modèles.\n\nLe modèle d'accueil est celui utilisé lorsqu'un visiteur arrive sur le site web.\n\nLe modèle par défaut est le modèle principal du site web. Il peut être le même que le modèle d'accueil.\n\nIl y a des modèles pour un affichage sur ordinateurs et des modèles pour un affichage sur des téléphones.
