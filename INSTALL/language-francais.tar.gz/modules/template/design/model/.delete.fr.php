[   0]Effacer un modèle
[   1]Nom:
[   2]Effacer le modèle?
[   3]Description:
[   4]Le modèle ne peut pas être effacé parce que c'est le modèle par défaut du site web.
[   5]Le modèle ne peut pas être effacé parce que c'est le modèle d'entrée du site web.
