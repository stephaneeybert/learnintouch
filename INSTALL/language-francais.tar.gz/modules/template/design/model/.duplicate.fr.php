[   0]Dupliquer un modèle
[   1]Nom:
[   5]Description:
[   7]Dupliquer le modèle?
[   2]Le nom ne doit pas être un nombre.
[   3]Le nom est requis.
[   4]Un modèle avec ce nom existe déjà.
