[   0]Renommer un modèle
[   1]Le type de modèle est requis.
[   2]Type de modèle:
[   3]Le nom ne doit avoir qu'un seul mot.\n\nIl ne peut contenir d'espaces blancs.
[   4]Le nom est requis.
[   6]Nom:
[   7]Description:
[   8]Modèle parent:
[   9]Un modèle avec ce nom existe déjà.
[  10]Il est possible pour un modèle, d'hériter d'un autre modèle.\n\nL'autre modèle devient le parent du modèle.\n\nLe modèle enfant hérite de tout le contenu du modèle parent.\n\nLe modèle enfant peut cependant styler le contenu de son modèle parent.
