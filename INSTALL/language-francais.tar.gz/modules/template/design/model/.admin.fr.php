[   0]Les modèles
[   1]Créer un modèle
[   2]Renommer le modèle
[   3]Effacer le modèle
[   4]Nom
[   5]Description
[   6]Composer le modèle
[   8]Défaut
[   9]Dupliquer le modèle
[  10]Exporter le modèle
[  11]Sélectionner un modèle
[  12]Spécifier le modèle d'entrée
[  13]Les modèles décrivent le contenu et la disposition générale du site web.\n\nIl peut y avoir un nombre illimité de modèles.\n\nChaque modèle peut être utilisé par un nombre illimité de pages web.\n\nUn modèle est spécifiée comme étant le modèle par défaut du site web.\n\nC'est le modèle utilisé par la plupart des pages du site web.\n\nUn autre modèle peut être spécifié comme étant le modèle d'entrée du site web.\n\nC'est le modèle utilisé par la page d'entrée du site web.\n\nLe modèle d'entrée permet de choisir quel modèle sera utilisé pour l'affichage des pages web lorsqu'un visiteur arrive sur le site web.\n\nEt le modèle par défaut permet de choisir quel modèle sera utilisé pour l'affichage des pages suivantes du site web.\n\nMais il est possible d'avoir d'autres modèles et de les utiliser pour n'importe quelles pages du site web.
[  14]Entrée
[  15]Le modèle par défaut pour ordinateur
[  16]Le modèle par défaut pour téléphone
[  17]Le modèle d'entrée pour ordinateur
[  18]Le modèle d'entrée pour téléphone
[  19]Afficher l'apercu du modèle
[  20]Composer le style des pages pré-formatées
[  21]Les images de navigation
[  27]Les préférences
