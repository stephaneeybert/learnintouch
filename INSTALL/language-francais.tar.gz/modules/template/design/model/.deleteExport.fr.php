[   0]Effacer un fichier
[   1]Fichier:
[   2]Effacer le fichier?
