[   1]Composer le style du conteneur
