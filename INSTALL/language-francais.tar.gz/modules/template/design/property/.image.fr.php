[   0]Télécharger une image
[   6]Image:
[   3]Nom de l'image:
[   2]Sélectionner une image:
[   7]Effacer l'image?
[  27]Aucune image n'a été spécifiée.
[   1]Veuillez sélectionner une image et la télécharger.
