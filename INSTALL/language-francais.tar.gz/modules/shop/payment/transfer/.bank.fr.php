[   0]Les pages de coordonnées bancaires
[   1]Pour chaque langue, une page peut être spécifiée comme étant la page de coordonnées bancaires.\n\nLa page sera affichée après qu'un visiteur envoi une commande et paye manuellement par une banque extérieure à la boutique.
[   2]Spécifier la page de coordonnées bancaires pour la langue
[   3]Langue
[   4]Page web
[   5]La page de coordonnées bancaires pour les ordinateurs
[   6]La page de coordonnées bancaires pour les téléphones
