[   1]Le paiement n'a PAS été effectué.\n\nVotre commande est toujours en cours.
[   0]Vous pouvez cliquer ici pour revenir à votre commande.
