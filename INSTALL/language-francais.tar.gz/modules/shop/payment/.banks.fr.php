[   0]Liste des banques
[   1]Spécifier les informations du compte Paypal
[   2]Carte bancaire avec Paypal
[   3]Transfert bancaire
[   4]Spécifier les informations de compte de banque
