[   0]Le paiement a été effectué.\n\nVotre commande a été acceptée!
[  19]Le paiement n'a PAS été effectué.\n\nVotre commande est toujours en cours.
[   1]Une nouvelle commande de
[  20]a été payée à
[   2]Une commande a été payée par
[   4]voir la commande
[   5]a reçu votre commande!
[   6]Cher(e)
[   7]Nous avons reçu votre commande avec la référence:
[   9]Nous vous remercions pour vos achats.
[  10]Sincères Salutations,
[  12]Vous pouvez consulter le statut de votre commande en utilisant l'adresse email et le mot de passe suivants:
[  13]Email:
[  14]Mot de passe:
[  15]voir le statut de votre commande
[  17]Le numéro de référence de la commande est:
[  18]Votre commande va s'afficher dans quelques secondes...
[  21]Le client peut être contacté à
[   3]Vous pouvez
[   8]vous connectez à votre compte.
[  11]Une fois connecté, vous pouvez
[  16]changer votre mot de passe
