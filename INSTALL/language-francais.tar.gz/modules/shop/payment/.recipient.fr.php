[   0]Le vendeur
[   1]Ces informations sont affichées sur les factures envoyées aux clients.
[   2]Nom de la boutique:
[   3]Le nom de la boutique est affiché en pied de page sur les factures clients.
[   4]Le format de l'adresse email est invalide.
[   5]Address:
[   6]L'adresse de la boutique est affichée en pied de page sur les factures clients.
[   7]Téléphone:
[   8]Le téléphone de la boutique est affichée en pied de page sur les factures clients.
[   9]Téléphone portable:
[  10]Le téléphone portable de la boutique est affichée en pied de page sur les factures clients.
[  11]Email:
[  12]L'adresse email de la boutique est affichée en pied de page sur les factures clients.
[  13]Nom de la banque:
[  14]Le nom de la banque de la boutique est affiché en pied de page sur les factures clients.
[  15]Compte bancaire:
[  16]Le compte bancaire de la boutique est affiché en pied de page sur les factures clients.
[  17]Numéro IBAN:
[  18]Le numéro IBAN de la boutique est affiché en pied de page sur les factures clients.
[  19]Numéro BIC:
[  20]Le numéro BIC de la boutique est affiché en pied de page sur les factures clients.
[  21]Code postal:
[  22]Pays:
[  23]Numéro d'inscription de la société:
[  24]Le numéro d'inscription de la société est le numéro d'identification de la société auprès des autorités légales.
[  25]Numéro de TVA: 
[  26]Le numéro de TVA est le numéro d'identification pour la TVA.
