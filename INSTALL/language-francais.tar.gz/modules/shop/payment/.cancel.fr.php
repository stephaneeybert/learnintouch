[   0]Le paiement a echoué ou a été annulé.\n\nVotre commande n'a pas été acceptée.
