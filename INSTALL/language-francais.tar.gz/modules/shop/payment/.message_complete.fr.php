[   0]Nous vous remercions de votre paiement. Votre transaction est terminée et vous allez recevoir par email un avis accusant réception de votre achat.
