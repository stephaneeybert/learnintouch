[   0]Modifier un affilié
[   1]Utilisateur:
[   2]Un affilié est un utilisateur du système.\n\nPour créer un nouvel affilié, veuillez d'abord créer un utilisateur.\n\nEnsuite veuillez choisir cet utilisateur nouvellement créé pour être un affilié. 
[   3]L'utilisateur est requis.
[   4]Cet utilisateur est déjà un affilié.
[  15]Sélectionner un utilisateur
[  25]Parcourir...
