[   0]Les codes de réduction
[   1]Taux de réduction
[   2]Modifier le code de réduction
[   3]Effacer le code de réduction
[   4]Ajouter un code de réduction
[   5]Code de réduction
[   6]Les codes de réduction de l'affilié
[   7]Un affilié peut avoir plusieurs codes de réduction, chaque code de réduction ayant un taux de réduction propre exprimé en pourcentage.
