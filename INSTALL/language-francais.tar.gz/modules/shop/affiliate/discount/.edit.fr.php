[   0]Modifier un code de réduction
[   1]Code de réduction:
[   2]Taux de réduction:
[   3]Le code de réduction est requis.
[   4]Ce code de réduction existe déjà.
[   5]Le taux de réduction est requis.
