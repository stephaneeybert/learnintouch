[   0]Effacer un code de réduction
[   1]Code de réduction:
[   2]Effacer le code de réduction?
[   3]Taux de réduction:
