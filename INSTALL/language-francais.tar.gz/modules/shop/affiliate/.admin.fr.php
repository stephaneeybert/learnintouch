[   0]Les affiliés
[   1]Codes de réduction
[   2]Modifier l'affilié
[   3]Effacer l'affilié
[   4]Ajouter un affilié
[   5]Nom
[   6]Les codes de réduction de l'affilié
[   7]Les affiliés sont des personnes qui sont en contact avec des clients potentiels.\n\nIls sont des agents assistant à la vente du service.\n\nUn affilié a des codes de réduction qu'il communique à ses contacts afin que ceux-ci puissent profiter d'une réduction en devenant clients.\n\nUn affilié peut avoir plusieurs codes de réduction, chaque code de réduction ayant un taux de réduction propre exprimé en pourcentage.
[   8]Chercher:
[   9]Il peut devenir fastidieux d'avoir à naviguer dans la liste des affiliés pour retrouver un affilié particulier.\n\nPour éviter cela, il est possible de saisir tout ou partie du nom d'un affilié et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera tous les affiliés correspondant au texte recherché.
