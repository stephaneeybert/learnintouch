[   0]Effacer une image
[   1]Image:
[   3]Description:
[   2]Effacer l'image?
