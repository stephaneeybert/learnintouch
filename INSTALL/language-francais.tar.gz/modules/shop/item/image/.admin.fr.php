[   0]Les images
[   1]Ajouter une image
[   2]Modifier l&#039;image
[   3]Effacer l&#039;image
[   4]Image
[   5]Description
[   6]Nom:
[   7]Référence:
[   8]Changer l&#039;image
[  10]Intervertir avec le suivant
[  11]Intervertir avec le précédent
[  13]Il peut y avoir plusieurs images pour un article.\n\nChaque image peut avoir une description.\n\nLes images peuvent être affichées dans un ordre spécifié.
