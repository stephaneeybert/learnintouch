[   0]Les articles de la boutique
[   1]Créer un article
[   2]Modifier l&#039;article
[   3]Effacer l&#039;article
[   4]Nom
[   5]Description
[   6]Les catégories
[   7]Gérer les images de l&#039;article
[   8]Url
[   9]Catégorie:
[  10]Intervertir avec le suivant
[  11]Intervertir avec le précédent
[  12]Image
[  13]Les articles de la boutique sont les biens à vendre.\n\nChaque article a une description.\n\nUn article peut éventuellement avoir des images.\n\nLes articles peuvent être triés par catégorie, modèle et gamme.
[  16]Les commandes d'achats
[  70]Chercher:
[  71]Il peut devenir fastidieux d'avoir à naviguer dans la liste des articles pour retrouver un article particulier.\n\nPour éviter cela, il est possible de faire une recherche basée sur du texte saisi.\n\nLe résultat de la recherche affichera tous les articles correspondant au texte recherché.
