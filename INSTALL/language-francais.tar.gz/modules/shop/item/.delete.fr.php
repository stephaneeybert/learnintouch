[   0]Effacer un article
[   1]Nom:
[   2]Effacer l'article?
[   3]Description courte:
[   4]L'article est utilisé par une ou plusieurs commandes:
[   6]Prénom
[   7]Nom
[   8]Email
[   9]Date de commande
[  10]Statut
[  11]Effacer l'article et conserver les commandes:
