[   0]Les catégories d'articles
[   1]Déplacer dans la page
[   2]Modifier la catégorie
[   3]Effacer la catégorie
[   4]Ajouter une catégorie
[   5]Nom
[   6]Description
[   7]Déplacer après la page
[   8]Déplacer avant la page
[  10]Intervertir avec la suivante
[  11]Intervertir avec la précédente
