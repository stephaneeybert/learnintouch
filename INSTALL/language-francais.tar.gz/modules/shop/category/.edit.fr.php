[   0]Modifier une catégorie d'article
[   4]Nom:
[   5]Description:
[   6]Le nom est requis.
