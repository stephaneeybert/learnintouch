[   0]Effacer une catégorie d'article
[   1]Nom:
[   5]Description:
[   2]Effacer la catégorie?
[   3]La catégorie ne peut être effacée car elle est utilisée par des articles.
