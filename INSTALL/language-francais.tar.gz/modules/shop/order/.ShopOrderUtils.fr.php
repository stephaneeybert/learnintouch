[   1]article(s)
[   3]Voir l'article
[   4]Référence
[   5]article(s) pour un total de:
[   6]Montant total:
[   7]Frais d'envoi et de gestion:
[   8]Emballage cadeau
[   9]Télécharger la facture PDF
[  10]Prénom:
[  11]Nom:
[  12]Organisation:
[  13]Email:
[  14]Téléphone:
[  15]Téléphone portable:
[  16]Adresse de facturation
[  17]Adresse:
[  19]Code postal:
[  20]Ville:
[  21]Département:
[  22]Pays:
[  23]Adresse de livraison
[  25]Fax:
[  26]Vos commandes d'achats
[  27]Veuillez cliquer sur une icône pour voir une commande.
[  28]Voir la commande
[  29]Status:
[  30]Commande
[  31]Articles
[  32]Total
