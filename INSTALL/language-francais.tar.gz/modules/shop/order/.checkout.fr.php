[   0]Votre commande
[   1]Prénom: *
[   2]Nom: *
[   3]Email: *
[   4]Organisation:
[   5]Téléphone:
[   6]Téléphone portable:
[   7]Message:
[   8]Veuillez saisir les informations de votre commande.\nLes champs obligatoires sont marqués d'une étoile *
[   9]Le nom est requis.
[  10]L'adresse email est requise.
[  11]Le format de l'adresse email est invalide.
[  12]Le prénom est requis.
[  13]Un message de contact a été envoyé à
[  14]Cliquez ici
[  15]Nous avons bien reçu votre message.\n\nNotre service clientèle vous contactera sous peu.
[  16]Message de contact de
[  17]pour lire le message.
[  18]Le suffixe de l'adresse email est invalide.
[  19]par
[  20]Message:
[  21]pour
[  22]Veuillez saisir ce code de sécurité
[  23]Code de sécurité: *
[  24]Veuillez saisir le code de sécurité affiché.\n\nUn code de sécurité est requis pour s'assurer que l'écriture d'un message de contact est faite par une personne et non pas par un programme.\n\nParce qu'un programme ne peut pas lire un nombre affiché sous forme graphique, seul une vrai personne peut ecrire un message de contact.
[  25]Passer la commande
[  26]Boite postale:
[  27]Votre panier d'achat est vide
[  29]Si l'adresse de livraison est différente de l'adresse de facturation alors veuillez aussi saisir une adresse de livraison. Autrement, l'adresse de facturation sera utilisée comme adresse de livraison.
[  30]Adresse:
[  32]Code postal:
[  33]Ville:
[  34]Département:
[  35]Pays:
[  36]Adresse de facturation
[  37]Adresse de livraison
[  38]L'adresse est requise.
[  39]Le code postal est requis.
[  41]La ville est requise.
[  42]Le pays est requis.
[  43]Vous pouvez aussi nous laisser un message concernant votre commande.
[  44]Le code de sécurité est requis.
[  45]Le code de sécurité est incorrect.
[  46]Cocher la case si l'adresse de livraison est différente de l'adresse de facturation.
[  47]Fax:
[  48]Voir le contenu du panier d'achat
