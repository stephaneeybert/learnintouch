[   0]Commande
[   1]Prénom:
[   2]A payer le:
[   3]Organisation:
[   4]Adresse email:
[   5]Téléphone:
[   6]Téléphone portable:
[   7]Message:
[   8]Date de facture:
[   9]Total:
[  10]Statut:
[  11]Le statut devrait être mis à jour après une opération sur une commande.\n\nPar exemple, si la commande est expédiée alors le statut de la commande devrait être mis à jour à Expédié.
[  12]Une date doit avoir le format
[  13]Voir l'adresse...
[  14]La date à payer doit être postérieure à la date de la facture.
[  15]Voir les article(s)...
[  16]Fax:
[  17]Numéro de TVA:
[  18]Numéro de facture:
[  19]Note de facture:
[  20]La note de facture est un message affiché sur la facture.
[  21]Langue de la facture:
[  22]La langue dans laquelle la facture est rendu.
