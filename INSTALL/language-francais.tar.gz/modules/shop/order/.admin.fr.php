[   0]Les commandes d'achats
[   1]Chaque commande a un statut indiquant l'état actuel de la commande.
[   2]Les commandes sont reçues par les clients achetant sur le site web.\n\nIl est possible de lister les commandes par leur statut.\n\nLes commandes payées sont celles qui ont été payées et pas encore expédiées. Ces commandes doivent être expédiées dès que possible.\n\nLes commandes expédiées sont celles qui ont été payées et expédiées.\n\nLes commandes en cours sont celles qui ont été reçues mais pas encore payées. Ces commandes ne devraient pas encore être expédiées.\n\nLes commandes annulées sont celles qui n'ont pas été et ne seront pas payées. Ce sont les commandes abandonnées par les clients en cours de visite du site web. Elles peuvent éventuellement être effacées du système.\n\nLes commandes remboursées sont celles qui ont été payées par les clients puis plus tard remboursées.
[   3]Statut:
[   4]Effacer les commandes annulées
[   5]Voir la commande
[   6]Télécharger la facture PDF
[   7]Annuler la commande
[   8]Nom
[   9]Montant total
[  10]Chercher:
[  11]Il peut devenir fastidieux d'avoir à naviguer dans la liste des commandes pour retrouver une commande particulière.\n\nPour éviter cela, il est possible de faire une recherche basée sur du texte saisi.\n\nLe résultat de la recherche affichera toutes les commandes correspondant au texte recherché.
[  12]Date à payer
[  13]Les affiliés
[  14]Date de commande
[  15]Numéro de commande
[  16]Statut
[  17]Mois:
[  18]Il est possible de filtrer les commandes par mois.\n\nPar défaut, le mois courant est sélectionné.
[  19]Les solutions de paiement en ligne
[  20]Les préférences
[  21]Le compte bancaire de la boutique
[  22]Voir la localisation du client
[  23]Les articles
