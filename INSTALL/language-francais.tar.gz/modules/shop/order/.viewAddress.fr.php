[   0]Adresse de la commande
[   1]Adresse de facturation
[   2]Adresse:
[   3]Boite postale:
[   4]Code postal:
[   5]Ville:
[   6]Etat:
[   7]Pays:
[   8]Courriel:
[  14]Adresse de livraison
