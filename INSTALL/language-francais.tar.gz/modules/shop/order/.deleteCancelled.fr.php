[   0]Effacer les commandes annulées
[   1]Effacer ces commandes
[   2]Seules les commandes avec un statut annulé peuvent être effacées.\n\nToutes les autres commandes ne seront pas effacées.
[   3]Nom
[   4]Date de commande
[   5]Numéro de commande
