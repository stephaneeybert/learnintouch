[   0]Confirmation de commande
[   1]Prénom:
[   2]Nom:
[   3]Email:
[   4]Organisation:
[   5]Téléphone:
[   6]Téléphone portable:
[   7]Message:
[   8]Procéder au paiement en ligne par carte bancaire
[   9]Réf:
[  10]Annuler la commande
[  11]Confirmer votre commande et procéder au paiement.
[  12]Emballage cadeau
[  13]Votre commande a été annulée !\n\nVous allez être redirigé dans quelques secondes...
[  14]Nous ne pouvons pas accepter de commandes pour l'instant.
[  15]Procéder au paiement différé avec un transfert bancaire
[  16]Pour des raisons administratives, nous ne pouvons pas accepter de commandes pour l'instant.
[  17]Boite postale:
[  18]L'adresse email a un suffix invalide.
[  19]Destinataire
[  20]Il n'y a pas d'articles dans le panier d'achat.
[  21]Article(s) commandé(s)
[  22]Continuer
[  23]Réduction:
[  30]Adresse:
[  32]Code postal:
[  33]Ville:
[  34]Département:
[  35]Pays:
[  36]Adresse de facturation
[  37]Adresse de livraison
[  47]Fax:
[ 110]Frais d'envoi et de gestion:
[ 111]Montant à payer:
[ 112]article(s) pour un total de:
[ 113]Total:
