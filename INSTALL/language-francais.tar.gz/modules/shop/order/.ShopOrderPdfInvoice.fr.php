[   0]Facture
[   1]Description
[   2]Quantité
[   3]Prix Unitaire
[   4]Montant
[   5]Payable à:
[   6]Banque:
[   7]Compte bancaire:
[   8]IBAN:
[   9]article(s) pour un total de:
[  10]Montant total:
[  11]Frais d'envoi et de gestion:
[  12]BIC:
[  13]Numéro de facture:
[  14]Payable le:
[  15]Le
[  16]Numéro de TVA:
[  17]Client:
[  18]Téléphone:
[  19]Téléphone portable:
[  20]Email:
[  21]Référence:
[  22]Numéro de TVA du client:
[  23]Réduction:
[  24]TVA
[  25]Total TVA:
