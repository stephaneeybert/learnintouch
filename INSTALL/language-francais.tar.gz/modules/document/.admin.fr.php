[   0]Les documents
[   1]Télécharger un document
[   2]Renommer le document
[   3]Effacer le document
[   4]Nom
[   5]Description
[   6]Les catégories
[   7]Télécharger un document
[   8]Télécharger le fichier
[   9]Catégorie:
[  10]Intervertir avec le suivant
[  11]Intervertir avec le précédent
[  13]Les documents sont des fichiers de n'importe quels types qui sont stockés dans le site web pour être offerts en téléchargement.\n\nQuand un document est stocké dans le site web, il peut ensuite être référencé par un lien.\n\nLes visiteurs du site web peuvent alors télécharger le document en cliquant sur le lien.
[  20]Les préférences
