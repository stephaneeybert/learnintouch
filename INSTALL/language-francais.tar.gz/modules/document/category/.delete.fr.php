[   0]Effacer une catégorie
[   1]Nom:
[   5]Description:
[   2]Effacer la catégorie?
[   3]La catégorie contient des documents.\n\nVeuillez effacer les documents ou les retirer de leur catégorie, pour pouvoir ensuite effacer la catégorie.
