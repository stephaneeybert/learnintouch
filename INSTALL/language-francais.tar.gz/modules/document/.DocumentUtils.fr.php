[   0]Document à télécharger:
[   1]Télécharger le document
[   2]Réf:
[   3]Télécharger
[   4]Afficher tous les documents:
[   5]Par défaut, lorsqu'aucune catégorie n'a encore été sélectionnée par un visiteur du site web, seuls les documents de la première catégorie sont affichés.\n\nMais il est possible d'afficher tous les documents au lieu de seulement ceux de la première catégorie.
[   6]Cacher le sélecteur:
[   7]Par défaut, un sélecteur de catégorie est affiché en haut de la liste des documents.\n\nMais ce sélecteur peut être caché pour interdire la sélection d'une autre catégorie.
[   8]Voir
[   9]Issuu:
[  10]Par défaut, les documents peuvent seulement être téléchargés.\n\nMais il est possible de les voir directement sur le site web.\n\nVous devez pour cela, vous inscrire à www.issuu.com et aller à la page http://www.issuu.com/smartlook\n\nDe là, vous saisissez simplement le nom de domaine de votre site web et copiez le code dans la préférence.\n\nAprès cela, vous devez rafraichir les modèles de votre site web.
[  32]Nombre de documents par rangée:
[  33]Les listes de documents peuvent afficher plusieurs documents par rangée.\n\nLe nombre de documents par rangée peut être modifié.
