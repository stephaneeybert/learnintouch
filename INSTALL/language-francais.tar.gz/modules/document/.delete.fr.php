[   0]Effacer un document
[   1]Référence:
[   3]Description:
[   2]Effacer le document?
[   6]Fichier:
