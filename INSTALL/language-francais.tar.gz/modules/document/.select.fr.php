[   0]Sélectionner un document
[   1]Catégorie:
[   2]Document:
[   3]Veuillez choisir un document ou une catégorie de documents.\n\nSi un document est choisi alors un clic sur le lien html offrira le document en téléchargement.\n\nSi, au contraire, une catégorie est choisie, alors un clic sur le lien redirigera vers une page affichant tous les documents de la catégorie.
[   4]Veuillez choisir un document OU une catégorie de documents.
