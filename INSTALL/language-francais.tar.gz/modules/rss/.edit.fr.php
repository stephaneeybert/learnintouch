[   0]Ajouter une source RSS pour une langue
[   1]Url:
[   2]L'url est l'adresse XML qui pointe vers la source RSS.\n\nSi la source RSS est disponible dans plusieurs langues alors il y a une url pour chaque langue de la source RSS.
[   3]Titre:
[   4]Par défaut, le titre est fournit par la source RSS.\n\nMais il est possible de spécifier un titre.\n\nDans ce cas, le titre spécifié sera affiché à la place de celui fournit par la source RSS.
[  19]Langue:
[  21]Une langue peut être assignée à une source RSS.\n\nSi tel est le cas, la source RSS est affichée seulement si sa langue est celle choisie par l'utilisateur visitant le site web.
