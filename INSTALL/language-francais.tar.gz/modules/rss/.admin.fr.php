[   0]Une source RSS
[   1]Ajouter une source RSS pour une langue
[   2]Titre
[   3]Effacer la source RSS
[   4]Langue
[   5]Url
[   7]Une source RSS permet l'affichage d'articles provenant d'autres sites web.\n\nSi la source RSS est disponible dans plusieurs langues alors il est possible d'afficher la source RSS dans ces différentes langues.\n\nUne url vers la source RSS peut être ajoutée pour chaque langue du site web.
[  13]Pour toutes les langues
[  14]Fermez la fenètre
[  15]pour la langue
[  22]Modifier la source RSS
