[   0]Effacer une langue
[   1]Nom:
[   2]Effacer la langue?
[   6]Code:
[   5]Image:
