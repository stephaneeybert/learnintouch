[   0]Les langues
[   1]Créer une langue
[   2]Modifier la langue
[   3]Effacer la langue
[   4]Code
[   5]Image
[   6]Le contenu du site web peut être affiché dans différentes langues.\n\nUn utilisateur visitant le site web peut choisir une langue dans laquelle les pages sont affichées.\n\nUne langue peut être désactivée si elle n'est pas utilisée.\n\nUne langue par défaut peut être spécifiée. C'est la langue utilisée pour les utilisateurs n'ayant pas encore choisit une langue.
[   7]Choisir comme langue par défaut
[   8]Nom
[   9]Défaut
[  10]Activer la langue pour le site web
[  11]Désactiver la langue pour le site web
[  12]Changer l'image
[  14]Activer la langue pour le panneau d'administration
[  15]Désactiver la langue pour le panneau d'administration
