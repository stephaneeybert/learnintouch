[   0]Spécifier la langue par défaut
[   2]Spécifier la langue comme étant celle par défaut?
[   1]Nom:
[   3]Code:
[   5]Image:
