[   0]Modifier une langue
[   7]Nom:
[   6]Code:
[   1]Locale:
[  39]Le code est requis.
[  40]Le nom est requis.
[   9]Une langue avec ce code existe déjà.
