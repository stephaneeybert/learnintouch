[   0]Désactiver une langue du site web
[   4]Activer une langue du site web
[   6]Nom:
[   5]Image:
[   7]Code:
[   1]Activer la langue?
[   2]Désactiver la langue?
[  15]Le language par défaut ne peut pas être désactivé.
