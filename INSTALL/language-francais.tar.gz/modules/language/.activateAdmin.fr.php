[   0]Désactiver une langue d'administration
[   4]Activer une langue d'administration
[   6]Nom:
[   5]Image:
[   7]Code:
[   1]Activer la langue?
[   2]Désactiver la langue?
