[   0]Effacer un site web
[   1]Nom:
[   5]Nom de domaine:
[   2]Effacer le site web?
