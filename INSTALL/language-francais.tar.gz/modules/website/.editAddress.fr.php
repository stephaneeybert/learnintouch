[   0]Adresse de site web
[   1]Boite postale:
[   2]Numéro de TVA:
[  13]Adresse:
[  14]Adresse:
[  15]Code postal:
[  16]Ville:
[  17]Région:
[  18]Pays:
[  19]Téléphone:
[  20]Tél portable:
[  21]Fax:
[  33]Le numéro de portable ne peut contenir que des chiffres.
[  34]Le numéro de fax ne peut contenir que des chiffres.
[  36]Le numéro de téléphone ne peut contenir que des chiffres.
