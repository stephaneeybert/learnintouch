[   0]Les sites web
[   1]Effacer le site web
[   2]Créer un site web
[   3]Nom
[   4]Site web
[   5]Durée
[   6]Modifier les informations
[   7]Date d'ouverture
[   8]Permissions d'utilisation des modules
[   9]Date de cloture
[  10]Modifier l'adresse
[  11]Les abonnements
[  12]Utilisation de l'espace disque
[  13]Usage disque
[  14]Augmenter l'espace disque
[  15]Package
[  16]Renouveler les abonnements
[  17]Exporter les nouvelles factures
[  18]Modifier les options
