[   0]Les abonnements du site web
[   1]Effacer l'abonnement
[   2]Créer un abonnement
[   3]Site web:
[   4]Date d'ouverture
[   5]Montant
[   6]Modifier l'abonnement
[   7]Auto renouvellement
[   8]Générer une commande
[   9]Date de clôture
[  10]Renouveler l'abonnement
[  15]Durée
