[   0]Les options d'un site web
[   7]Nom du site web:
[   9]Options
[   8]Choisissez les options pour le site web.\n\nLes options non sélectionnés ne seront pas accessibles par le site web.
