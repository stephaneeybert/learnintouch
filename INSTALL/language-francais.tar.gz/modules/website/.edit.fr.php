[   0]Modifier un site web
[   1]Prénom:
[   2]Nom:
[   3]Nom de domaine: *
[   4]Email:
[   5]Package:
[   6]Le nom système est requis.
[   7]Le nom de la base de données est requis.
[   8]Nom de la base de données: *
[   9]Le nom système: *
[  10]Nom de site web: *
[  12]Le nom de domaine est requis.
[  13]Le format de l'adresse email est invalide.
[  14]Le nom de site web est requis.
[  15]Espace disque
[  16](Mo)
