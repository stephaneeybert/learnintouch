[   0]Un lien de navigation
[   1]Ajouter un lien pour une langue
[   3]Effacer le lien
[   4]Langue
[   7]Les liens de navigation offrent aux utilisateurs visitant le site web un moyen de naviguer au sein du site web.\n\nUne lien de navigation pointe vers une page web ou vers un site web.\n\nIl est représenté par du texte ou par une image.\n\nSi le site web utilise plusieurs langues alors le lien peut être défini dans chacune de ces langues.
[  10]Image/Texte
[  13]Pour toutes les langues
[  14]Fermez la fenètre
[  15]pour la langue
[  22]Modifier le lien
