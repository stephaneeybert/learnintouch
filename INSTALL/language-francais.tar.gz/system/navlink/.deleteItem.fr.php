[   0]Effacer un élément
[   1]Texte:
[   5]Description:
[   2]Effacer l'élément?
