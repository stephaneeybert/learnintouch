[   0]Télécharger une image
[   6]Image:
[   3]Nom de l'image:
[   2]Sélectionner une image:
[   7]Effacer l'image?
[   1]Une lien de navigation peut utiliser une image.\n\nSi un lien de navigation possède une image, alors l'image sera affichée à la place du nom du lien.
