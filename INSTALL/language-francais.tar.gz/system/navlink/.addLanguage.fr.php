[  20]Un lien pour cette langue existe déjà.\n\nVeuillez choisir une autre langue.
[   0]Ajouter un lien pour une langue
[  19]Langue:
[  21]Une langue peut être assignée à un lien de navigation.\n\nSi tel est le cas, le lien de navigation est affiché seulement si sa langue est celle choisie par l'utilisateur visitant le site web.
