[   0]Télécharger le fichier audio
[   1]Lecteur video HTML5
[   2]Lecteur video Flash
[   9]Flash haut parleur simple pour audio
[  11]Flash avec control pour audio
