[   0]Confirmer et valider l&#039;opération
[   1]Fermer la fenètre
