[   0]Valider l'opération
[   1]Fermer la fenètre
[   2]Déconnexion du panneau d'administration
[   3]Retour au niveau supérieur
[   4]Thalasoft Web Solution
[   5]Un produit de Thalasoft.com
[   6]Le nom LearnInTouch et le logiciel sont enregistrés chez Copyright France.
