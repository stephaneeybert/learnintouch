[   0]Modifier un menu
[   3]Cacher le menu:
[   8]Par défault un menu est visible et est affiché.\n\nMais il peut être caché. Dans ce cas, il n'est pas affiché.\n\nCette fonctionalité offre un moyen facile de cacher momentanément un menu.
