[   0]Modifier une langue dans un menu
[   7]Langue:
[   1]Un menu existe déjà pour la langue spécifié.
[  12]Une langue peut être assignée à un menu de navigation.\n\nSi tel est le cas, le menu de navigation est affiché seulement si sa langue est celle choisie par l'utilisateur visitant le site web.
