[   0]Effacer une langue d'un menu
[   1]Langue:
[   2]Effacer la langue du menu?
