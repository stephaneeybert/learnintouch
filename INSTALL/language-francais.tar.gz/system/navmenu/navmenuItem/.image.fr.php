[   0]Télécharger une image
[   6]Image:
[   3]Nom de l'image:
[   2]Sélectionner une image:
[   7]Effacer l'image?
[  27]Aucune image n'a été spécifiée.
[   1]Un menu de navigation peut utiliser des images.\n\nSi un élément d'un menu de navigation possède une image, alors l'image sera affichée avant le nom de l'élément.
