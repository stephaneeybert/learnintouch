[   0]Télécharger une image
[   6]Image:
[   3]Nom de l'image:
[   2]Sélectionner une image:
[   7]Effacer l'image?
[  27]Aucune image n'a été spécifiée.
[   1]Un élément d'un menu de navigation peut avoir une image.\n\nCette première image est affichée à la place du nom de l'élément.\n\nSi un élément a une image, alors il peut aussi avoir une image 'mouse over'.\n\nCette seconde image est affichée quand le curseur de la souris passe au dessus de la première image.
