[   0]La taille maximum de fichier est
[   1]Ko.
[   2]Soit le fichier est trop gros soit le fichier est vide.
[   3]Le fichier doit avoir un des types suivants:
[   4]Echec du téléchargement du fichier
[  22]Ce type de fichier est interdit.
[  23]La taille du fichier est plus grande que la taille maximum de fichier permise.
[  27]Aucun fichier n'a été spécifié.
