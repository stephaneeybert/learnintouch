[   0]Exécute un ordre SQL sur toutes les bases de données
[   1]Ordre:
[   2]Recherche:
[   3]Remplace:
