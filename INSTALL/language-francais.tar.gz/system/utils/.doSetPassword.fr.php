[   1]Veuillez choisir un nouveau mot de passe à 
[   2]Nous avons réinitialisé votre mot de passe à
[   3]Vous pouvez choisir un nouveau mot de passe.
[   4]D'abord, veuillez vous connectez à
[   5]Ensuite, veuillez changer votre mot de passe à
[   6]Salutations
