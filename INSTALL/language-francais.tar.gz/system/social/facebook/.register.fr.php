[   0]Inscription utilisateur
[   1]Veuillez saisir votre adresse email pour finir votre inscription.
[   2]Adresse email:
[   3]Je souhaite recevoir vos emails
[   4]L'adresse email est requise.
[   5]Le format de l'adresse email est invalide.
[   6]S'enregistrer...
