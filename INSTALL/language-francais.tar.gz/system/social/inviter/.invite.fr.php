[   0]Invitez vos amis
[   2]Veuillez noter que les adresses email de vos amis ne seront pas conservées.
[   3]Adresse email: *
[   4]Mot de passe: *
[   5]Afficher les contacts
[   6]Les contacts de vos amis n'ont pas pu être récupéré. Veuillez vérifier l'adresse email et le mot de passe que vous avez saisi, ou réessayer plus tard.
[   7]Les contacts de vos amis n'ont pas pu être récupéré. Veuillez réessayer plus tard.
[   8]Service: *
[   9]L'adresse email est requise.
[  10]Le message est requis.
[  11]Vous pouvez inviter vos amis à venir découvrir notre site web, en leur envoyant un message.
[  12]Le mot de passe est requis.
[  13]Sélectionner/Desélectionner tous les contacts
[  14]Envoyer le message
[  15]Au moins un contact doit être sélectionné.
[  16]L'invitation a été envoyée aux adresses email sélectionnées suivantes:
[  17]Message: *
[  18]Sujet:
[  19]Choisissez un maximum de
[  20]contacts.
