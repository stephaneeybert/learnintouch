[   0]L'adresse email ou le mot de passe est invalide.
[   1]Aucun contact n'a pu être récupéré.
