[   0]Télécharger un fichier image/flash
[   2]Sélectionner un fichier:
[   1]Les fichiers sont téléchargés à l'aide de l'éditeur html intégré.\n\nLe fichier image/flash est automatiquement inséré dans la page web.
[   3]Pour utiliser ce fichier image/flash dans une page web, veuillez utiliser le lien suivant:
[   4]Vous pouvez sélectionner le lien et faire un copier/coller à l'aide d'un clic droit de la souris.
[   5]Redimensioner à la largeur:
[   6]Lors du téléchargement vers le serveur, une image peut être redimensionée à une certaine largeur.\n\nSi aucune largeur n'est spécifiée. alors l'image n'est pas redimensionée.\n\nLa largeur par défaut est prise de la plus grande largeur d'image dans les préférences.

