[   1]Page Web:
[   3]Insérer un lien pointant vers une page du site web.
[   4]Annuler
[   5]Insérer
[   6]Nouvelle fenêtre:
[   7]Sélectionner une page du site web
[   8]Modèle:
[   9]Un modèle peut être assigné à un lien de navigation.\n\nDans ce cas, la page web pointée par le lien de navigation est affichée dans le modèle spécifié.\n\nAutrement, la page web est affichée dans le modèle actuel.\n\nCela permet à un site web d'afficher des pages web dans différents modèles.\n\nPar exemple, il peut y avoir un modèle par défaut pour la plupart des pages web et un autre modèle pour quelques pages web ayant trait à un évènement particulier.
