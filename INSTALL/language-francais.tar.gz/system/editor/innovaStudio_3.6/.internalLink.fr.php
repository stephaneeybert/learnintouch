[   1]Page Web:
[   3]Insérer un lien pointant vers une page du site web.
[   4]Annuler
[   5]Insérer
[   6]Nouvelle fenêtre:
[   7]Sélectionner une page du site web
