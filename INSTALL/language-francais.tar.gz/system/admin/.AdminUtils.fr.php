[   0]Dernière mise à jour le
[   1]Période de connexion par jeton (semaines):
[   2]Certaines pages du panneau d'administration peuvent être accedées par l'administrateur en cliquant sur un lien contenant un jeton.\n\nPar exemple un email envoyé à un administrateur peut contenir un lien pour voir un message de contact envoyé par un visiteur du site web.\n\nPour offrir un accès instantané à une telle page il est préférable de ne pas obliger l'administrateur à se connecter au panneau d'administratoin avant d'accéder à la page.\n\nUne connexion est ainsi offerte dans le lien vers la page.\n\nPour des raisons de sécurité, il est possible de spécifier une période de validité pour cette connexion.\n\nAprès la fin de cette période la connexion expire et l'administrateur doit se connecter manuellement pour accéder à la page.\n\nCette période est exprimée en semaines.\n\nSi aucune période n'est spécifiée alors la connexion dans le lien n'expirera jamais.
[   3]Nombre d'administrateurs par page:
[   4]La liste des administrateurs dans l'interface d'administration permet d'afficher un nombre choisit d'administrateurs par page.
[   5]Vous ne pouvez pas accéder à cette page.
[   6]Les inscriptions de participants
[   8]Les résultats des devoirs
[   9]Les devoirs donnés à un participant
[  10]Les leçons
[  11]Les exercices
leçons
