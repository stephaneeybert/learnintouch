[   0]Enregistrer un nouvel administrateur
[   1]Prénom: *
[   2]Nom: *
[   3]Adresse:
[   4]Code Postal:
[   5]Ville:
[   6]Pays:
[   7]Email:
[   8]Login: *
[   9]Mot de passe: *
[  10]Tapez votre nom et adresse.\n\nChoisissez un nom de login et un mot de passe.\n\nLes champs requis apparaissent en <B>gras</B> avec une étoile.
[  11]Le prénom et le nom de famille sont requis.
[  12]Préférence admin:
[  13]Le format de l'adresse email est invalide.
[  14]Le nom de login et le mot de passe n'ont pas été correctement défini.
[  15]Ce nom de login est interdit.
[  16]Quelqu'un a deja choisit ce nom de login. Vous devez choisir un autre nom de login.
[  17]Par défaut, seul un super administrateur peut modifier les préférences.\n\nMais il est possible de permettre à un administrateur normal de modifier les préférences.
[  18]Le mot de passe doit être saisi deux fois pour s'assurer qu'il est correctement saisi.
[  19]Un super administrateur peut créer et effacer d'autres administrateurs.\n\nIl peut aussi changer les mots de passe de tous les administrateurs.\n\nIl devrait donc y avoir le moins possible de super administrateurs.\n\nReflechissez bien avant de donner le droit 'super' à un administrateur.\n\nIdéalement, il devrait y avoir un ou deux super administrateurs.
[  20]Super admin:
