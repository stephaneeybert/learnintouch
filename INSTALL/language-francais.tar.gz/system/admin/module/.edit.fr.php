[   0]Les modules d'un administrateur
[   7]Nom de l'administrateur:
[   9]Modules
[   8]Choisissez les modules que l'administrateur peut utiliser.\n\nLes modules non sélectionnés ne seront pas accessibles par l'administrateur.
