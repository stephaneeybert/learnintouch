[   0]Modifier un administrateur
[   1]Prénom: *
[   2]Nom: *
[   3]Adresse:
[   4]Code Postal:
[   5]Ville:
[   6]Pays:
[   7]Email:
[   8]Login: *
[   9]Profil:
[  10]Préférence admin:
[  11]Par défaut, seul un super administrateur peut modifier les préférences.\n\nMais il est possible de permettre à un administrateur normal de modifier les préférences.
[  12]Le prénom et le nom de famille sont requis.
[  13]Le format de l'adresse email est invalide.
[  15]Ce nom de login est interdit.
[  16]Vous ne pouvez pas accéder à cette page.
[  17]Page de post connexion:
[  18]Par défaut, le menu principal du panneau d'administration est affiché après la connexion de l'administrateur.\n\nMais il est possible de spécifier une page au sein du panneau d'administration, qui est affichée après la connexion de l'administrateur.
[  19]Un super administrateur peut créer et effacer d'autres administrateurs.\n\nIl peut aussi changer les mots de passe de tous les administrateurs.\n\nIl devrait donc y avoir le moins possible de super administrateurs.\n\nReflechissez bien avant de donner le droit 'super' à un administrateur.\n\nIdéalement, il devrait y avoir un ou deux super administrateurs.
[  20]Super admin:
