[   0]Connexion Administrateur
[   1]Nom:
[   2]Mot de passe:
[   3]L'abonnement pour le site web
[   4]est expiré.
[   5]Votre nom de login ou votre mot de passe est invalide.
[   6]Votre nom de login ou votre mot de passe est incorrect.
