[   0]Effacer un administrateur
[   1]Effacer l'administrateur?
[   2]Un administrateur ne peut pas s'effacer lui même.
[   3]Un administrateur du staff ne peut pas été effacé.
[   4]Nom de l'administrateur:
[   5]Un administrateur qui est un auteur de journaux ne peut pas été éffacé.\n\nVeuillez d'abord effacer l'auteur de journaux.
