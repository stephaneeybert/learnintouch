[   0]Changer un mot de passe
[   2]Nouveau mot de passe:
[   8]Confirmer le nouveau mot de passe:
[   4]Changer le mot de passe de l'administrateur:
[   3]Tapez et confirmer un nouveau mot de passe pour l'administrateur.
[   1]Seul un super administrateur peut changer le mot de passe d'un autre administrateur.
[   6]Le nouveau mot de passe n'a pas été correctement défini.
