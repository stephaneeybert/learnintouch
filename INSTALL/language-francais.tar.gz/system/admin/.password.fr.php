[   0]Changer le mot de passe
[   1]Mot de passe actuel:
[  10]Tapez votre mot de passe actuel pour vérification.
[   2]Nouveau mot de passe:
[  11]Veuillez saisir votre nouveau mot de passe.
[  12]Veuillez saisir une deuxième fois votre nouveau mot de passe, pour être sur de l'avoir saisi correctement.
[   3]Tapez d'abord votre mot de passe actuel.\n\nVeuillez ensuite tapez et confirmer votre nouveau mot de passe.
[   4]Le mot de passe actuel est requis.
[   5]Le mot de passe actuel est incorrect.
[   6]Le nouveau mot de passe n'a pas été correctement défini.
