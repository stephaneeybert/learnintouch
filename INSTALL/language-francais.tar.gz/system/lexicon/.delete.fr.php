[   0]Effacer une entrée du lexique
[   1]Entrée:
[   2]Explication:
[   3]Lors de la modification ou la suppression d'une entrée, veuillez noter que l'entrée peut déjà être utilisée sur un ou plusieurs contenus du site web.\n\nVeuillez gérer le lexique avec soin car ses entrées sont communes à tout le site web.
[   4]Toutes les entrées du lexique
[   5]Remarque !
