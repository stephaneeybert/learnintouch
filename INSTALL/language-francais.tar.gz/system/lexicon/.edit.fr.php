[   0]Ajouter une entrée
[   1]Entrée:
[   2]Explication:
[   3]L'entrée est requise.
[   4]L'explication est requise.
[   5]L'entrée est un mot ou une phrase courte.\n\nLe lexique est global pour tout le site web et ses entrées peuvent être utilisées sur différents types de contenus.\n\nUne entrée peut ainsi être utilisée plusieurs fois sur différents contenus.\n\nLors de la modification ou la suppression d'une entrée, veuillez noter que l'entrée peut déjà être utilisée sur un ou plusieurs contenus du site web.\n\nVeuillez gérer le lexique avec soin car ses entrées sont communes à tout le site web.
[   6]L'explication est un texte court expliquant l'entrée.
[   7]Modifier une entrée
[   8]Lors de la modification ou la suppression d'une entrée, veuillez noter que l'entrée peut déjà être utilisée sur un ou plusieurs contenus du site web.\n\nVeuillez gérer le lexique avec soin car ses entrées sont communes à tout le site web.
[   9]Toutes les entrées du lexique
[  10]Remarque !
[  11]Ajouter une image
[  12]Image:
[  13]Une entrée du lexique peut aussi avoir une image en plus d'un texte d'explication.
[  14]Insérer ou effacer une image
