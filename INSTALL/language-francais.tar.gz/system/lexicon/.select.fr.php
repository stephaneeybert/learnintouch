[   0]Choisir une entrée dans le lexique
[   1]L'entrée est requise.
[   2]Nom:
[   3]Ajouter une entrée
[   4]Effacer l'entrée du lexique
[   5]Modifier l'entrée
[   7]Pour choisir une entrée, veuillez commencer à saisir l'entrée. Si le lexique contient des entrées correspondant aux lettres saisies alors ces entrées seront suggérées.\n\nSi aucune entrée n'est suggérée alors il est possible d'ajouter l'entrée au lexique.\n\nOu bien, si l'entrée suggérée doit être modifiée avant d'être utilisée, alors l'entrée peut être modifiée dans le lexique.\n\nVeuillez vous assurer de ne pas insérer une entrée sur un mot qui en contient déjà une.
[   8]Toutes les entrées du lexique
