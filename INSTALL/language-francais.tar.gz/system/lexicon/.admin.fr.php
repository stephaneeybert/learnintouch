[   0]Les entrées du lexique
[   1]Entrée
[   2]Explication
[   3]Modifier l'entrée dans le lexique
[   4]Effacer l'entrée du lexique
[   5]Le lexique est global pour tout le site web et ses entrées peuvent être utilisées sur différents types de contenus.\n\nL'entrée est un mot ou une phrase courte.\n\nUne entrée peut ainsi être utilisée plusieurs fois sur différents contenus.\n\nLors de la modification ou la suppression d'une entrée, veuillez noter que l'entrée peut déjà être utilisée sur un ou plusieurs contenus du site web.\n\nLors de la modification ou la suppression d'une entrée, veuillez noter que l'entrée peut déjà être utilisée sur un ou plusieurs contenus du site web.\n\nVeuillez gérer le lexique avec soin car ses entrées sont communes à tout le site web.
[   6]Ajouter une entrée dans le lexique
[   7]Chercher:
[   8]Il peut devenir fastidieux d'avoir à naviguer dans le lexique pour retrouver une entrée.\n\nPour éviter cela, il est possible de saisir tout ou partie d'une entrée et de faire une recherche basée sur le texte saisi.\n\nLe résultat de la recherche affichera toutes les entrées correspondant au texte saisi.
[   9]Image
[  14]Insérer ou effacer une image
[  15]Les préférences
