[   0]Une entrée du lexique est manquante
[   1]L'entrée du lexique avec l'identifiant
[   2]n'a pas été trouvée.
[   3]Elle était requise par la page:
[   4]Veuillez ouvrir la page, voir son code source html et chercher le contenu suivant:
