[   0]Suggérer des définitions:
[   1]Lors de l'ajout d'une entrée du lexique, il est possible d'avoir des définitions suggérées d'un site web externe.\n\nCeci peut aider dans la rédaction de la définition de la nouvelle entrée dans le lexique.\n\nVeuillez noter que lorsqu'une entrée du lexique est modifiée, aucune définitions ne sont suggérées.
[   2]Connexion utilisateur requise:
[   3]Par défaut, si un texte contient des mots du lexique, alors les explications du lexique sont affichées au dessus des mots lorsque le curseur de la souris passe sur ces mots.\n\nMais il est possible de n'afficher les explications du lexique seulement si le lecteur est un utilisateur qui s'est connecté.\n\nDans ce cas, le lecteur sera capable de lire le texte avec les explications du lexique.\n\nSi le lecteur n'est pas un utilisateur connecté, alors il pourra seulement lire le texte, mais ne pourra pas voir les explications du lexique.
[   4]Chercher dans le lexique
[  21]Largeur de l'image:
[  22]La largeur de l'image.
[  23]Largeur de l'image sur téléphones:
[  24]La largeur de l'image lorsqu'elle est affichée sur un téléphone ou un appareil portable à petit écran.

