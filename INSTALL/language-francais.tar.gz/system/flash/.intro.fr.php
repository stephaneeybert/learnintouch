[   0]L'Intro Flash
[   1]Un site web peut avoir une introduction Flash.\n\nL'introduction Flash est affichée avant les pages du site web.\n\nL'introduction Flash peut aussi être affichée dans une fenêtre popup.
[   2]Télécharger et paramétrer une animation Flash
[   3]Les préférences
[   4]Obtenir le lecteur Flash
