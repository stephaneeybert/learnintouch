[   1]Cacher l'intro Flash:
[   2]Afficher l'intro Flash dans une fenêtre popup:
[   5]Texte du lien pour passer l'intro Flash:
[  11]Largeur de la fenêtre popup d'intro Flash:
[  12]Hauteur de la fenêtre popup d'intro Flash:
[  13]Afficher l'intro Flash une seule fois par visite:
[  14]Position haute de la fenêtre popup de l'intro Flash:
[  15]Position gauche de la fenêtre popup de l'intro Flash:
[  18]Couleur de fond de la page d'intro Flash:
[  19]Périodicité de l'affichage:
[  20]Passer l'intro Flash
[  31]L'intro Flash peut être cachée.\n\nDans ce cas, elle n'est pas affichée dans le site web.
[  32]L'intro Flash peut n'être affichée qu'une seule fois durant une visite.\n\nCela permet aux visiteurs de ne pas être ennuyés par un affichage répété de l'intro Flash durant leur visite.\n\nUne visite se termine lorsque le visiteur ferme son navigateur.
[  33]Par défault l'intro Flash est affichée à chaque visite.\n\nMême si elle n'est affichée qu'une seule fois par visite, cela peut quand même être ennuyeux pour le visiteur si plusieurs visites sont faites dans un court espace de temps.\n\nPour éviter cet affichage répété, une périodicité peut être spécifiée, durant laquelle l'intro Flash ne sera affichée qu'une seule fois, même si plusieurs visites sont faites.\n\nLa périodicité est exprimée en un nombre de jours.\n\nSi le nombre de jours est 0 (zéro) alors la périodicité n'est pas utilisée.\n\nPar exemple, un nombre de jours mis à 1 n'affichera l'intro Flash qu'une seule fois par jour pour chaque visiteur.
[  34]Par défault l'intro Flash est affichée dans la fenêtre principale du navigateur.\n\nMais elle peut à la place être affichée dans une fenêtre popup.
[  35]Une couleur est spécifiée à l'aide d'un code couleur hexadécimal.\n\nUn exemple est #AA00CC.
[  36]Un lien est affiché sous l'intro Flash.\n\nIl offre aux visiteurs un moyen de passer l'affichage de l'intro Flash.\n\nLe texte du lien peut être changé de sa valeur par défaut.
[  40]Si l'intro Flash est affichée dans une fenêtre popup, alors la largeur et la hauteur, et les positions haute et gauche de la fenêtre popup peuvent être spécifiées.
