[   0]Une animation Flash
[   1]Largeur:
[   2]Hauteur:
[   3]Couleur Flash:
[   4]Exemple Actionscript
[   5]Afin de récupérer le contenu du site web dans l'animation Flash, un fichier wddx est utilisé comme interface entre le site web et l'animation Flash.\n\nCe fichier wddx contenant les informations à jour du site web doit être lu depuis un actionscript.\n\nLe contenu de l'animation Flash peut ainsi être dynamiquement spécifié depuis le site web.\n\nLe codage en dur de contenu dans l'animation Flash est évité.\n\nDe cette façon, le contenu de l'animation Flash est automatiquement mis à jour lorsque le site web est édité.
[   6]Fichier Flash:
[   7]Sélectionner une couleur
[   8]Télécharger l'exemple d'actionscript
[  11]L'objet Flash peut recevoir sa largeur et sa hauteur en tant que paramètres.\n\nCela permet au programmeur Flash d'offrir un fichier Flash paramétrable.
[  12]Sélectionner un fichier Flash
[  13]Une couleur peut être passée à l'animation Flash.\n\nCette couleur est passée en paramètre au fichier Flash et peut être alors utilisée par le développeur Flash.\n\nNotez que cette couleur n'est pas la couleur de fond de la page affichant l'animation Flash.\n\nUn exemple est #AA00CC.
[  16]Télécharger ou effacer un fichier Macromedia Flash ou un fichier audio.\n\nDans le cas où le fichier téléchargé est un fichier audio et non un fichier Macromedia Flash alors le fichier audio sera joué automatiquement.
[  30]Passer l'intro Flash
