[   0]Les sites web importateur
[   1]Adresse web
[   2]D'autres sites web peuvent importer du contenu depuis votre site web.\n\nPour des raisons de sécurité, pour importer depuis votre site web, un autre site web doit d'abord être enregistré dans votre site web en tant que site web importateur.\n\nL'autre site web doit aussi enregistrer votre site web en tant que site web exportateur.
[   3]Effacer le site web
[   4]Ajouter un site web
[   5]Les sites web qui peuvent importer votre contenu.
[   7]En attente
[   8]La demande de permission n'a pas encore été accordée
[   9]Rejetée
[  10]Historique des imports par les autres sites web
