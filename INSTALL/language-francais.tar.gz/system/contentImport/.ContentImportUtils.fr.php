[   0]Une importation de contenu a été refusé
[   7]à
[   1]Un site web a essayé d'importer du contenu mais a été refusé l'accès.
[   2]\n\nLe nom de domaine du site web était:
[   3]\n\nLa tentative était soit illégitime soit le site web n'était pas correctement enregistré comme un site web importateur.\n\nDans ce dernier cas, veuillez vous assurer que le site web est enregistré dans la liste des sites web importateurs.
[   4]Vous n'avez pas encore demandé la permission d'accéder au site web
[   8]Vous ne pouvez pas accéder au site web parce que votre demande de permission a été refusé par
[   9]Vous ne pouvez pas accéder au site web parce que votre demande de permission est en cours à
[   5]Vous pouvez
[   6]demander la permission
[  10]Il n'a pas été possible de déterminer quel site web a essayé d'importer du contenu.
[  11]La demande de permission a été enregistré avec succès par le site web exportateur.
[  13]La demande de permission a échoué.
[  14]Le site web
[  15]a envoyé une demande de permission pour importer du contenu
[  16]Vous pouvez
[  17]accepter
[  18]ou
[  19]rejeter
[  20]la demande de permission.
[  21]Demande de permission d'import
[  22]Un site web a essayé d'importer du contenu mais avait une permission invalide.
[  23]Traitement de demande de permission
[  24]Le site web
[  25]a
[  26]refusé
[  27]accepté
[  28]votre demande de permission.
[  29]Vous ne pouvez pas importer du contenu du site web
[  30]Vous pouvez maintenant importer du contenu du site web
