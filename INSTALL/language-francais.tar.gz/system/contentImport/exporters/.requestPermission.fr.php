[   0]Demander une permission d'import
[   1]Avant de pouvoir importer du contenu d'un site web, il est nécéssaire de demander la permission du site web exportateur.\n\nUne fois que la permission a été accordée il est possible d'importer du site web exportateur.\n\nLe site web exportateur a le droit de refuser la demande de permission.\n\nLe site web exportateur sera notifé de votre demande.\n\nEt vous serez aussi notifé lorsque votre demande sera acceptée ou refusée.
[   2]Envoyer une demande de permission à
