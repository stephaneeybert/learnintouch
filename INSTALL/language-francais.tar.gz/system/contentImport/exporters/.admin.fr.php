[   0]Les sites web exportateur
[   1]Adresse web
[   2]Votre site web peut importer du contenu depuis d'autres sites web.\n\nPour importer depuis un autre site web, un autre site web doit être enregistré dans votre site web en tant que site web exportateur.\n\nUne fois que l'autre site web est enregistré, il est possible de voir son offre de contenu.\n\nPour des raisons de sécurité, votre site web doit aussi être enregistré dans l'autre site web en tant que site web importateur.
[   3]Effacer le site web
[   4]Ajouter un site web
[   5]Les sites web d'où vous pouvez importer.
[   6]Demander la permission d'importer du contenu
[   7]En attente
[   8]Refusé
