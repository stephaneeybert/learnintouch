[   0]Modifier une préférence
[   3]Texte:
[   1]Réinitialiser la préférence?
[   2]Réinitialiser la préférence en
