[   0]Les préférences
[   2]Modifier la valeur
[   1]Les préférences offrent des options de paramétrage pour le site web.\n\nElles permettent de personaliser le contenu et le fonctionnement du site web.
[   3]Sélectionner une couleur
[   4]Réinitialiser la valeur par défaut
[   5]Sélectionner une page du site web
[   6]Seul un super administrateur peut éditer les préférences.
[   7]Modifier la préférence dans toutes les langues
