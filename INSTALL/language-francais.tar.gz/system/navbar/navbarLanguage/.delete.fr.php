[   0]Effacer une langue d'une barre
[   1]Langue:
[   2]Effacer la langue de la barre?
