[   0]Modifier une langue dans une barre
[   7]Langue:
[   1]Une barre existe déjà pour la langue spécifié.
[  12]Une langue peut être assignée à une barre de navigation.\n\nSi tel est le cas, la barre de navigation est affichée seulement si sa langue est celle choisie par l'utilisateur visitant le site web.
