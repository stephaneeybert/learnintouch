[   0]Télécharger une image
[   1]Une barre de navigation peut utiliser des images.\n\nSi un élément d'une barre de navigation possède une image, alors l'image sera affichée à la place du nom de l'élément.\n\nDes images de petites dimensions peuvent ainsi être utilisées pour créer des barres d'icones.
[   2]Sélectionner une image:
[   3]Nom de l'image
[   6]Image:
[   7]Effacer l'image
[  27]Aucune image n'a été spécifiée.
