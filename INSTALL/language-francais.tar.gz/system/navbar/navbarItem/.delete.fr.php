[   0]Effacer un élément
[   1]Nom:
[   5]Description:
[   2]Effacer l'élément?
