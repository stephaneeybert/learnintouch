[   0]Modifier une barre de navigation
[   3]Masquer la barre de navigation:
[   8]Par défault une barre de navigation est visible et est affichée.\n\nMais elle peut être cachée. Dans ce cas, elle n'est pas affichée.\n\nCette fonctionalité offre un moyen facile de cacher momentanément une barre de navigation.
