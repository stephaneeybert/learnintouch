[   0]Une barre de navigation
[   1]Ajouter une langue à la barre
[   2]Modifier la barre
[   3]Effacer la langue de la barre
[   4]Langue
[   5]Langue
[   6]Description
[   7]Les barres de navigation offrent aux utilisateurs visitant le site web un moyen de naviguer au sein du site web.\n\nUne barre de navigation est composée d'une série d'éléments, chaque élément pointant vers une page web ou vers un site web.\n\nChaque élément est représenté par du texte ou par une image.\n\nUn élément qui est représenté par une image peut avoir une seconde image.\n\nCette seconde image s'affiche lorsque le curseur de la souris passe sur la première image de l'élément.
[   8]Insérer ou effacer une image
[   9]Changer la langue
[  10]Elément
[  11]Url
[  12]Ajouter un élément dans la barre
[  13]Insérer ou effacer une seconde image
[  14]Fermez la fenètre
[  15]pour la langue
[  16]Pour toutes les langues
[  17]Langue:
[  22]Modifier l'élément
[  23]Effacer l'élément
[  30]Intervertir avec le suivant
[  31]Intervertir avec le précédent
