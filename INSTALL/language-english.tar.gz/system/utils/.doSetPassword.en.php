[   1]Please, choose a new password at 
[   2]We have reset your password to
[   3]You can choose a new password.
[   4]First, log in at 
[   5]Then. change your password at
[   6]Kind Regards
