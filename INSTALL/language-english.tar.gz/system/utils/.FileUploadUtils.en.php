[   0]The maximum file size is
[   1]Kb.
[   2]Either the file is too big or the file is empty.
[   3]The file must have one of the following types:
[   4]Failed to upload the file
[  22]This file type is unauthorised.
[  23]The file size is larger than the allowed maximum file size.
[  27]No file has been specified.
