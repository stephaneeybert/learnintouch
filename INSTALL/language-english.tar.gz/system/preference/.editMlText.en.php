[   0]Edit a preference
[   3]Text:
[   1]Reset the preference?
[   2]Reset the preference in
