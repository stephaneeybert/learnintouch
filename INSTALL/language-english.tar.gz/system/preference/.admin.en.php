[   0]The preferences
[   1]The preferences offer some setup options for the web site.\n\nThey offer a way to customize the content and the functioning of the web site.
[   2]Edit the value
[   3]Select a color
[   4]Reset the default value
[   5]Select a page of the web site
[   6]Only a super administrator can edit the preferences.
[   7]Edit the preference in all languages
