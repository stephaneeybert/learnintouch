[   0]Change the password
[   1]Current Password:
[  10]Type in your current password for verification.
[   2]New Password:
[  11]Type in your new password.
[  12]Type in your new password again, to make sure you have typed it correctly.
[   3]Type in your current password first.\n\nThen type in and confirm your new password.
[   4]The current password is required.
[   5]The current password is incorrect.
[   6]The new password has not been correctly defined.
