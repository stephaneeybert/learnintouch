[   0]Delete an administrator
[   1]Delete the administrator?
[   2]An administrator cannot delete itself.
[   3]An administrator from the staff cannot be deleted.
[   4]Administrator name:
[   5]An administrator who is a news editor cannot be delete.\n\nDelete first the news editor.
