[   0]Change a password
[   2]New Password:
[   8]Confirm the new Password:
[   4]Change the password of the administrator:
[   3]Type in and confirm a new password for the administrator.
[   1]Only a super administrator can change the password of another administrator.
[   6]The new password has not been correctly defined.
