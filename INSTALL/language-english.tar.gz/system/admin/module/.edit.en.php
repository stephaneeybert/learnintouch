[   0]Administrator's modules
[   7]Administrator name:
[   9]Modules
[   8]Select the modules the administrator is allowed to use.\n\nThe modules that are not selected won't be accessible by the administrator.
