[   0]Edit an administrator
[   1]Firstname: *
[   2]Lastname: *
[   3]Address:
[   4]Zip Code:
[   5]City:
[   6]Country:
[   7]Email:
[   8]Login: *
[   9]Profile:
[  10]Preference admin:
[  11]By default, only a super administrator can edit the preferences.\n\nBut it is possible to allow a normal administrator to edit the preferences.
[  12]The firstname and the lastname are required.
[  13]The email address format is invalid.
[  14]The login name and the password have not been correctly defined.
[  15]This login name is forbidden.
[  16]You cannot access this page.
[  17]Post login page:
[  18]By default, the main menu of the administration panel is displayed after the administrator login.\n\nBut it is possible to specify a page within the administration panel, that is displayed after the administrator login.
[  19]A super administrator can create and delete other administrators.\n\nHe can also change the passwords of all the administrators.\n\nThere should therefore be as few as possible super administrators.\n\nThink twice before granting the 'super' right to an administrator.\n\nIdeally, there should be one or two super administrators.
[  20]Super admin:
