[   0]Last update on
[   1]Token login period (weeks):
[   2]Some pages of the administration panel can be accessed by the administrator by clicking on a link containing a token.\n\nFor example an email sent to an administrator can contain a link to view a contact message posted by a visitor of the website.\n\nTo offer an instant access to such a page it is preferred not to force the administrator to log into the administration panel before accessing the page.\n\nA login is thus offered in the link to the page.\n\nFor security reasons, it is possible to specify a validity period for this login.\n\nAfter the end of this period the login expires and the administrator must log in manually to access the page.\n\nThis period is expressed in weeks.\n\nIf no period is specified then the login in the link will never expire.
[   3]Number of administrators per page:
[   4]The list of administrators in the administration interface can display a chosen number of administrators per page.
[   5]You cannot access this page.
[   6]The participants subscriptions
[   8]The assignments results
[   9]The assignments given to a participant
[  10]The lessons
[  11]The exercises
