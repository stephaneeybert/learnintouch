[   0]Upload an image
[   6]Image:
[   3]Image name:
[   2]Select an image:
[   7]Delete the image?
[   1]A navigation link can have an image.\n\nIf a navigation link has an image, then the image will be displayed in place of the link name.
