[  20]A link for this language already exists.\n\nPlease choose another language.
[   0]Add a link for a language
[  19]Language:
[  21]A language can be assigned to a navigation link.\n\nIf so, the navigation link is only displayed if its assigned language is the one chosen by the user visiting the web site.
