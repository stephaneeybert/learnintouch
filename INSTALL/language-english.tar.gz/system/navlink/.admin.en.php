[   0]A navigation link
[   1]Add a link for a language
[   3]Delete the link
[   4]Language
[   7]The navigation links offer the users visiting the web site a way to navigate around the web site.\n\nA navigation links points to a web page or to a web site.\n\nIt is represented by some text or by an image.\n\nIf the web site uses several languages then the link can be defined in each of these languages.
[  10]Image/Text
[  13]For all languages
[  14]Close the window
[  15]for the language
[  22]Edit the link
