[   0]Delete an item
[   1]Text:
[   5]Description:
[   2]Delete the item?
