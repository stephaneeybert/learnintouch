[   0]For all languages
