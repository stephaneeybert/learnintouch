[   0]A navigation menu
[   1]Add a language to the menu
[   2]Edit the menu
[   3]Delete the language from the menu
[   4]Language
[   5]Language
[   6]Description
[   7]The navigation menus offer the users visiting the web site a way to navigate around the web site.\n\nA navigation menu is composed of a series of items, each item pointing to a web page or to a web site.\n\nEach element is represented by some text or by an image.\n\nAn element that is represented by an image can have a second image.\n\nThis second image is displayed when the mouse cursor passes over the first image of the element.
[   8]Insert or delete an image
[   9]Change the language
[  10]Item
[  11]Url
[  12]Add an item
[  13]For all languages
[  14]Close the window
[  15]for the language
[  16]Add a separator
[  17]Language:
[  19]Insert or delete a second image
[  22]Edit the item
[  23]Delete the item
[  30]Swap with next
[  31]Swap with previous
