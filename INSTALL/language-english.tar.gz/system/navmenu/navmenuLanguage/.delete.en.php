[   0]Delete a menu language
[   1]Language:
[   2]Delete the menu language?
