[   0]Edit a menu
[   3]Hide the menu:
[   8]By default a menu is visible and is displayed.\n\nBut it can be hidden. In that case, it is not displayed.\n\nThis feature offers an easy way to temporarily hide a menu.
