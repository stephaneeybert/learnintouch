[   0]Upload an image
[   6]Image:
[   3]Image name:
[   2]Select an image:
[   7]Delete the image?
[  27]No image has been specified.
[   1]A navigation menu can use images.\n\nIf an item of a navigation menu has an image, then the image will be displayed before the item name.
