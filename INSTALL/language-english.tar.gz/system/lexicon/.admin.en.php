[   0]The lexicon entries
[   1]Entry
[   2]Explanation
[   3]Edit the entry in the lexicon
[   4]Delete the entry from the lexicon
[   5]The lexicon is global to the website and its entries can be used on different types of contents in the website.\n\nThe entry is a word or short sentence.\n\nAn entry can thus be used several time on different contents.\n\nWhen editing or deleting an existing entry, note that the entry may already be used on one or more contents of the website.\n\nWhen editing or deleting an existing entry, note that the entry may already be used on one or more contents of the website.\n\nManage the lexicon with care as its entries are common to the whole website.
[   6]Add an entry to the lexicon
[   7]Search:
[   8]It can become tedious to navigate in the lexicon to find an entry.\n\nTo avoid this, it is possible to type in all or part of an entry and do a search based on the typed in text.\n\nThe search result will display all the entries matching the typed in text.
[   9]Image
[  14]Insert or delete an image
[  15]The preferences
