[   0]Add an entry
[   1]Entry:
[   2]Explanation:
[   3]The entry is required.
[   4]The explanation is required.
[   5]The entry is a word or short sentence.\n\nThe lexicon is global to the website and its entries can be used on different types of contents in the website.\n\nAn entry can thus be used several time on different contents.\n\nWhen editing or deleting an existing entry, note that the entry may already be used on one or more contents of the website.\n\nManage the lexicon with care as its entries are common to the whole website.
[   6]The explanation is a short text explaning the entry.
[   7]Edit an entry
[   8]When editing or deleting an existing entry, note that the entry may already be used on one or more contents of the website.\n\nManage the lexicon with care as its entries are common to the whole website.
[   9]All the lexicon entries
[  10]Note !
[  11]Add an image
[  12]Image:
[  13]A lexicon entry can also have an image apart from a text explanation.
[  14]Insert or delete an image
