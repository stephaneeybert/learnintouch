[   0]Delete an entry from the lexicon
[   1]Entry:
[   2]Explanation:
[   3]When editing or deleting an existing entry, note that the entry may already be used on one or more contents of the website.\n\nManage the lexicon with care as its entries are common to the whole website.
[   4]All the lexicon entries
[   5]Note !
