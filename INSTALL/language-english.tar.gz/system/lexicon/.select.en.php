[   0]Choose an entry in the lexicon
[   1]An entry is required.
[   2]Name:
[   3]Add an entry
[   4]Delete the entry from the lexicon
[   5]Edit the entry
[   7]To choose an entry, start typing in the entry. If the lexicon contains some entries matching the typed in characters then these entries will be suggested.\n\nIf no entry is suggested then it is possible to add the entry to the lexicon.\n\nOr if the suggested entry needs to be edited before being used, then the entry can be edited in the lexicon.\n\nBe carefull not to insert a lexicon entry on a word that already contains one.
[   8]All the lexicon entries
