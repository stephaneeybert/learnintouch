[   0]The Flash Intro
[   1]A web site can have a Flash introduction.\n\nThe Flash introduction is displayed before the pages of web site.\n\nThe Flash introduction can also be displayed in a popup window.
[   2]Upload and setup a Flash animation
[   3]The preferences
[   4]Get the Flash player
