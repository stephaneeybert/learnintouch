[   0]A Flash animation
[   1]Width:
[   2]Height:
[   3]Flash color:
[   4]Actionscript example
[   5]In order to retrieve the content of the website into the Flash animation, a wddx file is used as an interface between the website and the Flash animation.\n\nThis wddx file containing the up to date website information must be read from an actionscript.\n\nThe content of the Flash animation can thus be dynamically specified from the website.\n\nThe hard coding of content in the Flash animation is avoided.\n\nThis way, the content of the Flash animation is automatically updated when the website is edited.
[   6]Flash file:
[   7]Select a color
[   8]Download the example actionscript
[  11]The Flash object can receive its width and its height as parameters.\n\nThis allows the Flash developer to offer a customizable Flash file.
[  12]Select a Flash file
[  13]A color can be passed to the Flash animation.\n\nThis color is passed as a parameter to the Flash file and can be then used by the Flash developper.\n\nNote that this color is not the background color of the page displaying the Flash animation.\n\nA color is specified using an hexadecimal color code.\n\nAn example is #AA00CC.
[  16]Upload or delete a Macromedia Flash file or an audio file.\n\nIn case the uploaded file is an audio file and not a Macromedia Flash file then the audio file will be played automatically.
[  30]Skip the Flash intro
