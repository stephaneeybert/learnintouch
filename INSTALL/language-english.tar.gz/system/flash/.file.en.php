[   0]Upload a file
[   3]File name:
[   2]Select a file:
[   7]Delete the file?
