[   0]Validate the operation
[   1]Close the window
[   2]Logout from the administration panel
[   3]Back to the upper level
[   4]Thalasoft Web Solution
[   5]A product of Thalasoft.com
[   6]The name LearnInTouch and the software are registered at Copyright France.
