[   0]Confirm and validate the operation
[   1]Close the window
