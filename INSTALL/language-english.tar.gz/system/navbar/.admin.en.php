[   0]A navigation bar
[   1]Add a language to the bar
[   2]Edit the bar
[   3]Delete the language from the bar
[   4]Language
[   5]Language
[   6]Description
[   7]The navigation bars offer the users visiting the web site a way to navigate around the web site.\n\nA navigation bar is composed of a series of items, each item pointing to a web page or to a web site.\n\nEach element is represented by some text or by an image.\n\nAn element that is represented by an image can have a second image.\n\nThis second image is displayed when the mouse cursor passes over the first image of the element.
[   8]Insert or delete an image
[   9]Change the language
[  10]Item
[  11]Url
[  12]Add an item in the bar
[  13]Insert or delete a second image
[  14]Close the window
[  15]for the language
[  16]For all languages
[  17]Language:
[  22]Edit the item
[  23]Delete the item
[  30]Swap with next
[  31]Swap with previous
