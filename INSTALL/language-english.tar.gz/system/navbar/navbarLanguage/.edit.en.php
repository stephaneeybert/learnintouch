[   0]Edit a language in a bar
[   7]Language:
[   1]A bar already exists for the specified language.
[  12]A language can be assigned to a navigation bar.\n\nIf so, the navigation bar is only displayed if its assigned language is the one chosen by the user visiting the web site.
