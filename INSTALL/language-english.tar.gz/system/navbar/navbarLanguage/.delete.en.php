[   0]Delete a bar language
[   1]Language:
[   2]Delete the bar language?
