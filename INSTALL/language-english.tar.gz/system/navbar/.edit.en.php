[   0]Edit a navigation bar
[   3]Hide the navigation bar:
[   8]By default a navigation bar is visible and is displayed.\n\nBut it can be hidden. In that case, it is not displayed.\n\nThis feature offers an easy way to temporarily hide a navigation bar.
