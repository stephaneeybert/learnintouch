[   0]Upload an image
[   6]Image:
[   3]Image name:
[   2]Select an image:
[   7]Delete the image?
[  27]No image has been specified.
[   1]A navigation bar item can have an image.\n\nThat first image is displayed in place of the item name.\n\nIf it has an image, then it can also have a 'mouse over' image.\n\nThat second image is displayed when the mouse cursor passes over the first image.
