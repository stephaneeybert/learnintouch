[   0]Upload an image
[   6]Image:
[   3]Image name:
[   2]Select an image:
[   7]Delete the image?
[  27]No image has been specified.
[   1]A navigation bar can use images.\n\nIf an item of a navigation bar has an image, then the image will be displayed in place of the item name.\n\nImages of small dimensions can thus be used to create icon bars.
