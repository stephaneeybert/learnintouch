[   0]Select a location
[   6]Country:
[   3]Region:
[   4]State:
[   5]Zipcode:
[   1]To select a location, choose a country, then a state, then a region and finally a zipcode.
