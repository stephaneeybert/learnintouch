[   0]Handle an import permission
[   1]Before being able to import content from a website, it is necessary to request for the permission from the exporting website.\n\nOnce the permission is granted it will be possible to import from the exporting website.\n\nThe exporting website has the right to deny the request for permission.\n\nThe exporting website will be notified by email about your request.\n\nAnd you will also be notifed by email when you request has been granted or denied.
[   2]the permission request to
[   3]Grant
[   4]Deny
[   5]The permission request has been granted.
[   6]The permission request has been denied.
[   7]The permission request cannot be granted.\n\nThis website cannot export its content.
