[   0]The importing websites
[   1]Web address
[   2]Other websites may import content from your website.\n\nFor security reasons, to import from your website, another website must first be registered in your website as an importing website.\n\nThe other website must also register your website as an exporting website.
[   3]Delete the website
[   4]Add a website
[   5]The websites that can import your content.
[   7]Pending
[   8]The permission request hasn't yet been granted
[   9]Denied
[  10]History of the imports by other websites
