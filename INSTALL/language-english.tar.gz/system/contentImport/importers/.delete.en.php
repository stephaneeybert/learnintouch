[   0]Delete an importing website
[   1]Domain name:
