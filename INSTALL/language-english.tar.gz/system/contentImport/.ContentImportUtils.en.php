[   0]A content import was denied
[   7]to
[   1]A website has attempted to import some content but was denied access.
[   2]\n\nThe website domain name was:
[   3]\n\nThe attempt was either illegitimate or the website is not correctly registered as an importing website.\n\nIn that latter case, make sure that the website is registered in the list of importing websites.
[   4]You have not yet asked for the permission to access the website
[   8]You cannot access the website because your request for permission has been denied by
[   9]You cannot yet access the website because your request for permission is pending at
[   5]You can
[   6]request the permission
[  10]It was not possible to determine which website attempted to import content.
[  11]The permission request has been successfully registered by the exporting website.
[  13]The permission request has failed.
[  14]The website
[  15]has sent a permission request to import content
[  16]You can
[  17]grant
[  18]or
[  19]deny
[  20]the permission request.
[  21]Import permission request
[  22]A website has attempted to import some content but had an invalid key.
[  23]Import permission handling
[  24]The website
[  25]has
[  26]denied
[  27]granted
[  28]your permission request.
[  29]You cannot import content from the website
[  30]You can now import content from the website
