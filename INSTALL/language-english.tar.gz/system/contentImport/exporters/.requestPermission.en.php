[   0]Request an import permission
[   1]Before being able to import content from a website, it is necessary to request for the permission from the exporting website.\n\nOnce the permission is granted it will be possible to import from the exporting website.\n\nThe exporting website has the right to deny the request for permission.\n\nThe exporting website will be notified by email about your request.\n\nAnd you will also be notifed by email when you request has been granted or denied.
[   2]Send a request for permission to
