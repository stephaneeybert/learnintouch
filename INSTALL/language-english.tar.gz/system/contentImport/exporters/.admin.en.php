[   0]The exporting websites
[   1]Web address
[   2]Your website may import content from other websites.\n\nTo import from another website, the other website must be registered in your website as an exporting website.\n\nOnce the other website is registered it is possible to view its content on offer.\n\nFor security measures, your website must also be registered in the other website as an importing website.
[   3]Delete the website
[   4]Add a website
[   5]The websites you can import from.
[   6]Request the permission to import content
[   7]Pending
[   8]Denied
