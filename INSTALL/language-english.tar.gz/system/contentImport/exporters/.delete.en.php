[   0]Delete an exporting website
[   1]Domain name:
