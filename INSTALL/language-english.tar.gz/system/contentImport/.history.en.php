[   0]Import history
[   1]Website
[   2]Content
[   3]Date / Time
[   4]The contents imported by other websites.
[   5]Content:
[   6]Complete course
[   7]Individual lesson
[   8]Individual exercise
[   9]Website:
