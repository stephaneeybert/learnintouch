[   1]Web page:
[   3]Insert a link pointing to a page of the web site.
[   4]Cancel
[   5]Insert
[   6]New window:
[   7]Select a page of the web site
[   8]Model:
[   9]A model can be assigned to a navigation link.\n\nIn that case, the web page pointed to by the navigation link is displayed in the specified model.\n\nOtherwise, the web page is displayed in the current model.\n\nThis allows a website to display web pages in different models.\n\nFor example, there can be one default model for most of the web pages and another model for some web pages that are related to a particular event.
