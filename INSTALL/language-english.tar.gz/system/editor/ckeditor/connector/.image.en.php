[   0]Upload an image/flash file
[   2]Select a file:
[   1]The image/flash files are uploaded using the built in html editor.\n\nThe image/flash file is automatically inserted in the web page.
[   3]To use this image/flash file in a web page, insert the following link:
[   4]You can select the link and do a copy/paste using a mouse right click.
[   5]Resize to width:
[   6]When being uploaded to the server, an image can be resized to the specified width.\n\nIf no width is specified then the image is not resized.\n\nThe default width is taken from the larger image width in the preferences.

