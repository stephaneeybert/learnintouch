[   1]Web page:
[   3]Insert a link pointing to a page of the web site.
[   4]Cancel
[   5]Insert
[   6]New window:
[   7]Select a page of the web site
