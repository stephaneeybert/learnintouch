[   0]Upload an image/flash file
[   2]Select a file:
[   1]The image/flash files are uploaded using the built in html editor.\n\nThe image/flash file is automatically inserted in the web page.
[   3]To use this image/flash file in a web page, insert the following link:
[   4]You can select the link and do a copy/paste using a mouse right click.
