[   0]Download the audio file
[   1]HTML5 video player
[   2]Flash video player
[   9]Flash simple speaker for audio
[  11]Flash with controls for audio
