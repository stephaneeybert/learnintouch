[   0]Invite your friends
[   2]Note that your friends email addresses will not be not stored.
[   3]Email address: *
[   4]Password: *
[   5]Display the contacts
[   6]Your friends contacts could not be retrieved. Please, check the email address and password you have provided, or try again later.
[   7]Your friends contacts could not be retrieved. Please, try again later.
[   8]Service: *
[   9]The email address is required.
[  10]The message is required.
[  11]You can invite your friends to find out about our website, by sending them a message.
[  12]The password is required.
[  13]Select/Unselect all contacts
[  14]Send the message
[  15]At least one contact must be selected.
[  16]The invite has been sent to the following selected email addresses:
[  17]Message: *
[  18]Subject:
[  19]Choose a maximum of
[  20]contacts.
