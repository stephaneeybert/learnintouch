[   0]The email address or password is invalid.
[   1]No contact could be retrieved.
