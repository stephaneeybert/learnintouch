[   0]User registration
[   1]Type in your email address to complete your registration.
[   2]Email address: *
[   3]I would like to receive your emails
[   4]The email is required.
[   5]The email address format is invalid.
[   6]Register...
[   7]The firstname is required.
[   8]The lastname is required.
[   9]Firstname: *
[  10]Lastname: *
[  11]You are being logged in with your Facebook account.
[  12]You are being logged in with your LinkedIn account.
[  13]You are being logged in with your Google account.
[  14]You are being logged in with your Twitter account.
