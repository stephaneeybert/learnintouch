[   4]Post a message on Twitter
[   6]Message:
[   7]The message is required.
[  23]Send
