[   0]User registration
[   1]Type in your email address to complete your registration.
[   2]Email address:
[   3]I would like to receive your emails
[   4]The email is required.
[   5]The email address format is invalid.
[   6]Register...
