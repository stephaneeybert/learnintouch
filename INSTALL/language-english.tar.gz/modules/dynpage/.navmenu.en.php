[   0]Edit a web pages menu
[  12]Web page:
[  15]Select a page of the web site
[  25]Browse...
