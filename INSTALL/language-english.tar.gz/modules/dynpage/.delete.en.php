[   0]Delete a page
[   1]Name:
[   5]Description:
[   2]Delete the page?
