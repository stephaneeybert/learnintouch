[   0]The secured system pages
[   1]Like the web pages, the access to the system pages can also be secured.\n\nA secured system page will no longer be accessible by the visitors.\n\nIt will only be accessible by the users who would have logged in on the website.
[   2]Specify the entry page for the language
[   3]Page
[   4]Secured
[   5]The entry page for the computers
[   6]The entry page for the phones
[   7]Activate the page secured access
[   8]Deactivate the page secured access
[   9]The page is secured
