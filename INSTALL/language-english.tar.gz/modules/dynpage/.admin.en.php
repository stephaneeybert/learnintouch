[   0]The web pages
[   1]Create a new page
[   2]Compose the page
[   3]Put the page in the garbage
[   4]Image
[   5]Directories
[   6]The page is also a folder for other pages
[   7]Move into the page
[   8]Move after the page
[   9]A web page is composed of text and images.\n\nA page can be specified as the default one. It becomes the default page of the directory.\n\nThe default page of the directory is used in the bread crumbs navigation and in the navigation menu.\n\nFor the root directory '/', the default page is also the homepage of the website.
[  10]Move before the page
[  11]Rename the page
[  12]Compose the page
[  13]Duplicate the page
[  18]Preview the page
[  19]Display the page web address
[  20]The page web address is :
[  21]To create a link pointing to this page, copy and paste the above web address in the property of the html tag.
[  22]Current directory:
[  26]Move the page to another directory
[  27]The preferences
[  28]Move the page
[  29]Rename the directory
[  30]Swap with next
[  31]Swap with previous
[  32]The pages dumped in the garbage
[  33]Upload an image or a video
[  35]View the pages directory tree
[  36]Activate the page secured access
[  37]Deactivate the page secured access
[  38]The page is secured
[  39]The secured access to the predefined pages
[  40]Specify the entry page
[  41]Assign to an administrator
[  43]Print the page
[  44]Go to the page
[  70]Search:
[  71]It can become tedious to navigate in the directories of page a particular page.\n\nTo avoid this, it is possible to type in all or part of the name of a page and do a search based on the typed in text.\n\nThe search result will display all the pages matching the searched text.
