[   0]Move a web page
[   1]A web page can be moved under another page.\n\nTo move a web page, select the destination page.
[   2]Move under the page
[   3]Move under the root
[   7]Move the page:
