[   0]Secure a system page
[   1]System page:
[   2]Secure the system page?
[   5]Unsecure the system page?
[   3]Secure the system page
[   4]Unsecure the system page
