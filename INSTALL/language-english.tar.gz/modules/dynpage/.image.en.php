[   0]Upload an image
[   2]Select an image:
[   1]Images are normally uploaded using the built in html editor.\n\nThis is the simplest way to add an image since the image is automatically inserted in the web page.\n\nBut images can also be uploaded outside of the built in html editor.\n\nIt is not the recommended way of adding an image in a web page.\n\nBut it allows the upload of images for the browsers that do not support the built in html editor.\n\nIt is also possible to delete the uploaded images that are not used in the web pages.
[   3]To use this image in a web page, insert the following link:
[   4]You can select the link and do a copy/paste using a mouse right click.
[   5]Delete the unused images
[   6]Resize to width:
[   7]When being uploaded to the server, an image can be resized to the specified width.\n\nIf no width is specified then the image is not resized.\n\nThe default width is taken from the larger image width in the preferences.

