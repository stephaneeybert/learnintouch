[   0]Specify the entry page
[   1]Web page:
[   5]Language:
[   4]Browse...
[   2]Select a page of the web site
[   3]For each language, a page can be specified as being the entry page of the website.\n\nThe page will be displayed when a visitor arrives on the website.
[   7]The web page is selected in the list of the website pages.\n\nThe page must be a page of the web site.
