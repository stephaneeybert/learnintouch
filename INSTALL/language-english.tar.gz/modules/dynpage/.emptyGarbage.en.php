[   0]Empty the garbage
[   2]Permanently delete all the pages of the garbage?
