[   0]The garbage
[   1]Empty the garbage
[  11]Retrieve the page
[   7]Name
[   6]Description
[   9]When a web page is being deleted, it is actually stored in the garbage.\n\nThe pages can be retrieved from the garbage.\n\nEmptying the garbage permanently deletes all the pages stored in it.
