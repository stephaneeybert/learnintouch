[   0]The entry pages
[   1]For each language, a page can be specified as being the entry page of the website.\n\nThe page will be displayed when a visitor arrives on the website.
[   2]Specify the entry page for the language
[   3]Language
[   4]Web page
[   5]The entry page for the computers
[   6]The entry page for the phones
