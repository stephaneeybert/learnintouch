[   0]Create / Rename a page
[   2]Name the page
[   4]Name:
[   5]Description:
[   6]The name is required.
[   7]A page with this name already exists.
[   8]Hide the page:
[   9]By default a page is visible and is displayed in the navigation menu.\n\nBut it can be hidden. In that case, it is not displayed in the navigation menu.\n\nThis feature offers an easy way to hide a page of the web site.
[   3]A web page must have a name. \n\nThe name must be a single lower case word.
