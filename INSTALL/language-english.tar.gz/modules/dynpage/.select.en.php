[   0]Select a web page
[   1]To select a web page, navigate in the directories and choose a page.
