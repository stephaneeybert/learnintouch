[   0]Delete the unused images
[   2]Delete the images?
[   1]The images not used in the web pages can be deleted.\n\nIt is a good practice not to bloat the server with images that are not used any longer by the web site.
