[   0]Secure a directory
[   1]Directory:
[   2]Activate the directory secured access?
[   5]Deactivate the directory secured access?
[   3]Activate the directory secured access
[   4]Deactivate the directory secured access
