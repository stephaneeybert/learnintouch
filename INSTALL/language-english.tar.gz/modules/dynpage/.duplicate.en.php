[   0]Duplicate a page
[   2]Name the page
[   4]Name:
[   5]Description:
[   6]The name is required.
[   7]A page with this name already exists.
[   3]Type in the name and possibly the description of the web page.\n\nThe name is required and must be a single lower case word.
