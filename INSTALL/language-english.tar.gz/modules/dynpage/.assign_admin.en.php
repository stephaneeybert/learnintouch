[   0]Assign an administrator to a directory
[   1]Directory:
[   2]Administrator:
[   3]A directory can be owned by an administrator.\n\nIn that case, only the administrator can access the directory content.\n\nThe other administrators do not see the directory.
[  15]Select an administrator
[  25]Browse...
