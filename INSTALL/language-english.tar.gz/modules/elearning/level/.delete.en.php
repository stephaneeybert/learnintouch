[   0]Delete a level
[   1]Name:
[   5]Description:
[   2]Delete the level?
