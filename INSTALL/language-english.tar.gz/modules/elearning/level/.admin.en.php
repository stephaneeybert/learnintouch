[   0]The levels
[   1]Create a level
[   2]Edit the level
[   3]Delete the level
[   5]Name
[   6]Description
