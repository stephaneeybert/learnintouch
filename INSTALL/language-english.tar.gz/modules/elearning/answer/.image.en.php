[   0]Upload an image
[   6]Image:
[   3]Image name:
[   2]Select an image:
[   7]Delete the image?
[  27]No image has been specified.
[   1]An answer can have an image.
[   4]Resize to width:
[   5]When being uploaded to the server, an image can be resized to the specified width.\n\nIf no width is specified then the image is not resized.\n\nThe default width is taken from the larger image width in the preferences.

