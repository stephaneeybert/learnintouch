[   0]Edit an answer
[   2]Question:
[   4]Answer:
[   5]Insert a lexicon entry
[   6]Clear the selected lexicon
[  10]Explanation:
[  11]The explanation can be specific to each answer.\n\nIf an explanation is given for an answer then it overwrites the one given for the question.\n\nAn explanation about the question can be displayed under each question result.\n\nIt can give the participant some additional information about the question's solution and help him understand his possible mistake.\n\nAn example of explanation could be:\n\n'Eventually' is a false friend. Although you may think the translation is 'eventuellement', it actually is 'finalement'.\n\nTo display, the answer given by the participant, within the explanation text, use the sequence of three question mark characters '???'.\n\nThe explanation is thus typed in as:\n\n'Eventually' is a false friend. Although you may think the translation is '???', it actually is 'finalement'.
[  15]Save the explanation
