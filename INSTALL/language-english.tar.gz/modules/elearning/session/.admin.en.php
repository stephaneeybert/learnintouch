[   0]The sessions
[   1]Create a session
[   2]Edit the session
[   3]Delete the session
[   4]Courses
[   5]Status
[   6]Opening date
[   7]Closing date
[   8]Status:
[   9]Manually closed
[  10]A session is a period of time.\n\nIt can last from several weeks to several months or more.\n\nOnce a course is created, it can then be offered into successive sessions.\n\nA participant can subscribe to the session of a course.\n\nFor example, a participant can subscribe to the session of september for the course of "English for beginners".
[  11]The courses of the session
[  12]Not yet opened
[  13]Automatically closed
[  14]Currently opened
[  15]There are some more courses for the session
[  16]A session must at least have one course.\n\nIt can also have several courses.\n\nThe courses of the session, if more than one, are displayed in the list of the courses of a session.
[  17]The status of a session represents the session lifecycle.\n\nThe courses of a session are accessible by the participants only when the session is opened.
[  18]Classes
[  19]Not yet opened
[  20]Opened
[  21]Closed
[  22]A session may have one or more classes.\n\nThe classes of the session, if more than one, are displayed in the list of the classes of a session.
[  23]The courses
[  25]Name
