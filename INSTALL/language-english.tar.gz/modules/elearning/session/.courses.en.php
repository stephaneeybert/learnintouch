[   0]The courses of a session
[   1]Session:
[   2]Add a course:
[   3]All the courses are not necessarily programmed for the same sessions.\n\nSome courses can be programmed for a session while others will be programmed for another session.\n\nA session can have one or several courses.\n\nIf a session has several courses then all of these courses start and end at the same time.
[   4]Courses
[   5]Remove the course from the session
[   6]The sessions
[   7]Opening date:
[   8]There must first be some courses to be able to create a session.
[   9]The courses
[  10]Closing date:
[  11]Create a course...
