[   0]Delete a session
[   1]Participant:
[   2]Delete the session?
[   3]From
[   4]To
[   5]The session cannot be deleted because it has some participants subscriptions.
[   6]The session cannot be deleted because it has some courses.
[   7]The session cannot be deleted because it has some classes.
[   8]Click here to view the courses of the session.
[   9]Click here to view the classes of the session.
