[   0]Unsubscription
[   1]Unsubscription from the course:
[   2]It is possible to unsubscribe from a course.\n\nIn that case, all exercises results for the exercises of the course will be permanently deleted.
[   3]Unsubscribe
[   4]The subscription is required.
[   5]The subscription course does not allow the unsubscription.
[   6]Please tick the checkbox to confirm the unsubscription.
