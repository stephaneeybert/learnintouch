[   0]Send a mail
[   1]Session:
[   2]Send the mail?
[   3]Participant:
[   4]The message body...
[   5]Please, make sure some recipients are specified.\nThe mail cannot be sent.
[   6]Class:
[   7]The mail subject or mail body is empty.\nThe mail cannot be sent.
[   8]Session:
[   9]Note that users that have set their profile not to receive emails will not receive any.
[  10]Recipient:
[  18]The attached files...
[  20]Mail:
[  21]It is possible to choose a mail to be sent.
[  22]A mail is currently being sent.\n\nWait for it to complete before sending another mail!!
[  25]The last sending failed on some email addresses.\n\nIt is possible for you to send again the mail to the list of email addresses for which the sending of the mail had failed.
