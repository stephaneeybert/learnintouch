[   0]Subscription
[   1]Teacher:
[   2]Class:
[   3]Session:
[   4]Course:
[   5]Subscribe
[   6]The session is required.
[   7]The course is required.
[   8]The class is required.
[   9]The teacher is required.
[  10]The maximum number of subscriptions has been reached.\n\nContact the school to create your subscription.
[  11]Watch live:
[  12]The exercises of a course can be watched live by a teacher.\n\nIt is then possible for the teacher, to watch on his computer, the progress of the exercise while the participant is answering the questions.\n\nThe questions results will be displayed live to the teacher while the participant is doing the exercise.
[  13]You are already subscribed to this course.
[  14]You are already subscribed to this course for this session.
[  15]The participant is required.
