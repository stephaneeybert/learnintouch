[   0]Close a subscription
[   2]A date must have the format
[   3]The end date must be after the subscription date.
[   4]Closing date:
