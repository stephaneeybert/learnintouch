[   0]Delete a subscription
[   1]Participant:
[   2]Delete the subscription?
[   3]Note: This will also delete all the exercise results for this subscription!
