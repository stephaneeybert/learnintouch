[   0]Give a course
[   1]Class:
[   2]Course:
[   3]Only the selected participants will receive the course.
[   4]The course is required.
[   6]To the participants:
[   7]Select all
[  10]It is possible to give a course to one or more participants.\n\nAll the participants will then be able to do the course.\n\nFor example, it is possible to give a course to all the participants of a class.
[  15]Unselect all
