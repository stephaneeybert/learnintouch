[   0]A course of a participant
[   1]Participant:
[   2]Closed on:
[   3]Subscribed on:
[   4]View the lesson
[   5]Course:
[   6]Live results
[   7]Session:
[   8]The participant cannot yet access this exercise
[   9]Edit the exercise
[  10]Print the results
[  11]Compose the exercise
[  12]It is possible to watch the progress of the exercise while the participant is answering the questions.\n\nIn that case, the questions results will be displayed to the teacher while the participant is doing the exercise.\n\nThe teacher will be able to watch a graphical progression of each exercise.\n\nThe live results are displayed only when the participant is online and doing the exercise.\n\nIf the participant is inactive then a warning starts blinking.\n\nIf the participant is absent then nothing is displayed.
[  13]Done
[  14]Indicates if and when the participant has done the exercise.
[  15]Grade
[  16]The grade is a letter or some text that represents the performance of the participant.
[  17]Points
[  18]The points is the total of points for the correct answers given by the participant.\n\nBy default, an answer is worth one point, but it can be worth several points.
[  19]Answers
[  20]The number of correct answers and the number of incorrect Answers.
[  21]Results
[  22]The results is the number of correct answers by the number of questions.
[  23]Average grade of the participant:
[  24]Watch and assist the participant
[  25]The average grade is the average of all the grades of the exercises.
[  26]The shared board
[  71]from
[  72]until
[  90]Send the exercise results
[  91]View the exercise
[  94]Display the exercise results
[ 145]No subscriptions have been found.
[ 186]The graph of results
