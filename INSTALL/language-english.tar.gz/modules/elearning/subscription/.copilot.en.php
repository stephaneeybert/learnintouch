[   0]The participant has not yet started the exercise.
