[   0]Delete a subject
[   1]Name:
[   5]Description:
[   2]Delete the subject?
