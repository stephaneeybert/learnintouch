[   0]The subjects
[   1]Create a subject
[   2]Edit the subject
[   3]Delete the subject
[   5]Name
[   6]Description
