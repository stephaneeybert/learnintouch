[   0]The teachers
[   1]Create a teacher
[   2]Only a teacher with super administrator privilege can access this page.
[   3]Delete the teacher
[   8]Name
[   9]Email
[  10]The teachers are the persons who teach to the participants.\n\nThe teachers are chosen among the users of the website.\n\nTo create a new teacher, first create a user.
[  70]Search:
[  71]It can become tedious to navigate in the list of teachers to find a particular teacher.\n\nTo avoid this, it is possible to type in all or part of the name of a teacher and do a search based on the typed in text.\n\nThe search result will display all the teachers matching the searched text.
