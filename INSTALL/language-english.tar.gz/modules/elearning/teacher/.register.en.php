[   0]Teacher registration
[   1]By being a teacher, you can create your own courses, lessons and exercises, and offer them to your participants.
[   2]I would like to be a teacher:
[   3]Register as a teacher
[   4]You need to subscribe to be a teacher.
[   5]You are already a teacher.
