[   1]The teacher's office at
[   2]Welcome {*actor*} to LearnInTouch. You can now offer your own courses, lessons and exercises to your participants.
[   3]I wish to register as a teacher
