[   0]Edit a teacher
[   1]User:
[   2]A teacher is a registered user of the system.\n\nTo create a new teacher, first create a user.\n\nThen choose this newly created user to be a teacher.
[   3]The user is required.
[   4]This user is already a teacher.
[   5]Add a user
[  15]Select a user
[  25]Browse...
