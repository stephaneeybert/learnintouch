[   0]Edit the introduction
[   1]Cancel the operation
[   2]You have no right to use this lesson.
[   3]A lesson can have an introduction.\n\nThe introduction is part of the lesson content and is dispayed at the beginning of the lesson.
