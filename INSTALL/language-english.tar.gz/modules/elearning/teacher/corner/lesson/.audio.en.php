[   0]Upload an audio file
[   1]A lesson can have an audio file.\n\nThe audio file can be played by the user.
[   2]Kb.
[   3]File name:
[   4]Validate the operation
[   5]Select a file:
[   6]Audio file:
[   7]Cancel the operation
[   8]Delete the audio file?
[  11]You have no right to use this lesson.
[  27]No audio file has been specified.
