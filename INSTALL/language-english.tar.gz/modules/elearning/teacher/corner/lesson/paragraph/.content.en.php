[   0]Edit the text of the paragraph
[   1]Cancel the operation
[  11]You have no right to use this paragraph.
