[   0]Upload an image
[   1]A lesson paragraph can have an image.\n\nThe image is displayed under the paragraph headline.
[   2]Select an image:
[   3]Image name:
[   4]Validate the operation
[   5]Delete the image?
[   6]Image:
[   7]Cancel the operation
[  11]You have no right to use this lesson.
[  27]No image has been specified.
[   8]Resize to width:
[   9]When being uploaded to the server, an image can be resized to the specified width.\n\nIf no width is specified then the image is not resized.\n\nThe default width is taken from the larger image width in the preferences.

