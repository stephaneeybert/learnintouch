[   0]Edit a lesson paragraph
[   1]Heading:
[   2]Lesson: *
[   3]The paragraph headline is required.
[   4]Headline: *
[   6]Exercise link:
[   7]Exercise link text:
[   8]By default, the link to the exercise displays the name to the exercise.\n\nBut it is possible to display another link text to the exercise.
[   9]It is possible to display at the bottom of each paragraph, a link to an exercise.\n\nA lesson can then become an entry point to a set of exercises related to the lesson.
[  11]A paragraph can be put in the heading of a lesson model.\n\nA paragraph can also have a link to an exercise.\n\nA lesson can then become an entry point to a set of exercises related to the lesson.
[  20]Cancel the operation
[  21]Validate the operation
[  22]It is possible to move the paragraph into another lesson.\n\nTo choose a lesson, type in all or part of the name of a lesson and do a search based on the typed in text.\n\nThe search result will display all the lessons matching the searched text.
[  23]Video:
[  24]A video from a service like YouTube, Vimeo or other, can be displayed in the page of questions.\n\nThe video is inserted in the page, with a copy/paste of its html code.
[  25]Video url:
[  26]The video can also be accessible with an html link.\n\nIn that case, the video is displayed in a new page on the website hosting the video.
