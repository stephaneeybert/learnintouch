[   0]A lesson is composed of an introduction and a series of paragraphs.\n\nA paragraph of a lesson may be composed of a headline, a header, a body and a footer and a link to an exercise.\n\nDuring a lesson, by default, all the paragraphs are displayed on one page.
[   1]Edit the text of the paragraph
[   2]The teacher's courses
[   3]Add a lesson paragraph
[   4]Delete the lesson and all its paragraphs
[   5]Delete the paragraph
[   6]Edit the paragraph
[   7]Upload or delete an image or a Flash file
[   8]Edit the instructions
[   9]Compose a lesson
[  10]Lesson:
[  15]Add a question to the page of questions
[  26]Print the lesson
[  27]Upload or delete an audio or a Flash file
[  34]Preview the lesson
[  40]Edit the lesson
[  41]Upload or delete an image or a Flash file
[  42]Upload or delete an audio or a Flash file
[  43]Edit the introduction
[  52]Print the paragraph
