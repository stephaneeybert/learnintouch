[   0]Delete a lesson
[   1]Name:
[   2]Delete the lesson?
[   3]This lesson has some exercises that have already been used and have some results.\n\nDeleting the lesson will NOT delete the exercises.\n\nThe exercise and results will be kept.
[   4]Delete the exercises:
[   5]Description:
[   6]The lesson paragraphs may have exercises.\n\nIt is possible to delete the exercises with the lesson.
[   7]An exercise
[   8]The exercises:
[  10]Cancel the operation
[  11]You have no right to delete this lesson.
