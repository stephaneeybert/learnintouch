[   0]Edit a lesson
[   1]Cancel the operation
[   3]The name is required.
[   4]The course is required.
[   5]A lesson with the specified name already exists.
[   6]Name: *
[   7]Validate the operation
[   8]Description:
[   9]Course: *
[  10]You have no right to edit this lesson.
