[   0]Edit the instructions of a page of questions
[   2]Cancel the operation
[   4]Name:
[   7]Validate the operation
[  10]Some instructions on how to do the exercise can be displayed at the beginning of a page of questions.\n\nThese instructions are here to help the participant answer the questions of the page.\n\nThey are not supposed to be part of the course content.
[  11]You have no right to use this exercise.
[  12]Reset the instructions
