[   0]Duplicate an exercise page
[   1]Exercise page:
[   7]Duplicate the exercise page?
[  10]Cancel the operation
[  11]You have no right to use this exercise.
