[   0]Delete an exercise
[   1]Name:
[   2]Delete the exercise?
[   3]This exercise has already been used and has some results.\n\nDeleting the exercise will also delete the detailed results of each question.\n\nBut the exercise grades and points will be kept.
[   5]Description:
[   8]The exercise is used in the following lessons:
[   9]The exercise must be removed from these lessons before being deleted.
[  10]Cancel the operation
[  11]You have no right to delete this exercise.

