[   0]Edit an exercise
[   1]Cancel the operation
[   3]The name is required.
[   4]The course is required.
[   5]An exercise with the specified name already exists.
[   6]Name: *
[   7]Validate the operation
[   8]Description:
[   9]Course: *
[  10]You have no right to edit this exercise.
[  11]The maximum duration must be a number of minutes
[  12]Maximum duration:
[  13]By default, the exercises do not have a maximum duration.\n\nThe participants can take all their time to do an exercise.\n\nIt is also possible to have a maximum duration identical to all the exercises.\n\nAnd it is finally possible to have a maximum duration specific to an exercise so as to have exercises with different maximum durations.\n\nThe duration is expressed in minutes.
[  20]Tabs as page numbers:
[  21]By default, the exercise page tabs are displayed using the names of the pages of questions.\n\nBut it is possible to display the tabs as, or with, numbers.
[  22]Hide the special letters keyboard:
[  23]By default, when displaying a page of questions that require the participant to type in the answers, a series of letters is displayed on top of the page.\n\nThese letters are the ones that may be missing from the keyboard of the computer used by the participant.\n\nIt is possible to hide this on-screen keyboard.
[  53]As page numbers
[  54]With page numbers
