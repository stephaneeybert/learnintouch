[   0]Upload an audio file
[   1]An exercise can have an audio file.\n\nThe audio file is played before the user answers the exercise questions.
[   2]Kb.
[   3]File name:
[   4]Validate the operation
[   5]Select a file:
[   6]Audio file:
[   7]Cancel the operation
[   8]Delete the audio file?
[  11]You have no right to use this exercise.
[  27]No audio file has been specified.
