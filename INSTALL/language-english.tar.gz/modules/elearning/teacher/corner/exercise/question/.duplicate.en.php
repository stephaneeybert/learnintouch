[   0]Duplicate a question
[   1]Question:
[   5]Points:
[   7]Duplicate the question?
[  10]Cancel the operation
[  11]You have no right to use this exercise.
