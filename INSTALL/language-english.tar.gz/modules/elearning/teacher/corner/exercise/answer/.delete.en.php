[   0]Delete an answer
[   1]Answer:
[   2]Delete the answer?
[   3]This answer has already been used and has some results.\n\nDeleting the answer will also delete the detailed results of the answer.\n\nBut the results of the other answers will not be deleted and the exercise grades and points will be kept.
[  10]Cancel the operation
[  11]You have no right to delete this answer.
