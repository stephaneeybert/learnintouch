[   0]Remove an exercise from a course
[   1]When an exercise is removed from a course, the exercise is not deleted.\n\nIt is simply removed from the list of exercises composing the course.\n\nThe exercise can be used by other courses.
[   2]Course:
[   4]Name:
[   5]Description:
[   6]Validate the operation
[   7]Cancel the operation
[  10]You have no right to use this course.
[  11]You have no right to use this exercise.
