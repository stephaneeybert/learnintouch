[   0]The teacher's courses
[   1]Add a lesson
[   2]Add a course
[   3]Edit the exercise
[   4]Compose the exercise
[   5]Edit the lesson
[   6]Compose the lesson
[   7]Edit the course
[   8]Add an exercise
[   9]Remove from the course
[  10]Delete the exercise
[  11]Delete the lesson
[  12]Preview the exercise
[  13]Preview the lesson
[  14]Print the exercise
[  15]Print the lesson
[  16]Send by email
[  17]Add the lesson to a course
[  18]Add the exercise to a course
[  19]Move after
[  20]A course
[  21]A lesson of the course
[  22]An exercise of the course
[  23]An exercise of the lesson
[  24]A course is composed of a series of lessons and exercises.\n\nFor example, a course can be "English for beginners".\n\nBefore adding lessons and exercises to a course, the course must be created.\n\nClick on the icon to add a course.
[  25]You have not created any course yet.
[  26]You can
[  27]create a course.
