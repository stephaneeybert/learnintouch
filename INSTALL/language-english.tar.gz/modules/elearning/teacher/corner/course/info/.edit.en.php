[   0]Create or modify a course information
[   1]Your courses, your lessons, your exercises...
[   2]Add a course information
[   3]The headline is required.
[   6]Headline: *
[   7]Validate the operation
[   8]Information:
[  10]You have no right to edit this course.
[  13]Cancel the operation
