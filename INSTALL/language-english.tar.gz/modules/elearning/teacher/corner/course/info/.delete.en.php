[   0]Delete a course information
[   4]Headline:
[   5]Information:
[   6]Validate the operation
[   7]Cancel the operation
[  10]You have no right to use this course.
