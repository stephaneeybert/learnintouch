[   0]The course information
[   1]Edit the course information
[   2]Add a course information
[   3]The teacher's courses
[  10]Delete the course information
[  24]The course information is composed of a series of headlines and associated texts.\n\nThe course information is a detailed description of the course content.\n\nIt can contain several pages each composed of a headline and a text.\n\nIt allows the participant to know more about the course before subscribing to it.
[  25]You have not created any course information yet.
[  26]You can create a course information by
[  27]clicking here
