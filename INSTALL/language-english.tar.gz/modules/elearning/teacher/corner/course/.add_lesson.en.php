[   0]Add a lesson to a course
[   1]A course is composed of a series of lessons and/or exercises.\n\nA course can have an unlimited number of lessons and/or exercises.
[   2]Course:
[   3]The lesson is already assigned to this course.
[   4]Name:
[   5]Description:
[   6]The course is required.
[   7]Validate the operation
[   8]Cancel the operation
[  10]You have no right to use this course.
[  11]You have no right to use this lesson.
