[   0]Delete a teacher
[   1]Email:
[   2]Delete the teacher?
[   6]Name:
