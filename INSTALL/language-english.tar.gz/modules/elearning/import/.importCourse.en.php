[   0]Import a course
[   1]Name:
[   2]Description:
[   3]A course with the specified name already exists.
[   4]A matter must be selected so as to import the course.
[   5]Import into the matter:
[   6]A matter must be chosen so as to import the course.\n\nThe imported course will have the selected matter.
[   7]Exercise:
[   8]The course could not be accessed.
[   9]Lesson:
[  10]The course has been successfully imported.
[  12]The course could not be imported.
[  13]Course:
[  14]View the imported course
