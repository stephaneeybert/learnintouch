[   0]Import a lesson
[   1]Name:
[   2]Description:
[   3]A lesson with the specified name already exists.
[   4]The lesson could not be accessed.
[   5]The lesson has been successfully imported.
[   6]The lesson could not be imported.
[   7]Lesson:
[   8]View the imported lesson
