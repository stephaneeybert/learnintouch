[   0]Import an exercise
[   1]Name:
[   2]Description:
[   3]An exercise with the specified name already exists.
[   4]The exercise could not be accessed.
[   5]The exercise has been successfully imported.
[   6]The exercise could not be imported.
[   7]Exercise:
[   8]View the imported exercise
