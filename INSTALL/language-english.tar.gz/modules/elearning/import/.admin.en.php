[   0]Courses import
[   1]Course
[   2]Description
[   3]The websites you can import content from
[   4]Import the course and all its lessons and exercises
[   5]Exporting website:
[   6]The websites that can import your content
[   7]Matter:
[   8]Register a website which you can import content from
[   9]Select a website which you can import content from
[  10]It is possible to import courses from a website.\n\nThe list displays all the courses that can be imported from a website.\n\nThe website must first be registered as an exporting website.\n\nWhen importing a course, the course itself and all its content is imported.
[  11]Course item
[  12]Import the lesson or exercise
[  13]Course:
[  14]Search:
[  15]Instead of selecting a matter and a course, it is possible to type in all or part of the name of a course, a lesson or an exercise, and do a search based on the typed in text.\n\nThe search result will display all the courses, lessons and exercises matching the searched text.
[  16]Select a matter to display its courses.
[  17]Select a course to display its lessons and exercises.
[  18]Exercise
[  19]Lesson
[  20]The searched text must contain at least 4 characters.
[  21]Others:
[  22]It is possible to browse in the other exercises and lessons, including those that do not belong to a course.
