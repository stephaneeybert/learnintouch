[   0]Delete a matter
[   1]Name:
[   5]Description:
[   2]Delete the matter?
[   3]The matter cannot be deleted because it is used by some courses.
