[   0]The matters
[   1]Create a matter
[   2]Edit the matter
[   3]Delete the matter
[   5]Name
[   6]Description
[   7]A matter is the type of content of the courses.\n\nFor example, a matter can be French or English, etc...
