[   0]The exercises results
[   1]Grade
[   2]Delete all the results of the exercise
[   3]Delete the result
[   4]Class
[   5]Exercise
[   6]Print the results
[   7]Teacher:
[   8]Since:
[   9]Exercise:
[  10]Delete all the results of the subscription
[  11]Session:
[  12]Participant:
[  13]View the results
[  14]Write and send a comment
[  15]The grade is a letter or some text that represents the performance of the participant.
[  16]The exercise has been done on
[  17]Exercise
[  18]Average grade of the participant:
[  19]The results ranges
[  20]The participant subscribed on
[  21]The average grade is the average of all the grades of the exercises.
[  22]The participant is not subscribed
[  23]Course:
[  24]Class:
[  25]Without session
[  26]Average grade of the participants:
[  27]Points
[  28]Send by email
[  29]The points is the total of points for the correct answers given by the participant.\n\nBy default, an answer is worth one point, but it can be worth several points.
[  30]Results
[  31]Participant
[  32]Course
[  33]The participant subscription
[  34]The results is the number of correct answers by the number of questions.
[  35]Answers
[  36]The number of correct answers and the number of incorrect Answers.
[  37]The graph of results
[  43]One week
[  44]One month
[  45]Three months
[  46]Six months
[  47]One year
[  48]Since:
[  70]Search:
[  71]It can become tedious to navigate in the list of results to find a particular result.\n\nTo avoid this, it is possible to type in all or part of the name of a person or an email address and do a search based on the typed in text.\n\nThe search result will display all the persons matching the searched text.
