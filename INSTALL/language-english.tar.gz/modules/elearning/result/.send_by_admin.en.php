[   0]Send the exercise results
[   1]Of the exercise:
[   3]Done by:
[   4]On:
[   5]To:
[   2]Send the exercise results?
[   8]Exercise
[   6]The exercise results has been sent to you.
[   9]To do the exercise, click on its name:
[   7]Best Regards
[  40]The email address is required.
[  38]The email address format is invalid.
[  10]See the exercise content...
