[   0]Exercise name:
[   1]You have
[   2]The results of your exercise at
[   3]Date:
[   4]Description:
[   5]An exercise from
[   6]has been done
[   7]The visitor
[   8]has done the exercise
[   9]The visitor
[  10]The exercise results can also be viewed by
[  11]click here
[  12]clicking here
[  13]can be contacted at
[  14]The exercise had a duration of
[  15]The exercise was completed in
[  16]The visitor has left the message:
[  17]Exercise results
[  18]A comment on your exercise results at
[  20]Course results
[  21]Point(s)
[  22]point(s) for
[  23]Class:
[  24]Participant:
[  25]Do the exercise
[  26]correct answer(s) out of
[  27]questions
[  28]Comment:
[  29]You have not answered
[  30]You have answered
[  31]participant(s)
[  32]You can
[  33]send a results comment
[  34]to the participant.
[  35]A teacher has written the following comment:
[  36]Best Regards
[  37]on your results for the exercise:
[  38]The participant is inactive
[  39]The participant has completed the exercise
[  40]Grade
[  41]The grade is a letter or some text that represents the performance of the participant.\n\nEach grade corresponds to a range of percentages.
[  42]Results
[  43]The results is the number of correct answers by the number of questions.
[  44]Points
[  45]The points is the total of points for the correct answers given by the participant.\n\nBy default, an answer is worth one point, but it can be worth several points.
