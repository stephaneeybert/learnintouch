[   0]Send a comment
[   1]Send a results comment to the participant.
[   2]The comment has been sent to the participant.
[   3]Send
[   4]Comment:
[   5]The comment is required.
[   6]After an exercise has been done, it is possible for a teacher to write a comment on the results of the exercise.\n\nThe comment will be sent to the participant and saved with the exercise results.
[   7]You are not allowed to view these exercise results.
