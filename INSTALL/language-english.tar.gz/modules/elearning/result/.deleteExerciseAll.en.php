[   0]Delete the results of an exercise
[   1]Name
[   5]Exercise:
[   2]Delete the exercise results?
[   3]Email
