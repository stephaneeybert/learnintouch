[   0]An exercise results
[   1]Grade
[   2]Exercise:
[   3]Done:
[   4]The exercise had a duration of
[   5]The exercise was completed in
[   6]Print the results
[   7]Message:
[   8]The grade is a letter or some text that represents the performance of the participant.
[   9]Points
[  10]Reading
[  11]Writing
[  12]Listening
[  13]Total
[  14]No exercise was found for the results.\n\nThe results have now been deleted.
[  15]The points is the total of points for the correct answers given by the participant.\n\nBy default, an answer is worth one point, but it can be worth several points.
[  16]Comment:
[  17]Write and send a comment
[  18]An exercise
[  19]Delete the result
[  20]point(s)
[  21]Solution(s):
[  22]Point(s):
[  23]Results
[  24]The results is the number of correct answers by the number of questions.
[  25]Answers
[  26]The number of correct answers and the number of incorrect Answers.
[  27]Participant:
[  28]Send by email
[  29]Email:
[  30]Live results:
[  31]It is possible to watch the progress of the exercise while the participant is answering the questions.\n\nIn that case, the questions results will be displayed to the teacher while the participant is doing the exercise.\n\nThe teacher will be able to watch a graphical progression of each exercise.\n\nThe live results are displayed only when the participant is online and doing the exercise.\n\nIf the participant is inactive then a warning starts blinking.\n\nIf the participant is absent then nothing is displayed.
