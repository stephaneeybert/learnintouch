[   0]Delete all the results of a subscription
[   1]Name:
[   5]Subscription:
[   2]Delete all the subscription results?
[   3]Email:
