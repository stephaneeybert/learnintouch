[   0]The results ranges
[   1]Create a range
[   2]Edit the range
[   3]Delete the range
[   4]Grade
[   5]Upper
[   9]By default, the exercises results are displayed in numbers of correct answers given by the participant.\n\nBut the number of correct answers is not always the most expressive representation.\n\nRendering the results as a grade, using a letter or a word, can be more expressive.\n\nEach grade is associated with a range that corresponds to a percentage of correct answers.\n\nFor example, the grade 'A' can be given for a percentage of correct answers of 80 to 100, the grade 'B' can be given for a percentage of correct answers of 60 to 79, etc...
