[   0]Edit a result range
[   1]Grade:
[   2]Upper:
[   3]The grade is required.
[   4]Each grade is associated with a range that corresponds to a percentage of correct answers.\n\nThe grade can be a letter, like A, B, C, etc... or it can be a short text, like Very Good, Good, etc...
[   6]The upper range percentage is required.
[  12]The upper range percentage must be between 1 and 100.
[  14]A range is described by two values.\n\nOnly the upper range value needs to be specified.\n\nThe lower range value being the upper range value of the preceding range.\n\nThe value must be a number between 1 and 100.
