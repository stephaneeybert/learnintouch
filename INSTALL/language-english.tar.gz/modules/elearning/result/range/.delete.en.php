[   0]Delete a result range
[   1]Max:
[   5]Grade:
[   2]Delete the result range?
