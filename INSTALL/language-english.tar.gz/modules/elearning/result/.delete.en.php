[   0]Delete an exercise results
[   1]Participant:
[   5]Exercise:
[   2]Delete the exercise results?
