[   0]Write a comment
[   1]Hide the comment:
[   2]By default the comment can be read by the participant.\n\nBut in case the comment is sensitive, it is possible to hide it so that the participant cannot read it.\n\nIn that case, only the teacher will be able to view the comment.
[   3]Send the comment:
[   4]Comment:
[   5]The comment can be sent to the participant.
[   6]After an exercise has been done, it is possible for a teacher to write a comment on the results of the exercise.
