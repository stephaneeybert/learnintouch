[   0]An assignment
[   1]Participant:
[   2]Exercise:
[   3]The participant is required.
[   4]The exercise is required.
[   7]The exercise is already given to the participant.
[   8]Only once
[   9]By default, a participant can do an assignment several times over.\n\nBut it is possible to only allow him to do the assignment once.\n\nIn that case, the participant will not be able to do the assignment a second time.\n\nEven if the participant can do the assignment more than once, his results are not saved again.\n\nThe results are saved only the first time the assignment is done.
[  10]It is possible to give an assignment to a participant.\n\nThe participant will then have to do the assignment.\n\nA participant can receive several assignments.
[  11]Opening date:
[  12]If an opening date is specified then the assignment will not be available before the opening date.
[  13]Closing date:
[  14]If a closing date is specified then the assignment will not be available after the opening date.
[  21]A date must have the format
[  34]The closing date must be greater than the opening date.
