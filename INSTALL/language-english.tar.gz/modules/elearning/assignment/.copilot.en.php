[   0]The participant has not yet started the exercise.
[   1]The subscription for the participant could not be found.
[   2]The participant could not be found.
