[   0]The assignments
[   1]A participant can be been given assignments.\n\nAn assignment is an exercise that the participant has to do.
[   2]The subscription is not currently opened.
[   3]Give an assignment
[   4]Exercise
[   5]Edit the assignment
[   6]Delete the assignment
[   7]Live results
[   8]It is possible to watch the progress of the exercise while the participant is answering the questions.\n\nIn that case, the questions results will be displayed to the teacher while the participant is doing the exercise.\n\nThe teacher will be able to watch a graphical progression of each assignment.\n\nThe live results are displayed only when the participant is online and doing the exercise.\n\nIf the participant is inactive then a warning starts blinking.\n\nIf the participant is absent then nothing is displayed.
[   9]Participant
[  11]Done
[  12]Opening
[  13]Closing
[  15]Indicates if and when the participant has done the assignment.
[  16]If an opening date is specified then the assignment will not be available before the opening date.
[  17]If a closing date is specified then the assignment will not be available after the opening date.
[  18]Participant:
[  19]Class:
[  20]The assignments results
[  21]Status:
[  22]By default, all assignments are displayed.\n\nBut it is possible to display only the ones available now, the ones available shortly or the closed ones.
[  23]Delete the closed assignments
[  24]Watch and assist the participant
[  25]Current
[  26]Shortly
[  27]Closed
[  28]View the results
