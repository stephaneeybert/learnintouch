[   0]Give an assignment
[   1]Class:
[   2]Exercise:
[   3]Only the selected participants will receive the assignment.
[   4]The exercise is required.
[   5]Participant:
[   6]To the participants:
[   7]Select all
[   8]Only once:
[   9]By default, a participant can do an assignment several times over.\n\nBut it is possible to only allow him to do the assignment once.\n\nIn that case, the participant will not be able to do the assignment a second time.\n\nEven if the participant can do the assignment more than once, his results are not saved again.\n\nThe results are saved only the first time the assignment is done.
[  10]It is possible to give an assignment to one or more participants.\n\nAll the participants will then be able to do the assignment.\n\nFor example, it is possible to give an assignment to all the participants of a class.
[  11]Opening date:
[  12]If an opening date is specified then the assignment will not be available before the opening date.
[  13]Closing date:
[  14]If a closing date is specified then the assignment will not be available after the opening date.
[  15]Unselect all
[  21]A date must have the format
[  34]The closing date must be greater than the opening date.
