[   0]Delete a participant assignment
[   1]Participant:
[   2]Exercise:
