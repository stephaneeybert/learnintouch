[   0]The assignments results
[   1]The results of the assignments are displayed live.
[   2]Class:
[   3]Suggest an assignment to the class
[   4]Exercise
[   5]Edit the class assignment
[   6]Delete the class assignment
[   7]Watch live
[   8]It is possible to watch the progress of the exercise while the participant is answering the questions.\n\nIn that case, the questions results will be displayed to the teacher while the participant is doing the exercise.\n\nThe teacher will be able to watch a graphical progression of each assignment as well as of all of the assignments together.
[   9]Done
[  10]Only once
[  11]Answers / Questions
[  12]Opening
[  13]Closing
[  14]By default, a participant can do an assignment several times over.\n\nBut it is possible to only allow him to do the assignment once.\n\nIn that case, the participant will not be able to do the assignment a second time.
[  15]The grade is a letter or some text that represents the performance of the participant.
[  16]Live results
[  17]It is possible to watch the progress of the exercise while the participant is answering the questions.\n\nIn that case, the questions results will be displayed to the teacher while the participant is doing the exercise.\n\nThe teacher will be able to watch a graphical progression of each exercise.\n\nThe live results are displayed only when the participant is online and doing the exercise.\n\nIf the participant is inactive then a warning starts blinking.\n\nIf the participant is absent then nothing is displayed.
[  18]Participant
[  19]Grade
[  20]View the results
[  21]Average grade of the participant:
[  22]Delete the result
[  23]Compose the exercise
[  24]View the participant
[  25]Participant:
[  26]Copilot with the participant
[  27]The answers is the number of answers given by the participants, including the correct and incorrect ones.\n\nThe questions is the number of questions for the exercise.
[  28]Indicates when the participant has done the assignment.
[  29]Session:
[  30]If a session is selected then only the assignments that the participants have done during the session will be displayed.\n\nThe assignments that the participants have not done during the session will not be displayed, even if they were supposed to be done at that time.
[  31]The assignments
[  32]Since:
[  33]The results ranges
[  34]Points
[  35]The points is the total of points for the correct answers given by the participant.\n\nBy default, an answer is worth one point, but it can be worth several points.
[  36]Results
[  37]The results is the number of correct answers by the number of questions.
[  38]Answers
[  39]The number of correct answers and the number of incorrect Answers.
[  40]The graph of results
[  41]The average grade is the average of all the grades of the exercises.
[  42]Average grade of the participants:
[  43]One week
[  44]One month
[  45]Three months
[  46]Six months
[  47]One year
[  48]The shared board
