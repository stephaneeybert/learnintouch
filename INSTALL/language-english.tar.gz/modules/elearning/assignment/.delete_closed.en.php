[   0]Delete the closed assignments of a participant
[   1]Participant:
[   2]Delete the closed assignments ?
