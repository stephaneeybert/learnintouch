[   0]Edit a class
[   4]Name:
[   5]Description:
[   6]The name is required.
