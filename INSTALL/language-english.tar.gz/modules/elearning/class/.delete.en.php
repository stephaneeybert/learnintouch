[   0]Delete a class
[   1]Name:
[   5]Description:
[   2]Delete the class?
[   3]There are some participants subscriptions for this class.\nThe participants subscriptions will not be deleted.\nHowever, they will not belong to a class any longer.
