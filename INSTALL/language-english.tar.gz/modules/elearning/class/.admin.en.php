[   0]The classes
[   1]Create a class
[   2]Edit the class
[   3]Delete the class
[   4]Give a course to the class participants
[   5]Name
[   6]Description
[   7]Send a mail to the class
[   8]Set the next exercise for a course of the class
[   9]Teacher:
[  10]A class is a group of people participating in one or several courses during a session.\n\nOn each new session, the class has new participants.
[  11]Add a participant to the class
[  12]The participants of the class
[  70]Search:
[  71]It can become tedious to navigate in the list of classes to find a particular class.\n\nTo avoid this, it is possible to type in all or part of the name of a class and do a search based on the typed in text.\n\nThe search result will display all the classes matching the searched text.
