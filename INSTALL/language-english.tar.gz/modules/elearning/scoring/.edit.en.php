[   0]Edit a scoring
[   1]Required score:
[   2]It is possible to specify a required score.\n\nIn that case, a message congratulating or encouraging the participant will be displayed in the scoring results.\n\nThe required score is expressed in percentage.
[   4]Name:
[   4]Name:
[   5]Description:
[   6]The name is required.
