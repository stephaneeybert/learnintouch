[   0]Delete a scoring
[   1]Name:
[   5]Description:
[   2]Delete the scoring and all its ranges?
[   3]The scoring cannot be deleted because it is used by some exercises.
