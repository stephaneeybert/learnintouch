[   0]Delete a scoring range
[   1]Max:
[   5]Score:
[   4]Advice:
[   6]Proposal:
[   2]Delete the scoring range?
