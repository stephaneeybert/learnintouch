[   0]Edit a scoring range
[   1]School advice:
[   2]Course proposal:
[   3]The score message is required.
[   4]Upper:
[   5]Participant level:
[   6]The upper range percentage is required.
[   7]Link text:
[   8]The link text is the text of the link to the web page.
[   9]The participant level is a text that gives an estimate of the level of the participant.\n\nIt can more or less felicitate the participant depending on the scoring range.
[  10]The school advice is a text that indicates what the participant should do.\n\nIt is a general recommendation which expresses the need of the participant.\n\nIt could mention official course names or levels.
[  11]The course proposal is a text that offers the participant to attend a course at the school, following the advice that was previously given to him.\n\nIt is the response to the need of the participant.\n\nIt is an invite for a subscription to a course.
[  12]The upper range percentage must be between 1 and 100.
[  13]Scoring:
[  14]A range is described by two values.\n\nOnly the upper range value needs to be specified.\n\nThe lower range value being the upper range value of the preceding range.\n\nThe value must be a number between 1 and 100.
[  15]Web page:
[  16]A link to a web page displayed below the scoring messages can offer to the participant, more information regarding the scoring proposition.
[  17]Select a page of the web site
[  18]Browse...
