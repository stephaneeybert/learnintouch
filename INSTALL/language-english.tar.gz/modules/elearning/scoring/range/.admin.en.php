[   0]The scoring ranges
[   1]Create a range
[   2]Edit the range
[   3]Delete the range
[   4]School advice
[   5]Upper
[   6]Participant level
[   7]Course proposal
[   8]Scoring:
[   9]A scoring is composed of several ranges.\n\nEach range corresponds to a percentage of correct answers.\n\nThe message in each range is split in three parts, a text about the level of the participant, a text about the school advice to the participant, and a text about a course proposal.\n\nOnly the first part of the message is required.
[  10]Web page
