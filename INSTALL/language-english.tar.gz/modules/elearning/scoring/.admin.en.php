[   0]The scorings
[   1]Create a scoring
[   2]Edit the scoring
[   3]Delete the scoring
[   4]The ranges
[   5]Name
[   6]Description
[   7]A scoring is the evaluation of the level of a participant using the results of the exercise.\n\nIf a scoring is specified for an exercise then a message corresponding to the level is displayed to the participant at the end of the exercise.\n\nA scoring is composed of several messages that are associated to percentages of correct answers.
