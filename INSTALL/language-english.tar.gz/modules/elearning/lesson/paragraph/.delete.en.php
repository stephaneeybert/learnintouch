[   0]Delete a paragraph
[   1]Paragraph:
[   2]Delete the paragraph ?
