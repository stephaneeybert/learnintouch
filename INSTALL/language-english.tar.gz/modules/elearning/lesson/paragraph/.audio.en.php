[   0]Upload an audio file
[   1]A paragraph can have an audio file.\n\nAn audio file is a file that can be streamed over the Internet to broadcast audio content.
[   2]Kb.
[   3]File name:
[   5]Select a file:
[   6]Audio file:
[   7]Delete the audio file?
[  27]No audio file has been specified.
