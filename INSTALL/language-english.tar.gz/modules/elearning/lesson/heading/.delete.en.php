[   0]Delete a lesson heading
[   1]Name:
[   5]Description:
[   2]Delete the lesson heading?
