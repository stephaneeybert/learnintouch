[   0]Edit the introduction
[   1]A lesson can have an introduction.\n\nThe introduction is part of the lesson content and is dispayed at the beginning of the lesson.
