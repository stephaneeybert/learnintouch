[   0]Edit the instructions of a lesson
[   1]Instructions:
[   4]Name:
[   5]Description:
[  11]Some instructions on how to do the lesson can be displayed at the beginning of a lesson.\n\nThese instructions are here to help the participant do the lesson.\n\nThey are not supposed to be part of the lesson content.
