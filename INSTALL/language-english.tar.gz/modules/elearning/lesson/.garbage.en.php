[   0]The garbage
[   1]Empty the garbage
[  11]Retrieve the lesson
[   7]Name
[   6]Description
[   9]When a lesson is being deleted, it is actually stored in the garbage.\n\nThe lesson can be retrieved from the garbage.\n\nEmptying the garbage permanently deletes all the lessons stored in it.
