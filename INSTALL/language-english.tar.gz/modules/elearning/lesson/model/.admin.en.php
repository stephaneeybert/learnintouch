[   0]The lesson models
[   1]Create a lesson model
[   2]Edit the lesson model
[   3]Delete the lesson model
[   4]Compose the lesson model
[   5]Name
[   6]Description
[   7]A lesson model is a set of headings composing a frame in which some lessons can be displayed.\n\nIf a lesson has a model then the lesson paragraphs are displayed within the headings of the model.\n\nThis allows for a common frame to be shared between several lessons.\n\nA lesson model also helps the content creator when creating a new lesson.\n\nThe creation of a new lesson is easier when following a model.
[   8]Lock the lesson model
[   9]Unlock the lesson model
