[   0]Delete a lesson model
[   1]Name:
[   5]Description:
[   2]Delete the lesson model?
