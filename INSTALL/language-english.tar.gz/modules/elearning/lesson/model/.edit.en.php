[   0]Edit a lesson model
[   4]Name:
[   5]Description:
[   6]The name is required.
