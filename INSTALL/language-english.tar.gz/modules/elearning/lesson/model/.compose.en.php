[   0]Compose a lesson model
[   1]Add a new heading
[   2]Delete the above heading
[   3]Are you sure you want to DELETE this heading ?
[   4]Name:
[   5]Description:
[   6]The name is required.
[   7]Heading text:
[   8]The heading name and text is displayed when displaying a lesson. It is the heading for one or more lesson paragraphs.\n\nThe lesson paragraphs are displayed within the headings of a lesson model.\n\nEach heading can contain several paragraphs.
[   9]Heading name:
[  10]Heading image:
[  11]Swap with the next heading
[  12]Swap with the previous heading
[  13]Upload or delete an image or a Flash file
[  14]Instructions:
[  15]Some instructions can be displayed to guide the content creator during the creation of a lesson.\n\nThese instructions are here to help the content creator.\n\nThey are not part of the lesson content and are not displayed in the lesson.
