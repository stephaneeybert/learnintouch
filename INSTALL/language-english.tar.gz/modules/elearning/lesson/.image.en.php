[   0]Upload an image
[   6]Image:
[   4]Resize to width:
[   5]When being uploaded to the server, an image can be resized to the specified width.\n\nIf no width is specified then the image is not resized.\n\nThe default width is taken from the larger image width in the preferences.
[   3]Image name:
[   2]Select an image:
[   7]Delete the image?
[  27]No image has been specified.
[   1]A lesson can have an image.\n\nThe image is displayed under the lesson title and description.
