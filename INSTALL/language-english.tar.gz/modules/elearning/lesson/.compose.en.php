[   0]Compose a lesson
[   1]Swap with the next paragraph
[   2]Paragraph
[   3]Exercise
[   4]Lesson:
[   5]Headline
[   6]Model:
[   7]Choose a heading for the paragraph...
[   8]Delete the lesson paragraph
[   9]Swap with the previous paragraph
[  10]Heading
[  11]Print the lesson
[  12]Compose the lesson model
[  13]Add a lesson paragraph...
[  14]Edit the instructions of the lesson
[  15]Are you sure you want to DELETE this lesson paragraph ?
[  16]Add a lesson paragraph to the heading
[  17]Add a lesson paragraph
[  18]Edit the lesson
[  19]Edit the introduction of the lesson
[  20]Edit the paragraph
[  21]Edit the text of the paragraph
[  29]A lesson is composed of an introduction and a series of paragraphs.\n\nA paragraph of a lesson may be composed of a headline, a header, a body and a footer and a link to an exercise.\n\nDuring a lesson, by default, all the paragraphs are displayed on one page.
[  34]Preview the lesson
[  41]Upload or delete an image or a Flash file
[  42]Upload or delete an audio or a Flash file
