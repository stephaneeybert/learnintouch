[   0]The lessons
[   1]Search:
[   2]It can become tedious to navigate in the list of lessons to find a particular lesson.\n\nTo avoid this, it is possible to type in all or part of the name of a lesson and do a search based on the typed in text.\n\nThe search result will display all the lessons matching the searched text.
[   3]Level:
[   4]Select the lessons of a particular level.
[   5]Course:
[   6]Select the lessons of a particular course.
[   7]Category:
[   8]Select the lessons of a particular category.
[   9]Subject:
[  10]Select the lessons of a particular subject.
[  11]Search lessons...
[  12]A lesson of the course
[  13]An exercise of the course
[  14]A lesson
[  15]An exercise of the lesson
[  16]The lessons and exercises of a course
