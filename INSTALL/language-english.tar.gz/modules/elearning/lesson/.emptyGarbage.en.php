[   0]Empty the garbage
[   2]Permanently delete all the lessons of the garbage?
