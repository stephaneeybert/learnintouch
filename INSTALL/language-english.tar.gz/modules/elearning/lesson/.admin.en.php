[   0]The lessons
[   1]Create a lesson
[   2]Edit the lesson
[   3]Put the lesson in the garbage
[   4]Name
[   5]Edit the exercise
[   6]The lesson models
[   7]Insert or delete an image or a multimedia file
[   8]Add the lesson to a course
[   9]Category:
[  10]Swap with next
[  11]Swap with previous
[  12]Compose the exercise
[  13]Level:
[  14]The levels
[  15]Remove from the course
[  16]An exercise
[  17]Description
[  18]Exercises
[  19]Teacher:
[  20]A lesson can have an exercise in each of its paragraphs
[  21]A lesson
[  22]The courses
[  23]The categories
[  24]Lock the lesson
[  25]Unlock the lesson
[  26]Preview the lesson
[  27]Preview the exercise
[  28]Send by email
[  29]The course management system offers lessons.\n\nA lesson may be composed of an introduction, an image or a Flash animation, an audio file and a series of paragraphs.\n\nA lesson can also be included in a course.
[  31]Delete the last imported course
[  32]Duplicate the lesson
[  33]Course:
[  34]The lessons dumped in the garbage
[  35]Show the lesson web address
[  36]The lesson web address is :
[  37]To create a link pointing to this lesson, copy and paste the above web address in the href attribute of a link.
[  38]Give an assignment
[  39]The subjects
[  40]Print the lesson
[  41]Print the exercise
[  42]Compose the lesson
[  43]One week
[  44]One month
[  45]Three months
[  46]Six months
[  47]One year
[  48]Created since:
[  50]Public
[  51]Protected
[  52]The exercises
[  53]Import a course, a lesson or an exercise
[  55]Subject:
[  56]Not yet released
[  57]Previous
[  58]Next
[  59]Select the lessons of a particular level.
[  60]Status:
[  61]Select the lessons of a particular category.
[  62]Select the lessons of a particular subject.
[  63]Select the lessons of a particular course.
[  64]Select the lessons of a particular status.
[  65]Select the lessons of a particular period of time.
[  66]Move after
[  70]Search:
[  71]It can become tedious to navigate in the list of lessons to find a particular lesson.\n\nTo avoid this, it is possible to type in all or part of the name of a lesson and do a search based on the typed in text.\n\nThe search result will display all the lessons matching the searched text.
