[   0]Duplicate a lesson
[   1]Name:
[   5]Description:
[   7]Duplicate the lesson?
[   6]The name is required.
[   9]A lesson with the specified name already exists.
