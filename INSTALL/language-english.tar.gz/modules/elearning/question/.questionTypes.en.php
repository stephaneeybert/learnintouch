[   0]Choose an answer in a drop down list
[   1]... in a radio buttons list [horizontal list]
[   2]... in a checkboxes list [ALL correct answers are REQUIRED]
[   3]Type in an answer in a question
[   4]... in a checkboxes [SEVERAL answers are ACCEPTED]
[   5]... in a radio buttons list [vertical list]
[   6]Drag an answer... into its question
[   7]... into any question
[   8]... to order the words of a sentence
[   9]... into a text with holes
[  10]Type in an answer in a text with holes
[  11]Select an answer in a text with holes
[  12]... under any question [SEVERAL answers are ACCEPTED]
[  13]Write a text
