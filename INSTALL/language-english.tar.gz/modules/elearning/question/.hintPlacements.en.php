[   0]After the answer field
[   1]Inside the answer field
[   2]At the end of the question
[   3]In a tooltip
[   4]Before the answer field
