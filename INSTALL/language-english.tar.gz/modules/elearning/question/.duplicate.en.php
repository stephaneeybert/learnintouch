[   0]Duplicate a question
[   1]Question:
[   5]Points:
[   7]Duplicate the question?
