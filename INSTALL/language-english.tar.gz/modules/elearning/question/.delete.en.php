[   0]Delete a question
[   1]Question:
[   2]Delete the question?
[   3]This question has already been used and has some results.\n\nDeleting the question will also delete the detailed results of the question.\n\nBut the results of the other questions will not be deleted and the exercise grades and points will be kept.
