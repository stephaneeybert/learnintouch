[   0]Upload an audio file
[   6]Audio file:
[   3]File name:
[   5]Select a file:
[   7]Delete the audio file?
[  27]No audio file has been specified.
[   1]A question can have an audio file.\n\nThe audio file is played by clicking on the audio player.\n\nAn audio file is a file that can be streamed over the Internet to broadcast audio content.
[   2]Kb.
