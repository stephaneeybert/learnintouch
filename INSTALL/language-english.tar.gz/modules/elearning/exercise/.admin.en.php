[   0]The exercises
[   1]Create an exercise
[   2]Edit the lesson
[   3]Put the exercise in the garbage
[   4]Name
[   5]Compose the lesson
[   6]The categories
[   7]Insert or delete an image or a multimedia file
[   8]Add the exercise to a course
[   9]Category:
[  10]Swap with next
[  11]Swap with previous
[  12]Compose the exercise
[  13]Level:
[  14]The levels
[  15]Remove from the course
[  16]A lesson
[  17]Description
[  18]Exercises
[  19]Teacher:
[  20]A lesson can have an exercise in each of its paragraphs
[  21]An exercise
[  22]The courses
[  23]Add the exercise to a lesson
[  24]Lock the exercise
[  25]Unlock the exercise
[  26]Preview the exercise
[  27]Preview the lesson
[  28]Send by email
[  29]The course platform is used to create courses, offer them to participants, register their results and facilitate the communication between the participants and their teachers.\n\nAn exercise may be composed of a text, an image or a Flash animation, an audio file and a series of pages of questions.\n\nAn exercise can also be included in a course.
[  31]Delete the last imported course
[  32]Duplicate the exercise
[  33]Course:
[  34]The exercises dumped in the garbage
[  35]Show the exercise web address
[  36]The exercise web address is :
[  37]To create a link pointing to this exercise, copy and paste the above web address in the href attribute of a link.
[  38]Give an assignment
[  39]The subjects
[  40]Print the exercise
[  41]Print the lesson
[  42]Edit the exercise
[  43]One week
[  44]One month
[  45]Three months
[  46]Six months
[  47]One year
[  48]Created since:
[  50]Public
[  51]Protected
[  52]The lessons
[  53]Import a course or an exercise
[  55]Subject:
[  56]Not yet released
[  57]Previous
[  58]Next
[  59]Select the exercises of a particular level.
[  60]Status:
[  61]Select the exercises of a particular category.
[  62]Select the exercises of a particular subject.
[  63]Select the exercises of a particular course.
[  64]Select the exercises of a particular status.
[  65]Select the exercises of a particular period of time.
[  66]Move after
[  70]Search:
[  71]It can become tedious to navigate in the list of exercises to find a particular exercise.\n\nTo avoid this, it is possible to type in all or part of the name of an exercise and do a search based on the typed in text.\n\nThe search result will display all the exercises matching the searched text.
