[   0]Delete an exercise
[   1]Name:
[   2]Delete the exercise?
[   3]This exercise has already been used and has some results.\n\nDeleting the exercise will also delete the detailed results of each question.\n\nBut the exercise grades and points will be kept.
[   4]The exercise is locked and cannot be deleted.
[   5]Description:
[   6]The exercise is used in the following courses:
[   7]The exercise must be removed from these courses before being deleted.
[   8]The exercise is used in the following lessons:
[   9]The exercise must be removed from these lessons before being deleted.
