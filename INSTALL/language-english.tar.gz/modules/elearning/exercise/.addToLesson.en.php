[   0]Add an exercise to a lesson
[   1]A lesson is composed of a series of paragraphs.\n\nEach paragraph of a lesson can display a link to an exercise.
[   2]Lesson paragraph:
[   4]Name:
[   5]Description:
[   6]The lesson paragraph is required.
