[   0]Compose the exercise
[   1]Swap with the next page of questions
[   2]Pages of questions
[   3]Add a page of questions to the exercise
[   4]Exercise:
[   5]Delete the page and all its questions
[   6]Edit the page of question
[   7]Upload or delete an image or a Flash file
[   8]Edit the instructions of the exercise
[   9]Swap with the previous page of questions
[  10]Edit the text of the page of questions
[  11]Multiple choice question
[  12]Type in answer
[  13]Listen to audio
[  14]Duplicate the question
[  15]Add a question to the page of questions
[  16]Edit the instructions of the page of questions
[  17]Preview the page of questions
[  18]Swap with the next answer
[  19]Swap with the previous answer
[  20]Edit the question
[  21]Delete the question and all its answers
[  22]Add an answer to the question
[  23]Edit the answer
[  24]Delete the answer
[  25]Specify as a solution to the question
[  26]Print the exercise
[  27]Upload or delete an audio or a Flash file
[  28]Specify the next pages of questions
[  29]An exercise may be composed of an introduction followed by several pages of questions.\n\nA page of questions may be composed of a text, an image or a Flash animation, an audio file and a series of questions.\n\nDuring an exercise, by default, each page of questions is displayed on a separate page, one after the other.
[  30]Swap with the next question
[  31]Swap with the previous question
[  32]Points
[  33]Specify as NOT a solution to the question
[  34]Preview the exercise
[  35]Hint
[  36]Reading
[  37]Writing
[  38]Listening
[  39]Type
[  40]Edit the exercise
[  41]Upload or delete an image or a Flash file
[  42]Upload or delete an audio or a Flash file
[  43]Edit the introduction
[  44]The number of questions is less than the number of location markers in the text of the page.
[  45]The number of location markers
[  46]Keep the existing order of the questions
[  47]Reorder the questions in their chronological order of creation
[  48]Duplicate the exercise page
[  49]The ordered answers are different than the question.
[  50]For a sentence to order, all answers must be solutions.
[  51]The question needs more than one answer.
[  52]Print the exercise page
[  53]Move into the question
[  54]Move after the answer
[  55]Move before the answer
[  56]Move into the page of questions
[  57]Move after the question
[  58]Move before the question
[  59]Move after the page of questions
[  60]Move before the page of questions
[  61]in the text of the page is less than the number of questions
