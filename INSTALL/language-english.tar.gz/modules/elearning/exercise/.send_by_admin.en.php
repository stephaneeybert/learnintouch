[   0]Send an exercise
[   1]Name:
[   2]Send the exercise?
[   3]Description:
[   4]Text:
[   5]Email:
[   6]An exercise has been sent to you.
[   7]Best Regards
[   8]An exercise from
[   9]To do the exercise, please click on its name:
[  10]See the exercise content...
[  11]Participant:
[  12]The recipient can be a participant, a class of participants, or a simple email address.
[  13]Class of participants:
[  14]There are no participants in the class.
[  15]Hello
[  16]Select a class of participants or a participant, or type in an email address.
[  38]The email address format is invalid.
[  40]A recipient is required.
