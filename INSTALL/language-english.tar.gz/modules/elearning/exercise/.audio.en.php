[   0]Upload an audio file
[   6]Audio file:
[   3]File name:
[   5]Select a file:
[   7]Delete the audio file?
[  27]No audio file has been specified.
[   1]An exercise can have an audio file.\n\nThe audio file is played before the user answers the exercise questions.
[   2]Kb.
