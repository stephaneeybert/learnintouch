[   0]Empty the garbage
[   2]Permanently delete all the exercises of the garbage?
