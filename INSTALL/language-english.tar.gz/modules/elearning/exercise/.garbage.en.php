[   0]The garbage
[   1]Empty the garbage
[  11]Retrieve the exercise
[   7]Name
[   6]Description
[   9]When an exercise is being deleted, it is actually stored in the garbage.\n\nThe exercise can be retrieved from the garbage.\n\nEmptying the garbage permanently deletes all the exercises stored in it.
