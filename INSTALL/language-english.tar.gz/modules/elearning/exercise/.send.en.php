[   0]Send an exercise
[   1]Name:
[   3]Description:
[   4]Text:
[   5]Email:
[   2]Send the exercise?
[   9]To do the exercise, please click on its name:
[  10]See the exercise content...
[  19]An exercise from
[  22]has been sent to you by
[  20]Hello
[  13]has sent you an exercise.
[  18]Kind Regards
[   7]Recipient email:
[  17]Type in the email address of the recipient.
[   8]Recipient name:
[  16]You can type in the name of the recipient.
[  11]Sender email:
[  15]You can type in your email address to leave your contact to the recipient.
[  12]Sender name:
[  14]You can type in your name to sign the sending.
[  23]Message:
[  24]You can type in a message.
[  21]The email address of the sender is required.
[  39]The email address format of the sender is invalid.
[  45]The email address of the sender has an invalid suffix.
[  40]The email address of the recipient is required.
[  38]The email address format of the recipient is invalid.
[  44]The email address of the recipient has an invalid suffix.
