[   0]Edit an exercise instructions
[   1]Instructions:
[   4]Name:
[   5]Description:
[  11]Some instructions on how to do the exercise can be displayed at the beginning of an exercise.\n\nThese instructions are here to help the participant do the exercise.\n\nThey are not supposed to be part of the exercise content.
