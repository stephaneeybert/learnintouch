[   0]The exercises
[   1]Search:
[   2]It can become tedious to navigate in the list of exercises to find a particular exercise.\n\nTo avoid this, it is possible to type in all or part of the name of an exercise and do a search based on the typed in text.\n\nThe search result will display all the exercises matching the searched text.
[   3]Level:
[   4]Select the exercises of a particular level.
[   5]Course:
[   6]Select the exercises of a particular course.
[   7]Category:
[   8]Select the exercises of a particular category.
[   9]Subject:
[  10]Select the exercises of a particular subject.
[  11]Search exercises...
[  12]A lesson of the course
[  13]An exercise of the course
[  14]An exercise
[  15]An exercise of the lesson
[  16]The lessons and exercises of a course
