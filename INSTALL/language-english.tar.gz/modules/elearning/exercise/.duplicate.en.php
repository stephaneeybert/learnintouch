[   0]Duplicate an exercise
[   1]Name:
[   5]Description:
[   7]Duplicate the exercise?
[   6]The name is required.
[   9]An exercise with the specified name already exists.
