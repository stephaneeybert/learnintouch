[   0]The email address is required.
[   1]The firstname is required.
[   2]The lastname is required.
[   4]Email: *
[   5]Firstname: *
[   6]Lastname: *
[   7]Message:
[   8]Continue
[   9]Telephone:
[  10]I can be called at the telephone number:
[  11]Available on:
[  12]Monday
[  13]Tuesday
[  14]Wednesday
[  15]Thursday
[  16]Friday
[  17]Saturday
[  18]Sunday
[  19]Morning
[  20]Lunch
[  21]Afternoon
[  22]Evening
[  23]Around:
[  24]I am is available on
[  25]around
[  26]The required fields are marked with a star *
[  27]The email address is required
[  28]The email address format is invalid.
