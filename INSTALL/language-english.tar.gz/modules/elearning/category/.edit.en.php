[   0]Edit a category
[   4]Name:
[   5]Description:
[   6]The name is required.
