[   0]Delete a category
[   1]Name:
[   5]Description:
[   2]Delete the category?
