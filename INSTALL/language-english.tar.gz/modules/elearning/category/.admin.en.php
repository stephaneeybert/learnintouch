[   0]The categories
[   1]Create a category
[   2]Edit the category
[   3]Delete the category
[   5]Name
[   6]Description
