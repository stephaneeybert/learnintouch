[   0]Page
[   1]page(s) left
[   2]Progression:
[   3]Remove the dropped answer
[   4]of the exercise
[   5]A hint to help you
[   6]Your answers are all correct!
[   7]Your answers are all incorrect.
[   8]Your answers are partially correct.
[   9]The solution is:
[  10]Display the text
[  11]View the video
[  12]Go to the video
[  13]The solutions are:
[  14]Hide the text
[  15]You have not typed in the expected number of words!
[  16]You have typed in
[  17]words out of
[  18]words.
[  19]Mini keyboard:
[  20]Click on a letter in the mini keyboard
[  21]Insert the letter
[  23]No answer was given.
