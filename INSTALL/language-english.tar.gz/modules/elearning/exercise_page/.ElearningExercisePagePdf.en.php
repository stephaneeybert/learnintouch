[   1]Questions of the exercise
[   2]Solutions of the exercise
