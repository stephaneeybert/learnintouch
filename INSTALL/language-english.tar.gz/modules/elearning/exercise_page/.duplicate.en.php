[   0]Duplicate an exercise page
[   1]Exercise page:
[   7]Duplicate the exercise page?
