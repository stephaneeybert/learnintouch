[  11]Write a text.
[  12]Choose an answer for each question.
[  13]Choose one or more answers for each question.
[  14]Choose all correct answers for each question.
[  15]Type in an answer for each question.
[  16]Choose an answer for each hole in the text.
[  17]Type in an answer for each hole in the text.
[  18]Drag an answer into its question.\nClick to remove the dropped answer.
[  19]Drag an answer into the questions.\nClick to remove the dropped answer.
[  20]Drag the answers to compose a sentence.
[  21]Drag an answer into each hole of the text.\nClick to remove the dropped answer.
[  22]Drag an answer or an image under the questions.\nClick to remove the dropped answer.
