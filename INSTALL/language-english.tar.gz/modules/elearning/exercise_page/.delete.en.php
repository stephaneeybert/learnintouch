[   0]Delete a page of questions
[   1]Page of questions:
[   2]Delete the page of questions?
[   3]This page of questions has already been used and has some results.\n\nDeleting the page of questions will also delete the detailed results of each question of the page.\n\nBut the results of the other pages of questions will not be deleted and the exercise grades and points will be kept.
