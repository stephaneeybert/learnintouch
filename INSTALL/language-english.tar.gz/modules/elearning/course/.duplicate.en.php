[   0]Duplicate a course
[   1]Name:
[   5]Description:
[   7]Duplicate the course?
[   6]The name is required.
[   9]A course with the specified name already exists.
