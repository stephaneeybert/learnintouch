[   0]Add an exercise to a course
[   1]A course is composed of a series of exercises and/or lessons.\n\nA course can have an unlimited number of exercises and/or lessons.
[   2]Course:
[   3]The exercise is already assigned to this course.
[   4]Name:
[   5]Description:
[   6]The course is required.
[   9]The course is locked and cannot be updated.
