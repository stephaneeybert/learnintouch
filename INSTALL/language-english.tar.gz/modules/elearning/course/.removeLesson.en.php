[   0]Remove a lesson from a course
[   1]When a lesson is removed from a course, the lesson is not deleted.\n\nIt is simply removed from the list of lessons composing the course.\n\nThe lesson can still be used by other courses.
[   2]Course:
[   4]Name:
[   5]Description:
[   9]The course is locked and cannot be updated.
