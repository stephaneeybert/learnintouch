[   0]Delete a course
[   1]Name:
[   2]Delete the course?
[   3]The course cannot be deleted because some sessions are programmed for this course.
[   4]The course cannot be deleted because it contains some lessons and / or exercises.
[   5]Description:
[   6]The course cannot be deleted because some participants have subscribed to this course.
[   7]Ignore the participants subscriptions:
[   8]By default, a course cannot be deleted if some participants have subscribed to the course.\n\nBut it is possible to delete a course and modify the participants subscriptions.\n\nIn that case, the participants subscriptions will not be removed.
[   9]The course is locked and cannot be deleted.
[  10]The course is used by
[  11]participants subscriptions.
[  12]Ignore the lessons and / or exercises:
[  13]If the course contains some lessons and / or exercises then these will be removed from the course, but they will not be deleted.
