[   0]Add a lesson to a course
[   1]A course is composed of a series of lessons and/or exercises.\n\nA course can have an unlimited number of lessons and/or exercises.
[   2]Course:
[   3]The lesson is already assigned to this course.
[   4]Name:
[   5]Description:
[   9]The course is locked and cannot be updated.
