[   0]The courses
[   1]Add a course
[   2]Edit the course
[   3]Delete the course
[   4]Name
[   5]Importable
[   6]The course can be imported by other websites
[   7]Insert or delete an image or a multimedia file
[   8]The lessons
[   9]The exercises
[  10]Restrict to super administrators
[  11]Authorize to all administrators
[  12]The lessons of the course
[  13]The exercises of the course
[  14]User:
[  15]A course can also be created by a user.\n\nIn that case, it is possible to display only the courses of a user.\n\nNote that a user is not an administrator.
[  16]Auto subscription
[  17]Description
[  18]The participants can subscribe to the course by themselves
[  19]Give the course to a class participants
[  20]Edit the course information
[  21]The sessions
[  22]Duplicate the course
[  28]Send by email
[  29]A course is composed of a series of lessons and exercises.\n\nFor example, a course can be "English for beginners".\n\nThe courses can be sorted by matter.
[  33]Matter:
[  34]The matters
[  53]Import a course, a lesson or an exercise
[  70]Search:
[  71]It can become tedious to navigate in the list of courses to find a particular course.\n\nTo avoid this, it is possible to type in all or part of the name of a course and do a search based on the typed in text.\n\nThe search result will display all the courses matching the searched text.
