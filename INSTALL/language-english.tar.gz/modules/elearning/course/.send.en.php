[   0]Send a course
[   1]Name:
[   2]Send the course?
[   3]Description:
[   4]Text:
[   6]A course has been sent to you.
[   7]Best Regards
[   8]A course from
[   9]To start the course, please click on its name:
[  11]Participant:
[  12]The recipient can be a participant, a class of participants, or a simple email address.
[  13]Class of participants:
[  14]There are no participants in the class.
[  15]Hello
[  16]Select a class of participants or a participant, or type in an email address.
[  40]A recipient is required.
