[   0]Edit the course information
[   1]Swap with the next course information
[   3]Headline
[   4]Course:
[   8]Delete the course information
[   9]Swap with the previous course information
[  15]Are you sure you want to DELETE this course information ?
[  17]Add a course information
[  20]Edit the course information
[  29]The course information is composed of a series of headlines and associated texts.
