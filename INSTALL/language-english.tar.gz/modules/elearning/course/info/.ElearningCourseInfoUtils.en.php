[   0]Display the course information
[   1]Hide the course information
