[   0]Edit a course information
[   1]Information:
[   4]The headline is required.
[   6]Headline:
[  23]The course information is a detailed description of the course content.\n\nIt can contain several pages each composed of a headline and a text.\n\nIt allows the participant to know more about the course before subscribing to it.
