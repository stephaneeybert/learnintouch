[   0]Remove an exercise from a course
[   1]When an exercise is removed from a course, the exercise is not deleted.\n\nIt is simply removed from the list of exercises composing the course.\n\nThe exercise can be used by other courses.
[   2]Course:
[   4]Name:
[   5]Description:
[   9]The course is locked and cannot be updated.
