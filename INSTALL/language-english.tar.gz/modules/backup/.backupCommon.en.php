[   0]Backup the common database
[   7]The common database has NOT been backed up
[   8]A problem occured and the common database has NOT been backed up.
[   9]Contact the website manager
[  10]Only a super administrator can backup the common database.
