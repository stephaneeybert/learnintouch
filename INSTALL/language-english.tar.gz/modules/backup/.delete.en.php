[   0]Delete a backup file
[   1]File:
[   2]Delete the file?
[   3]No file has been specified.
