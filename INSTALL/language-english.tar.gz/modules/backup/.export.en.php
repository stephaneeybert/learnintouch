[   0]Export a table
[   1]Export a table into a CSV text file.
[   2]Table name:
[   8]A problem occured and the table has NOT been exported.
[   9]Contact the website manager
[  12]The website data is stored in a set of database tables.\n\nThis data might be usefull to other applications than the website.\n\nThe data contained in each database table can thus be exported into a text file.\n\nThis text file has a CSV format, allowing it to be read by a spreadsheet, like MS Excel for example.
