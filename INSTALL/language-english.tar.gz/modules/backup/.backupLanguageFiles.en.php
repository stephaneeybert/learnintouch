[   0]Backup the language files
[   1]Backup the language files into an archive file.\n\nThe archive file has a tar format.\n\nTo open it on a Windows system, use a utility like WinZip.\n\nTo open it on a Unix/Linux/OSX system, use the commands tar.
[  15]Start the backup
[   8]A problem occured and the language files have NOT been backed up.
[   9]Contact the website manager
[   2]Language:
