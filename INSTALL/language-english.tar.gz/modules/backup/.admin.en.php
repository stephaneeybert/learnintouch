[   0]The website backups
[   1]Create a backup file
[   2]Size
[   3]Delete the backup file
[   4]Database backup
[   5]Date
[   6]Website backup:
[   7]Export a database table
[   8]Download the file
[   9]Backup the common database
[  10]The directory containing the backup files could not be opened.
[  11]Backup the language files
[  12]A full backup of the website content can be created and downloaded.\n\nThis allows for the safe keeping of a full copy of the website content.\n\nAn automatic backup of all the website data is done every day.\n\nThe website data is stored in a database and in a directory.\n\nThe text is stored in the database, and the files, like images, audio files, etc... are stored in the directory.\n\nAs this data can represent a fair amount of work, making a backup copy of it, is a smart move to make!\n\nMaking a backup of the website data is a two steps process.\n\nFirst, create a backup file.\n\nThe backup file will then appear at the top of the list of backup files.\n\nSecond, download the backup file by clicking on its name.\n\nAfter the downloading is complete, a copy of the backup file sits now on your computer.\n\nIt is a very good thing to always have an up-to-date backup file!
[  13]The backup is being prepared...
[  14]The preferences
[  15]Size:
