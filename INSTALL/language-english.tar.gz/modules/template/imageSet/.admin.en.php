[   0]The navigation images
[   1]On some pages, the website displays navigation images.\n\nIt is possible to replace the default images by some custom images.\n\nTo customize an image, simply upload an image file to replace the image.\n\nAny custom image will be displayed in place of the standard image.
[   2]Upload an image
[   3]Reset the images
[   4]Computer
[   5]Insert or delete a computer image
[   6]Reset the computer image
[   7]Reset the phone image
[   8]Phone
[   9]Insert or delete a phone image
