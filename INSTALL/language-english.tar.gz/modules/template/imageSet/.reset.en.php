[   0]Reset the images
[   1]Reset the images?
