[   0]Reset an image (phone)
[   6]Image:
[   7]Reset the image?
