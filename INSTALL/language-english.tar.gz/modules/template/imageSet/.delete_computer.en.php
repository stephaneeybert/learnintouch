[   0]Reset an image (computer)
[   6]Image:
[   7]Reset the image?
