[   0]Upload an image (phone)
[   2]Select an image:
[   3]Image name:
[   6]Image:
[   7]Delete the image?
[  27]No image has been specified.
