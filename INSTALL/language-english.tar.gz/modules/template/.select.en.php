[   0]Select a web page
[   1]To select a web page, click on one type of content and choose a page.
[  10]The web pages created with an html editor
[  11]The web pages
[  12]Sell items and goods in the shop
[  13]The shop
[  14]The courses and exercises
[  15]The courses
[  18]The news
[  19]The newspapers and their stories, headings and authors
[  20]The photo albums
[  21]The photos stored in albums
[  22]The people
[  23]The people of the company/organisation
[  24]The favorite links
[  25]The links to your favorite websites
[  26]The preformatted pages
[  27]The preformatted pages offered by the system
[  28]The documents
[  29]The library of documents offer for download
[  30]The languages
[  31]The languages used by the website
[  32]The forms
[  33]The forms
