[   0]Rename a model
[   1]The model type is required.
[   2]Model type:
[   3]The name must have only one word.\n\nIt cannot contain any blank spaces.
[   4]The name is required.
[   6]Name:
[   7]Description:
[   8]Parent model:
[   9]A model with the specified name already exists.
[  10]It is possible for a model, to inherit from another model.\n\nThe other model acts like a parent to the model.\n\nThe child model inherits all the content of the parent model.\n\nThe child model can however style the content of its parent model.
