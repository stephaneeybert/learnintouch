[   0]Delete a file
[   1]File:
[   2]Delete the file?
