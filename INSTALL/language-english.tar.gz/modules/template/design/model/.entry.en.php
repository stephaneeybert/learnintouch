[   0]Specify the website models
[   1]Entry model for computers:
[   2]Entry model for phones:
[   3]Default model for computers:
[   4]Default model for phones:
[   5]The website content is displayed within models.\n\nThe entry model is the one used when a visitor comes to the website.\n\nThe default model is the main model of the website. It can be the same as the entry model.\n\nThere are models for a display on computers and models for a display on mobile phones.
