[   0]Duplicate a model
[   1]Name:
[   5]Description:
[   7]Duplicate the model?
[   2]The name must not be a number.
[   3]The name is required.
[   4]A model with this name already exists.
