[   0]The models
[   1]Create a model
[   2]Rename the model
[   3]Delete the model
[   4]Name
[   5]Description
[   6]Compose the model
[   8]Default
[   9]Duplicate the model
[  10]Export the model
[  11]Select a model
[  12]Specify the entry model
[  13]The models describe the general content and layout of the web site.\n\nThere can be an unlimited number of models.\n\nEach model can be used by an unlimited number of web pages.\n\nOne model is specified as being the default model of the website.\n\nIt is the model used by most of the pages of the website.\n\nOne other model can be specified as being the entry model of the website.\n\nIt is the model used by the entry page of the website.\n\nThe entry model permits to choose which model will be used for the display of the web pages when a visitor arrives on the website.\n\nAnd the default model permits to choose which model will be used for the display of the following web pages of the website.\n\nBut it is possible to have other models and to use them for any pages of the web site.
[  14]Entry
[  15]The default model for computer
[  16]The default model for phone
[  17]The entry model for computer
[  18]The entry model for phone
[  19]Preview the model
[  20]Compose the style of the pre-formatted pages
[  21]The navigation images
[  27]The preferences
