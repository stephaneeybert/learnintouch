[   0]Delete a model
[   1]Name:
[   2]Delete the model?
[   3]Description:
[   4]The model cannot be deleted because it is the default website model.
[   5]The model cannot be deleted because it is the website entry model.
