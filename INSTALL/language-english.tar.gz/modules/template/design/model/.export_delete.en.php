[   0]Delete an exported model
[   1]File:
[   2]Delete the exported model?
