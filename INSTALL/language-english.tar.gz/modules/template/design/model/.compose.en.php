[   0]Compose a model
[   1]Delete an element
[   2]Model type:
[   3]Add an element
[   4]Swap with next
[   5]Swap with previous
[   6]Model:
[   7]Style the container
[   8]A model is composed of containers, each containing a series of elements.\n\nA container is represented here by a black square.\n\nThe elements are the objects serving in the building of the model.\n\nThere are different types of elements.\n\nSome elements are navigation links.\n\nOthers are displaying content.\n\nTo compose a model, simply add some elements into the containers.\n\nThen edit the content of the elements.\n\nFinally, compose the style of the elements.
[   9]Style the element
[  10]Style the model
[  11]Compose the element
[  12]Preview the model
[  13]Are you sure you want to DELETE ?
[  14]Style the pre-formatted pages
[  15]Style the inner model
[  16]Swap with next
[  17]The containers must all have a width expressed in the same unit, either in pixels, or in percentage.
[  18]Swap with previous
[  19]Delete a container
[  20]Add a container
[  21]Add a row of containers
[  22]Move to next row
[  23]Move to previous row
[  24]Preview the container
[  25]Preview the element
[  26]Duplicate the element
[  27]Hide the element
[  28]Show the element
[  29]Swap the row with the previous
[  30]Swap the row with the next
[  31]inherits of the model:
[  32]The rows of containers should have the same total width.
[  33]The row
[  34]of containers should have the same total width than its parent model row.
