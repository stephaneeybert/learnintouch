[   1]Compose the inner style of the model
