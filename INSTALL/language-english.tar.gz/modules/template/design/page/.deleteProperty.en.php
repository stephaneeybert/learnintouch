[   0]Delete the style of a page
[   1]Delete the style
[   2]Close the window
[   3]Delete the style of the page:
[   4]There is no style to delete.
