[   0]Compose the style of the pre-formatted pages
[   1]Compose the style of the page
[   4]Delete the style of the page
