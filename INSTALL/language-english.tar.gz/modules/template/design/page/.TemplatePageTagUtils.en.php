[   0]The page
[   1]Title
[   2]A comment line
[   3]A warning message
[   4]A label on a form field
[   5]The content of a tooltip popup
[   6]The validation button
[   7]The cancel button
[   8]The content of an email
[   9]Some icons
