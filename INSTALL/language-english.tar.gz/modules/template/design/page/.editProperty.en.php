[   0]Compose the style of
[   1]Delete the style of the tag
[   3]Make sure the page contains some content before composing its style.\n\nFor example, for a newspaper, check that it is published.\n\nOr for the photo gallery, check that are a few photos in the gallery.\n\nFor each page, make sure that the page displays some content before editing its style.
[   4]Compose the style for
[   5]Are you sure you want to DELETE the style ?
