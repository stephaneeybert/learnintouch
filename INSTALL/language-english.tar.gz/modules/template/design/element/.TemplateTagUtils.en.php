[   0]The navigation link
[   1]The navigation bar
[   2]The middle items of a navigation bar
[   3]The navigation menu
[   4]The top menu
[   5]The menus
[   6]The items of the sub menus
[   7]The item separators
[   8]The items without menu
[   9]The web pages
[  10]The web page bread crumbs
[  11]The web page directory tree
[  12]The text
[  13]A news story
[  14]The date
[  15]The time
[  16]The Flash animation
[  17]The language selector
[  18]A flag
[  19]The user login
[  20]The login name
[  21]The login password
[  22]The validation button
[  23]The register link
[  24]The login link
[  25]The profile link
[  26]The password link
[  27]The logout link
[  28]The mail subscription
[  29]The image cycle
[  30]A text
[  31]A field label
[  32]A field input
[  33]The last update
[  34]The newspaper
[  35]The title
[  36]The header image
[  37]A news story headline
[  38]A release date
[  39]The rss logo
[  40]The website address
[  41]The page content
[  42]The item images
[  43]The image of the navigation link
[  44]The image of a flag
[  45]The border of the header image
[  46]The border of an input field
[  47]The website telephone
[  48]The search engine
[  49]The RSS source
[  50]The search field
[  51]The border of the field
[  52]A news story
[  53]The middle items of the top menu
[  54]The top menu item images
[  55]The menu item images
[  56]The first item of a navigation bar
[  57]The last item of a navigation bar
[  58]The current page
[  59]The headline of the news story
[  60]The title of the RSS source
[  61]The first item of the top menu
[  62]The last item of the top menu
[  63]A news story image
[  64]The border of a news story image
[  65]The menu title
[  66]An image
[  67]The website fax
[  68]The website copyright
[  69]The element
[  70]The title of the event search
[  71]A label for the event search
[  72]A radio button for the event search
[  73]An input field for the event search
[  74]The period for the event search
[  75]The news stories
[  76]The display link for the event search
[  77]The event search box
[  78]A result message
[  79]A select list for the event search
[  80]The lexicon
[  81]The read next link
[  82]The news story excerpt
[  83]The calendar
