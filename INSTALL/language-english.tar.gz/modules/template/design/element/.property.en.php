[   1]Compose the style of:
