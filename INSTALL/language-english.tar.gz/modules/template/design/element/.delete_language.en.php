[   0]Delete a language
[   1]Language:
[   2]Delete the language?
[   3]For all languages
