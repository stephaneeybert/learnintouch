[   0]A template element
[   1]Add a language
[   2]in
[   3]Delete the element
[   4]Language
[   7]A template element is some content displayed in a template of the website.
[  10]Image/Text
[  13]For all languages
[  14]Close the window
[  15]for the language
[  22]Edit the element
