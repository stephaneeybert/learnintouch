[   0]Compose the style of an element
[   1]Delete the style of the tag
[   3]Close the page
[   4]Compose the style
[   5]Are you sure you want to DELETE the style ?
