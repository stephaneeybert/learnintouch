[   0]Duplicate an element
[   1]Type:
[   2]Choose a container in which to duplicate the element.
[   3]Container:
[   4]The destination container that will receive the duplicated element.
[   7]Duplicate the element?
