[   0]Search...
[   1]A newspaper
[   2]The documents offered for download
[   3]A people
[   4]A newsstory
[   5]A web page
[   6]The client images cycle
[   7]A photo
[   8]The favorite links cycle
[   9]The photos cycle of an album
[  10]The visitor email address registration
[  11]The client references
[  12]The guestbook
[  13]The people
[  14]The favorite links
[  15]The visitor SMS number registration
[  16]The photo search
[  17]The photos of one album
[  18]A document
[  19]The contact form
[  20]The teacher corner
[  21]The user edit profile
[  22]An exercise
[  23]The user login
[  24]The user change password
[  25]The guestbook form
[  26]The user unsubscription
[  27]The user registration
[  28]The user logout
[  29]The news publications
[  30]The newspapers
[  31]The languages
[  32]A news publication
[  33]The search engine
[  34]The shop items
[  35]A shop item
[  36]All the shopping orders of a user
[  37]The user get password
[  38]The list of teachers
[  39]The shopping cart
[  40]The shop items search
[  41]The user's selection of items
[  42]The photo albums
[  43]A form
[  44]The results of an exercise
[  45]The website entry
[  46]The post user login
[  47]Popup windows template model:
[  48]The popup windows can be displayed using their own template model.\n\nThis allows for a display that is different than the main model of the website.
[  49]Preview the model with some dummy content:
[  50]Refresh the model
[  51]When displaying the model preview, by default the model is empty and does not display any web page.\n\nBut it is possible to display some dummy content in the model preview.\n\nThis allows for a more realistic looking model preview.
[  52]The model has been refreshed!
[  53]Model refresh ongoing...
[  54]The participants of a teacher
[  55]A lesson
[  56]The assignments of a participant
[  57]The course subscriptions of a participant
[  58]The terms of service
[  59]Register
[  60]Subscription
[  61]Leave us mobile phone number (SMS)
[  63]Number:
[  64]The friends invite
[  65]Popup windows template model (phone):
[  66]Our exercises and courses
[  67]Our lessons and courses
