[   0]The Time Setup
[   1]It may be that your local time is different than the system time.\n\nIn that case, you can specify the time difference between your local time and the system time.\n\nSelect the time difference to get a correct local time.
[   2]The system time:
[   3]corrected by the time difference of:
[   4]gives the local time:
[   5]and the local date:
[   6]The preferences
