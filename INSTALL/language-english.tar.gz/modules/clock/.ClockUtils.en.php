[   1]The date display format:
[   2]The date language:
[   3]The date can be displayed in a format using words for the day and the month.\n\nIn that case, the default language of the website is used to display the date.\n\nBut it is possible to choose another language for the date display.\n\nNote that this language is not used by the web site administration interface.
[  10]The time format:
[  27]The date numeric format:
[  32]The date numeric format is only used in the web site administration interface.\n\nThe date numeric format is not used on the pages of the web site.\n\nIt offers the administrators of the web site a format of their choice.\n\nThere is one format for the American date type and one format for the European date type.
[  33]There is a large choice of date formats.\n\nThe chosen date format is used to display the date on the pages of the web site.\n\nIt is not used by the administrators in the web site administration interface.
[  35]There are several choices of time format.
