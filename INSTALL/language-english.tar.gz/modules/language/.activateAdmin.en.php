[   0]Deactivate an administration language
[   4]Activate an administration language
[   6]Code:
[   5]Image:
[   7]Name:
[   1]Activate the language?
[   2]Deactivate the language?
