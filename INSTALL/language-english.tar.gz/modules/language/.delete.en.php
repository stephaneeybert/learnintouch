[   0]Delete a language
[   1]Name:
[   2]Delete the language?
[   6]Code:
[   5]Image:
