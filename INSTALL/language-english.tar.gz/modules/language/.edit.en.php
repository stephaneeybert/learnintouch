[   0]Edit a language
[   7]Name:
[   6]Code:
[   1]Locale:
[  39]The code is required.
[  40]The name is required.
[   9]A language with this code already exists.
