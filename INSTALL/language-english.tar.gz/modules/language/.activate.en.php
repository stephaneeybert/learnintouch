[   0]Deactivate a website language
[   4]Activate a website language
[   6]Code:
[   5]Image:
[   7]Name:
[   1]Activate the language?
[   2]Deactivate the language?
[  15]The default language cannot be deactivated.
