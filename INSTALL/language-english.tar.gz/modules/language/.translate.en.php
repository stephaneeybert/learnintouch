[   0]Translation
[   1]Feel free to edit any incorrect translation.
[   2]Translation into:
[   3]Get a new translation
[   4]Translate the website texts
