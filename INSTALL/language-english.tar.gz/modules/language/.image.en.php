[   0]Upload an image
[   6]Image:
[   3]Image name:
[   2]Select an image:
[   7]Delete the image?
[  27]No image has been specified.
