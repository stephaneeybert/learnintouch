[   0]The languages
[   1]Create a language
[   2]Edit the language
[   3]Delete the language
[   4]Code
[   5]Image
[   6]The web site content can be displayed in different languages.\n\nA user visiting the web site can choose a language in which the pages are displayed.\n\nA language can be deactivated if it is not used.\n\nA default language can be specified. It is the language used for the users that have not yet chosen a language.
[   7]Choose as default language
[   8]Name
[   9]Default
[  10]Activate the language for the website
[  11]Deactivate the language for the website
[  12]Change the image
[  14]Activate the language for the administration panel
[  15]Deactivate the language for the administration panel
