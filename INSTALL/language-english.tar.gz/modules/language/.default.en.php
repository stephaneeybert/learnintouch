[   0]Set the default language
[   2]Set the language as the default one?
[   1]Name:
[   3]Code:
[   5]Image:
