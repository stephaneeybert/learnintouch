[   0]Translation of the website texts
[   1]These texts are displayed on the website pages.
[   2]Edit the translation
