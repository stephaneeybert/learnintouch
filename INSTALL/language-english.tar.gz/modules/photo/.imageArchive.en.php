[   0]Upload an album
[   1]The 'gif' images are not supported.\n\nThis image format is protected by a patent.\n\nPlease transform your 'gif' images into 'jpg' images.
[   2]Select a file:
[   3]The name of the archive file is incorrect.\n\nA filename must be composed of the letters a-zA-Z only.
[   4]A photo album with the name
[   5]already exists.
[   6]Replace the existing album
[   7]Add to the existing album
[   8]Existing album:
[   9]Description:
[  10]The description is displayed when the mouse cursor passes over the photo.\n\nAll the uploaded photos will have the same description.
[  11]Tags:
[  12]A photo can have some tags.\n\nThese are labels that can help categorize a photo and make its search easier.\n\nA tag must be a word.\n\nEach tag is separated by a blank space.\n\nAll the uploaded photos will have the same tags.
