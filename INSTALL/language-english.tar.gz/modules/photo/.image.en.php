[   0]Upload an image
[   6]Image:
[   5]Album:
[   3]Image name:
[   2]Select an image:
[   8]There are currently no photo albums.\n\nPlease, create a photo album before inserting photos.
[   4]Select a photo album to upload a photo.\n\nA photo must belong to a photo album.\n\nIf no photo album is selected then the photo cannot be uploaded.
[   1]The 'gif' images are not supported.\n\nThis image format is protected by a patent.\n\nPlease transform your 'gif' images into 'jpg' images.
[   7]Resize to width:
[   9]When being uploaded to the server, an image can be resized to the specified width.\n\nIf no width is specified then the image is not resized.\n\nThe default width is taken from the larger image width in the preferences.

