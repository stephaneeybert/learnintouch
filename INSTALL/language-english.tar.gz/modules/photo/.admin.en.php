[   0]The photo albums
[   1]Create a photo
[   2]Edit the photo
[   3]Delete the photo
[   4]Upload a full album
[   5]The photo formats
[   6]The albums
[   7]Change the image
[   9]Album:
[  10]Swap with next
[  11]Swap with previous
[  12]Reference:
[  13]The photo albums allow for the display of photos.\n\nThe photos are stored into albums and can be displayed in diaporamas.
[  14]Name:
[  20]The preferences
[  70]Search:
[  71]It can become tedious to navigate in the lists of photos to find a particular photo.\n\nTo avoid this, it is possible to type in all or part of the reference, name, description, comment,price of a photo and do a search based on the typed in text.\n\nThe search result will display all the photos matching the searched text.
