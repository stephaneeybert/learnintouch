[   0]The photo formats
[   1]Create a format
[   2]Edit the format
[   3]Delete the format
[   5]Name
[   6]Description
