[   0]Delete a format
[   1]Name:
[   5]Description:
[   2]Delete the format?
[   3]The format is used by some photos.\n\nDelete the photos first to be able to delete the format.
