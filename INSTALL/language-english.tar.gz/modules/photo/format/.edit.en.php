[   0]Edit a format
[   4]Name:
[   1]Price:
[   3]If the price is set then it is the unit price for all the photos in the format.
[   5]Description:
[   6]The name is required.
[   2]The name is already used by another photo format.
