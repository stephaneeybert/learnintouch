[   0]A photo album cycle
[   1]Photo album:
