[   0]Search
[   5]Reference:
[  13]Text:
[  14]It is possible to search for a photo album containing a particular text.\n\nThe search result displays the photo albums whose name, event or location contain the typed in text.
[  15]It is possible to search for a photo album using a photo reference.
[  16]It is possible to search for the photo albums that have been published for a certain period of time.
[  21]Choose...
[  29]Back to the list of photo albums
[  43]One week
[  44]One month
[  45]Three months
[  46]Six months
[  47]One year
[  48]Since:
