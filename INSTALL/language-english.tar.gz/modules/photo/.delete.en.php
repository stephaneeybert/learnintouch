[   0]Delete a photo
[   1]Reference:
[   3]Description:
[   2]Delete the photo?
[   6]Image:
