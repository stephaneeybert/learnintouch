[   0]Select a photo album
[   1]Album photos cycle:
[   2]Album photos list:
