[   0]Photo album:
[   1]No photo albums were found.
[   2]View the photo album
[   3]Photo cycle:
[  52]Detailed search in the list of photo albums
[ 101]Back to the list of photo albums
