[   0]Add a format
[   4]Album:
[   1]Price:
[   3]The price of a photo for all the photos in the format for the album.
[   5]Format:
[   6]The price is required.
[   7]The format is required.
[   2]The price must be numerical.
[   8]The chosen format is already used by another album.\n\nChoose another format.
