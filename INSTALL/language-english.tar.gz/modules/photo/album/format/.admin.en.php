[   0]The photo formats of a photo album
[   1]Add a format to the album
[   2]Edit the format
[   3]Delete the format
[   4]The photo formats
[   5]Name
[   7]Price
[   8]Photo album:
[   9]The formats of an album are used to specify the prices of the photos for a given format of a given album.\n\nAll the photos of an album have an identical price per format.
