[   0]Delete a format of an album
[   4]Album:
[   1]Price:
[   2]Delete the album format?
[   5]Format:
