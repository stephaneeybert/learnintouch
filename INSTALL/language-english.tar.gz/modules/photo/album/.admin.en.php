[   0]The photo albums
[   1]Create an album
[   2]Edit the album
[   3]Delete the album
[   4]Location
[   5]Name
[   6]Event
[   7]Date
[   8]The photo formats of the album
[   9]The photos of the album
[  10]Swap with next
[  11]Swap with previous
[  12]Upload a full album
