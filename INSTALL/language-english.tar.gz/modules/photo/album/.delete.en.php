[   0]Delete an album
[   1]Name:
[   5]Event:
[   2]Delete the album?
[   4]Delete the photos of the album
[   6]Confirm:
[   3]The album contains some photos.\n\nDelete the photos first to be able to delete the album.
