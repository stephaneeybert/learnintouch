[   0]Edit an album
[   2]The name is already used by another photo album.
[   3]Location:
[   4]Name:
[   5]Event:
[   6]The name is required.
[   7]If the price is set then it is the unit price for all the photos in the album.
[   8]Publication date:
[   9]Price:
[  10]Hide:
[  11]The photo album can be hidden.\n\nIn that case, it will not be displayed in the list of albums.
[  12]No slideshow:
[  13]By default, the photos are displayed in a slideshow when cliking on a photo.\n\nBut it's possible not to display them in a slideshow.\n\nIn that case, the photos will simply be displayed in a large format.
[  14]No zoom:
[  15]By default, the photos are zoomable.\n\nBut it is possible not to display a zoom of the photo in its original format when the mouse hovers over the photo.\n\nNote that this makes sense only if the original photo is larger than the one displayed.
[  21]A date must have the format
