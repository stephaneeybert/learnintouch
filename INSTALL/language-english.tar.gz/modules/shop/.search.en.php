[   1]The minimun price.
[   2]The maximun price.
[   3]Search
[   5]Reference:
[   6]Category:
[   8]Price min:
[  13]Text:
[  14]It is possible to search for an item containing a particular text.\n\nThe search result displays the items whose name or description contain the typed in text.
[  15]It is possible to search for an item using its reference.
[  16]It is possible to search for the items that have been published for a certain period of time.
[  21]Choose...
[  27]Contact us for more information
[  28]View my selection
[  29]Back to the list of items
[  43]One week
[  44]One month
[  45]Three months
[  46]Six months
[  47]One year
[  48]Since:
[  49]Price max:
