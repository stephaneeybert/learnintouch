[   0]Your order
[   1]Firstname: *
[   2]Lastname: *
[   3]Email: *
[   4]Organisation:
[   5]Telephone:
[   6]Mobile phone:
[   7]Message:
[   8]Type in the informations of your order.\nThe required fields are marked with a star *
[   9]The lastname is required.
[  10]The email is required.
[  11]The email address format is invalid.
[  12]The firstname is required.
[  13]A contact message has been sent to
[  14]Click here
[  15]We have received your message.\n\nOur customer department will contact you shortly.
[  16]Contact message from
[  17]to read the message.
[  18]The email address has an invalid suffix.
[  19]by
[  20]Message :
[  21]for
[  22]Type in this security code
[  23]Security code: *
[  24]Type in the displayed security code.\n\nA security code is required to ensure that the contact message is posted by a person and not by a program.\n\nBecause a program cannot read a number displayed in a graphical form, only a real person can post a contact message.
[  25]Send the order
[  26]Postal box:
[  27]Your shopping cart is empty.
[  29]If the shipping address is different than the invoice address then type in a shipping address. Otherwise, the invoice address will be used as shipping address.
[  30]Address:
[  32]Zip Code:
[  33]City:
[  34]State:
[  35]Country:
[  36]Invoice address
[  37]Shipping address
[  38]The address is required.
[  39]The zip code is required.
[  41]The city is required.
[  42]The country is required.
[  43]You can also leave us a message regarding your order.
[  44]The security code is required.
[  45]The security code is incorrect.
[  46]Check the box if the shipping address is different than the invoice address.
[  47]Fax:
[  48]View the shopping cart content
