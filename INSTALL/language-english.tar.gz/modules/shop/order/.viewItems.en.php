[   0]Order item(s)
[   1]Gift wrap
[   2]Name
[   3]Reference
[   4]Description
[   5]Total
[   6]Shipping and handling fees:
[   7]Total amount:
[   8]Discount:
[   9]VAT
