[   0]Order confirmation
[   1]Firstname:
[   2]Lastname:
[   3]Email:
[   4]Organisation:
[   5]Telephone:
[   6]Mobile phone:
[   7]Message:
[   8]Proceed to on-line payment with a bank card
[   9]Ref:
[  10]Cancel the order
[  11]Confirm the order and proceed to payment.
[  12]Gift wrap
[  13]Your order has been canceled !\n\nYou will be redirected in a few seconds...
[  14]We cannot accept orders for the time being.
[  15]Proceed to delayed payment with a bank transfert
[  16]For administrative reasons, we cannot accept orders for the time being.
[  17]Postal box:
[  18]The email address has an invalid suffix.
[  19]Recipient
[  20]There are no items in the shopping cart.
[  21]Ordered item(s)
[  22]Continue
[  23]Discount:
[  30]Address:
[  32]Zip Code:
[  33]City:
[  34]State:
[  35]Country:
[  36]Invoice address
[  37]Shipping address
[  47]Fax:
[ 110]Shipping and handling fees:
[ 111]Amount to pay:
[ 112]item(s) for a total of:
[ 113]Total:
