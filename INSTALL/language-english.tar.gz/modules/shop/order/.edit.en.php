[   0]Order
[   1]Firstname:
[   2]Due date:
[   3]Organisation:
[   4]Email address:
[   5]Telephone:
[   6]Mobile phone:
[   7]Message:
[   8]Invoice date:
[   9]Total:
[  10]Status:
[  11]The status should be updated after an operation on the order.\n\nFor example, if the order is being shipped then the order status should be updated to Shipped.
[  12]A date must have the format
[  13]View the address...
[  14]The due date must be greater than the invoice date.
[  15]View the item(s)...
[  16]Fax:
[  17]VAT number:
[  18]Invoice number:
[  19]Invoice note:
[  20]The invoice note is a message displayed on the invoice.
[  21]Invoice language:
[  22]The language in which the invoice is rendered.
