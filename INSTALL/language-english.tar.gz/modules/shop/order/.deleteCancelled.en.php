[   0]Delete the cancelled orders
[   1]Delete these orders
[   2]Only the orders with a cancelled status can be deleted.\n\nAll other orders will not be deleted.
[   3]Name
[   4]Order date
[   5]Order Number
