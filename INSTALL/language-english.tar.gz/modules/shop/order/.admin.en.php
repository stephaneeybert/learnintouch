[   0]The shopping orders
[   1]Each order has a status indicating the current state of the order.
[   2]The orders are received by the clients shopping on the website.\n\nIt is possible to list the orders byt their status.\n\nThe paid orders are the ones having been paid and not yet shipped. These orders need to be shipped as soon as possible.\n\nThe shipped orders are the ones having been paid and shipped.\n\nThe pending orders are the ones having been received but not yet paid. These orders should not yet be shipped.\n\nThe cancelled orders are the ones that have not been and will not be paid. These are the orders abandoned by the clients during the website visit. They can possibly be deleted from the system.\n\nThe refund orders are the ones that have been paid by the clients and later refund to them.
[   3]Status:
[   4]Delete the cancelled orders
[   5]View the order
[   6]Download the PDF invoice
[   7]Cancel the order
[   8]Name
[   9]Total amount
[  10]Search:
[  11]It can become tedious to navigate in the list of orders to find a particular order.\n\nTo avoid this, it is possible to do a search based on some typed in text.\n\nThe search result will display all the orders matching the searched text.
[  12]Due date
[  13]The affiliates
[  14]Order date
[  15]Order Number
[  16]Status
[  17]Month:
[  18]It is possible to filter the orders by month.\n\nBy default, the current month is selected.
[  19]The on-line payment solutions
[  20]The preferences
[  21]The shop bank account
[  22]View the client location
[  23]The items
