[   1]item(s)
[   3]View the item
[   4]Reference:
[   5]item(s) for a total of:
[   6]Total amount:
[   7]Shipping and handling fees:
[   8]Gift wrap
[   9]Download the PDF invoice
[  10]Firstname:
[  11]Lastname:
[  12]Organisation:
[  13]Email:
[  14]Telephone:
[  15]Mobile phone:
[  16]Invoice address
[  17]Address:
[  19]Zip Code:
[  20]City:
[  21]State:
[  22]Country:
[  23]Shipping address
[  25]Fax:
[  26]Your shopping orders
[  27]Click on an icon to view an order.
[  28]View the order
[  29]Status:
[  30]Order
[  31]Items
[  32]Total
