[   0]Invoice
[   1]Description
[   2]Quantity
[   3]Unit Price
[   4]Amount
[   5]Payable to:
[   6]Bank:
[   7]Bank account:
[   8]IBAN:
[   9]item(s) for a total of:
[  10]Total amount:
[  11]Shipping and handling fees:
[  12]BIC:
[  13]Invoice number:
[  14]Due date:
[  15]
[  16]VAT number:
[  17]Client:
[  18]Telephone:
[  19]Mobile phone:
[  20]Email:
[  21]Reference:
[  22]Client VAT number:
[  23]Discount:
[  24]VAT
[  25]Total VAT:
