[   0]Edit a discount code
[   1]Discount code:
[   2]Discount rate:
[   3]The discount code is required.
[   4]This discount code already exists.
[   5]The discount rate is required.
