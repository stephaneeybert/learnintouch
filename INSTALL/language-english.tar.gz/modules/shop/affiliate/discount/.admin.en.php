[   0]The discount codes
[   1]Discount rate
[   2]Edit the discount code
[   3]Delete the discount code
[   4]Add a discount code
[   5]Discount code
[   7]An affiliate can have several discount codes, each discount code having a discount rate expressed in percentage.
