[   0]Delete a discount code
[   1]Discount code:
[   2]Delete the discount code?
[   3]Discount rate:
