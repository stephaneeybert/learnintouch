[   0]The affiliates
[   1]Discount codes
[   2]Edit the affiliate
[   3]Delete the affiliate
[   4]Add an affiliate
[   5]Name
[   6]The affiliate's discount codes
[   7]The affiliates are people who are in contact with potential clients.\n\nThey are agents assisting in selling the service.\n\nAn affiliate has discount codes that he gives to his contacts so that these can benefit from a discount when becoming clients.\n\nAn affiliate can have several discount codes, each discount code having a discount rate expressed in percentage.
[   8]Search:
[   9]It can become tedious to navigate in the list of affiliates to find a particular affiliate.\n\nTo avoid this, it is possible to type in all or part of the name of an affiliate and do a search based on the typed in text.\n\nThe search result will display all the affiliates matching the searched text.
