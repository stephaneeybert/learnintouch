[   0]Edit an affiliate
[   1]User:
[   2]An affiliate is a registered user of the system.\n\nTo create a new affiliate, first create a user.\n\nThen choose this newly created user to be an affiliate.
[   3]The user is required.
[   4]This user is already an affiliate.
[  15]Select a user
[  25]Browse...
