[   0]Delete an affiliate
[   1]Email:
[   2]Delete the affiliate?
[   3]Name:
