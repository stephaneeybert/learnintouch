[   0]The categories of items
[   1]Move into the page
[   2]Edit the category
[   3]Delete the category
[   4]Add a category
[   5]Name
[   6]Description
[   7]Move after the page
[   8]Move before the page
[  10]Swap with next
[  11]Swap with previous
