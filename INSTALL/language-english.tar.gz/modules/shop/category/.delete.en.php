[   0]Delete an item category
[   1]Name:
[   5]Description:
[   2]Delete the category?
[   3]The category cannot be deleted because it is used by some items.
