[   0]The shop items
[   1]Create an item
[   2]Edit the item
[   3]Delete the item
[   4]Name
[   5]Description
[   6]The categories
[   7]Manage the images of the item
[   8]Url
[   9]Category:
[  10]Swap with next
[  11]Swap with previous
[  12]Image
[  13]The shop items are goods on sell.\n\nEach item has a description.\n\nAn item can also have images.\n\nThe items can be sorted by category, model and range.
[  16]The shopping orders
[  70]Search:
[  71]It can become tedious to navigate in the list of items to find a particular item.\n\nTo avoid this, it is possible to do a search based on some typed in text.\n\nThe search result will display all the items matching the searched text.
