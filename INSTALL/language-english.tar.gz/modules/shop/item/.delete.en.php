[   0]Delete an item
[   1]Name:
[   2]Delete the item?
[   3]Short description:
[   4]The item is used by one or more orders:
[   6]Firstname
[   7]Lastname
[   8]Email
[   9]Order Date
[  10]Status
[  11]Delete the item and keep the orders:
