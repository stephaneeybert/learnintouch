[   0]Delete an image
[   1]Image:
[   3]Description:
[   2]Delete the image?
