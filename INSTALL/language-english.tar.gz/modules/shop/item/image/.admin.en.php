[   0]The images
[   1]Add an image
[   2]Edit the image
[   3]Delete the image
[   4]Image
[   5]Description
[   6]Name:
[   7]Reference:
[   8]Change the image
[  10]Swap with next
[  11]Swap with previous
[  13]There can be several images for one item.\n\nEach image can have a description.\n\nThe images can be displayed in a specified order.
