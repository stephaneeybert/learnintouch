[   0]The seller
[   1]These informations are displayed on the invoices sent to the clients.
[   2]Shop name:
[   3]The shop name is displayed in the footer on the client invoices.
[   4]The email address format is invalid.
[   5]Address:
[   6]The shop address is displayed in the footer on the client invoices.
[   7]Telephone:
[   8]The shop telephone is displayed in the footer on the client invoices.
[   9]Mobile phone:
[  10]The shop mobile phone is displayed in the footer on the client invoices.
[  11]Email:
[  12]The shop email address is displayed in the footer on the client invoices.
[  13]Bank name:
[  14]The shop bank name is displayed in the footer on the client invoices.
[  15]Bank account:
[  16]The shop bank account is displayed in the footer on the client invoices.
[  17]IBAN number:
[  18]The shop IBAN number is displayed in the footer on the client invoices.
[  19]BIC number:
[  20]The shop BIC number is displayed in the footer on the client invoices.
[  21]Zip code:
[  22]Country:
[  23]Company registration number:
[  24]The company registration number is the identification number of the company with the legal authorities.
[  25]VAT number:
[  26]The VAT number is the identification number for the value added tax.
