[   0]List of banks
[   1]Specify the Paypal account information
[   2]Bank card with Paypal
[   3]Bank transfert
[   4]Specify the bank account information
