[   0]The payment has been completed.\n\nYour order has been accepted!
[  19]The payment has NOT been completed.\n\nYour order is still pending.
[   1]A new order from
[  20]has been paid at
[   2]An order has been paid from
[   4]view the order
[   5]has received your order!
[   6]Dear
[   7]We have received your order with the reference:
[   9]We thank you for your purchase.
[  10]Kind Regards,
[  12]You can view the status of your order using the following email address and password:
[  13]Email:
[  14]Password:
[  15]view the status of your order
[  17]The order reference number is:
[  18]Your order will display in a few seconds...
[  21]The client can be contacted at
[   3]You can
[   8]log into your account.
[  11]Once logged in, you can
[  16]change your password
