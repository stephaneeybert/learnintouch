[   1]The payment has NOT been completed.\n\nYour order is still pending.
[   0]You can click here to go back to your order.
