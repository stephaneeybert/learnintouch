[   0]The payment has failed or has been canceled.\n\nYour order has not been accepted.
