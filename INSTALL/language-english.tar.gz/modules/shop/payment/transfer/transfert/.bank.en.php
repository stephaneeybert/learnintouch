[   0]The external bank details pages
[   1]For each language, a page can be specified as being the external bank details page.\n\nThe page will be displayed after a visitor sends an order and pays manually by a bank external to the shop.
[   2]Specify the external bank details page for the language
[   3]Language
[   4]Web page
[   5]The external bank details page for the computers
[   6]The external bank details page for the phones
