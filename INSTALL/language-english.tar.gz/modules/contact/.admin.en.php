[   0]The messages
[   1]Email
[   2]View the message
[   3]Put the message in the garbage
[   4]Subject
[   5]Telephone/Mobile
[   6]The statuses
[   7]The preferences
[   8]Date/Time
[   9]Status:
[  10]The contact messages are the messages received from the users of your web site.\n\nThese messages are often first contact messages.\n\nIt is preferable that your users contact you through this contact form, than to publish your email address on the web site.\n\nPublishing an email address on a web site exposes it to spam.\n\nIt is therefore advised not to publish your email address on your web site.\n\nMoveover, this messages system allows you to process the incoming messages by marking them using some processing status.
[  11]Delete all the messages
[  12]Name
[  13]Send an email
[  14]Read the message
[  15]The example form to download
[  16]The referers
[  32]The messages dumped in the garbage
