[   0]The garbage
[   1]Empty the garbage
[  11]Retrieve the message
[   7]Name
[   6]Description
[   9]When a message is being deleted, it is actually stored in the garbage.\n\nThe messages can be retrieved from the garbage.\n\nEmptying the garbage permanently deletes all the messages stored in it.
