[   0]Delete a message
[   2]Delete the message?
[   3]Subject:
[   4]From:
