[   0]The status
[   1]Add a status
[   2]Edit the status
[   3]Delete the status
[   4]Name
[  10]Swap with next
[  11]Swap with previous
[   9]The status are used to manage the contact messages.\n\nThey help by marking the stages in the processing of the messages.\n\nThe status can, for example, sort the incoming messages from those that have already been processed, or those that are now archived, or those that should be deleted.\n\nThe status can be ordered using the up and down arrows.\n\nCreate a few status and use them to sort your messages.
