[   0]Delete a status
[   2]Delete the status?
[   3]Name:
[   4]Description:
