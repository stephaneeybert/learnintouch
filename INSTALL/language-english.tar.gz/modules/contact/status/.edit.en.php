[   0]Edit a status
[   1]Name:
[   2]Description:
[   3]The name cannot be empty.
