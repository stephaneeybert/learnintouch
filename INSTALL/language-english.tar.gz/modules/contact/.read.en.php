[   0]Read a message
[   1]Name:
[   2]Subject:
[   3]Message:
[   4]Organisation:
[   5]Telephone:
[   6]Email:
[   7]Put the message in the garbage
[   8]Referer:
[   9]You can update the message status after having read the message.
[  10]Status:
