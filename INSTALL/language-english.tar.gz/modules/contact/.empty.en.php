[   0]Delete the messages
[   1]Status:
[   2]Delete all these messages?
[   3]Email
[   4]Subject
[   5]The contact messages can be delete one by one but that can quickly become tedious.\n\nA quicker way to delete several messages is to select all the messages of one particular status, and delete them all.
[   6]Choose a status before deleting all the messages of a status.
[   8]Date/Time
[  12]Name
