[   0]The referers
[   1]Add a referer
[   2]Edit the referer
[   3]Delete the referer
[   4]Description
[  10]Swap with next
[  11]Swap with previous
[   9]The referers are used to offer in the contact form, a list of options from which the visitor can choose how he has found out about the website.\n\nIt can be interesting to know how the visitors have found out about the website, be it an ad, a search engine, a web portal, word of mouth, etc...
