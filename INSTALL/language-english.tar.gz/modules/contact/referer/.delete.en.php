[   0]Delete a referer
[   2]Delete the referer?
[   4]Description:
