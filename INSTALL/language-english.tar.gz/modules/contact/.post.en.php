[   0]Contact Message
[   1]Firstname:
[   2]Lastname:
[   3]Email:
[   4]Organisation:
[   5]Telephone:
[   6]Subject:
[   7]Message:
[   8]Type in your email address and your message.\nThe required fields are marked with a star *
[   9]Referer:
[  10]The email is required.
[  11]The email address format is invalid.
[  12]The message is required.
[  13]How did you hear about us?
[  14]Send
[  18]The email address has an invalid suffix.
[  15]We have received your message.\n\nOur customer department will contact you shortly.
[  23]Security code: *
[  24]Type in the displayed security code.\n\nA security code is required to ensure that the contact message is posted by a person and not by a program.\n\nBecause a program cannot read a number displayed in a graphical form, only a real person can post a contact message.
[  22]Type in this security code
[  33]The security code is required.
[  34]The security code is incorrect.
