[   0]Empty the garbage
[   2]Permanently delete all the messages of the garbage?
