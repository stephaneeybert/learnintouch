[   0]The form has been received.\n\nThank you for your participation!
[   1]A new form has been sent at
[   2]A visitor of the website has filled up and sent a form at
[   3]The content of the form is the following:
[   4]Kind Regards
