[   0]Specify the page
[   1]Web page:
[   5]Language:
[   4]Browse...
[   2]Select a page of the web site
[   7]The web page is selected in the list of the website pages.\n\nThe page must be a page of the web site.
