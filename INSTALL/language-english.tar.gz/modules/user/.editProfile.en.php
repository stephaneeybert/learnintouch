[   0]User profile
[   1]Mails:
[   2]Upload a new photo
[   3]Profile:
[   4]Photo:
[   5]Email:
[   7]Mobile phone:
[   8]Home phone:
[   9]Fax:
[  10]Work phone:
[  11]Organisation:
[  12]Postal box:
[  13]Address:
[  14]Address:
[  15]Zip Code:
[  16]City:
[  17]State:
[  18]Country:
[  19]Sms:
[  20](Check to receive sms messages from us)
[  21]Save
[  22]Change the password
[  23]The fields with a star * character are mandatory.
[  24](Check to receive emails from us)
[  25]Firstname: *
[  26]Lastname: *
[  30]The address is required.
[  31]The zip code is required.
[  32]The zipcode must contain only numbers.
[  33]The city is required.
[  34]The country is required.
