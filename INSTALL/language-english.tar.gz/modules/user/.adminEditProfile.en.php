[   0]The user profile
[   1]The user address
[   2]Address:
[   3]Address:
[   4]Zip Code:
[   5]City:
[   6]State:
[   7]Country:
[   8]Home phone:
[   9]Fax:
[  10]Work phone:
[  11]Firstname: *
[  12]Lastname: *
[  13]Email: *
[  14]Sms subscription:
[  15]Profile:
[  16]Mails subscription:
[  17]Mobile phone:
[  18]Organisation:
[  19]Postal box:
