[   0]Delete the users of the last import
[   1]Delete the users of the last import?
[   2]Number of users of the last import:
[   3]List of users of the last import
[   4]There was no import.
