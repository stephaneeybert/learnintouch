[   0]Change your password
[   1]Email address: *
[   2]Current Password: *
[   3]Then type and confirm your new password.
[   4]New Password: *
[   5]Confirm password: *
[   6]Change the password
[   9]Your password has been updated!
[  20]The new password is required.
[  21]The two passwords are not identical.\n\nYou must type an identical password in the two password fields.
[  25]The email address is required.
[  27]The current password is required.
[  28]Your current email address or or your password is incorrect.
[  99]Type in your email address and your current password.
