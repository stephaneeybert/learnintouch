[   0]Email address validation
[   1]Your email address has now been validated.
[   2]The user could not be found.
[   3]The validation email expired.
[   4]You can
[   5]to log in.
[   6]click here
[   7]to contact us.
[   8]The user with id
[   9]could not be found on his email address confirmation.
[  10]had an invalid link on his email address confirmation.
