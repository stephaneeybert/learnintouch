[   0]The email address is required.
[   1]The email address is invalid.
[   2]A user with this email address already exists.\n\nPlease choose another email address.
[   3]The mobile phone number must be specified to send sms messages to the user.
[  20]The firstname is required.
[  21]The lastname is required.
[  34]The mobile phone number must contain only digits.
[  35]The fax number must contain only digits.
[  36]The telephone number must contain only digits.
