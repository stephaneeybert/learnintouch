[   0]Mail Unsubscription
[   1]Your subscription to the mails has been de-activated.\n\nYou won't receive any more mails from us untill you reactivate your subscription.\n\nYou can nevertheless at any time reactivate your subscription.
