[   0]The users
[   1]Delete the user
[   2]Import a list of users
[   3]Register a user
[   4]Edit the user profile
[   5]Assign a new password
[   6]The users are the visitors who can log into the web site.\n\nThey have registered themselves or have been registered by an administrator.\n\nThey can log into the website using a login name and a password.\n\nOnce a user has logged in, he can access the protected content of the website.\n\nEach user has a unique login name that is his email address.
[   7]Delete the users of the last import
[   8]Export all the users
[   9]The preferences
[  10]Name
[  11]Email
[  12]Number of users:
[  13]Search:
[  14]It can become tedious to navigate in the list of users to find a particular user.\n\nTo avoid this, it is possible to type in all or part of a user name or email address and do a search based on the typed in text.\n\nThe search result will display all the users matching the typed in text.
[  15]Not valid since
[  16]Specify the post user login pages
[  17]Insert or delete an image
[  18]Valid until
[  19]Valid
[  20]Account validity:
[  21]When a user has REGISTERED HIMSELF, he can log in with his password only during a period of time.\n\nDuring that period an administrator is able to confirm the user registration and the user login is no longer limited in time.\n\nBut if the user account is not confirmed by an administrator in time then the user won't be able to log in when this period expires.
[  22]Not valid since
[  23]Valid until
[  24]Valid
[  25]Validate the user account
[  26]Invalidate the user account
[  27]Organisation
[  28]Mailing:
[  29]SMS:
[  30]Subscribed
[  31]Not subscribed
[  32]A user can be subscribed to the mailings.\n\nIn that case, he will receive the mailings that are sent to him.\n\nOtherwise, he will not receive any mailings, even if his email address is part of the mailing recipients.
[  33]A user can be subscribed to the sms messages.\n\nIn that case, he will receive the sms messages that are sent to him.\n\nOtherwise, he will not receive any sms messages, even if his mobile phone number is part of the sms recipients.
[  34]Email not confirmed
[  35]Login
[  36]The date the user has logged in for the last time.
[  37]Last login:
[  38]The period during which users have logged in for the last time.
[  39]Week
[  40]Month
[  41]Year
[  42]More
[  43]Validity
[  44]Quarter
[  45]Semester
