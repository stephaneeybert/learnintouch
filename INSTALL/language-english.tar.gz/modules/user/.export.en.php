[   0]Export the users
[   1]Export all the users into a text file?
