[   0]The login redirection pages
[   1]For each language, a page can be specified as being the post user login page of the website.\n\nThe page will be displayed after a user logs into the website with his login name and password.\n\nNote that it may be advised not to redirect the user to a specific page.\n\nIn that case the user will be redirected to the page he originally requested.
[   2]Specify the post login page for the language
[   3]Language
[   4]Web page
[   5]The post login page for the computers
[   6]The post login page for the phones
[   7]The expired login pages
[   8]For each language, a page can be specified as being the expired user login page of the website.\n\nThe page will be displayed if the user login has expired.\n\nThe user login expires if it has a validity date, and that date has passed.
[   9]Specify the expired login page for the language
[  10]The post login pages
[  11]The expired login page for the computers
[  12]The expired login page for the phones
