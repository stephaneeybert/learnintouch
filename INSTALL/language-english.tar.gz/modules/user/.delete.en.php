[   0]Delete a user
[   1]Delete the user?
[   3]User name:
[   2]The user is a teacher. Delete the teacher first before deleting the user.
[   4]Deleting the user will delete all his courses subscriptions and all his exercises results.
[   5]The user has subscribed to
[   6]course(s).
[   7]The user has
[   8]shopping order(s).
[   9]Deleting the user will delete all his shopping orders.
