[   0]Stay logged in for
[   1]week
[   2]click here
[   3]Log in
[   4]Your email address has not yet been confirmed. Please, search in your email inbox for our email containing the confirmation link.
[   4]weeks
[   5](cookies)
[   6]Cookies\n\nWhat are cookies and why do I need them?\n\nA cookie is a small file containing text informations. These informations can be connection parameters to a web site, user preferences or any other types of data.\n\nWhen you log into our web site, you can ask us to remember your login parameters. So that you avoid typing them in on every visit. We then send you a cookie containing these parameters. The cookie is stored in your browser.\n\nWhy your web site keeps asking me my login parameters whereas I have authorised the cookies on my browser?\n\nCheck that your browser accepts cookies. See below for specific instructions to change the options in your browser. If the problem remains, then this may be due to a firewall program between your computer and the Web.\n\n\nHow can I change the settings of my browser so that it acceps cookies?\n\nThe directions to change the settings relating to cookies vary depending on the browser you use. See below for more sp�cific details on the most common browsers. You can also get some information about cookies by visiting the web sites of Microsoft and Netscape.\n\nHow do I accept cookies in Internet Explorer?\n\nWith Internet Explorer 5.0 and previous versions, cookies are in the Security tab of the Internet Options option of the Tools menu.\n\nWith Internet Explorer 6.0, cookies are in the Private tab of the Internet Options option of the Tools menu.\n\nWith Netscape Navigator, cookies are in the Preference option of the Edit menu.\n\n\nBlocking cookies\n\nYou can block cookies for all the web sites. You can also block cookies for certain web sites only.\n\nNB: If you block cookies for all the web sites, then some features of these web sites may not work any more. If you block session cookies, then certain pages and services of these web sites will not work any more.\n\n\nGeneralities about cookies\n\nAccording to the law on electronic information, all web sites that use cookies must inform their visitors that:\n\n- The web site contains cookies\n- What usage these cookies have\n- How to avoid these cookies\n\nThere are two types of cookies:\n\n- Cookie: Holds an information permanently on the hard drive, is kept even after the computer has been shut down.\n- Session Cookie: Holds an information temporarily in memory (RAM), disappears when the browser is closed or when the computer is shut down.\n\n\nOur web site and cookies\n\nOur web site uses session cookies to conserve technical informations between the different web pages of our web site, and to keep your choices between the different pages. 
[   7]The cookies are used to ensure the browser works fine during your visit on the pages of our web site. The server uses cookies too for its inner working. No personnal or sensitive information is held or used in our cookies.\n\nYour web browser must have the session cookies option activated for the pages of our web site to work correctly. Most of the web browsers have this option activated (session cookies are very common). If this option is not activated in your web browser, you can easily activate it yourself. Please see the options or the help of your web browser.
[   8]has a not yet confirmed email address.
[   9]The email address is required.
[  10]Your user account has expired since the
[  11]You can also
[  12]The password is required.
[  13]The login name or the password is incorrect.
[  14]to contact us.
[  15]The email address you used during registration, was:
[  16]The user with the email address
[  17]is no longer valid.
[  20]Auto login:
[  21]Check this box to be remembered by the system and skip the login procedure on your next visit.\n\nYou will then be automatically connected on your next visit.\n\nIf you use a shared computer, like in an Internet caf� or in a library, then do not check this box.\n\nThat is because this option makes use of cookies.\n\nAs your login parameters will be stored on the computer, in a cookie text file, enabling this option can represent a risk for the confidentiality of these parameters.
[  22]User Login
[  23]Type in your email address and your password.
[  24]Email address:
[  25]Password:
[  26]If you have lost your password
[  27]click here
[  28]To register
