[   0]User account
[   1]User name:
[   2]Make the user account permanent?
[   3]Invalidate the user account?
[   4]The user account is valid until:
[   5]The user account is not limited in time.
[   6]The user account is not valid since:
