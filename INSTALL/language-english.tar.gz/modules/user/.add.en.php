[   0]User registration
[   1]The fields with a star <B>*</B> character are mandatory.
[   2]Email address: *
[   3]Firstname: *
[   4]Lastname: *
[   5]Password: *
[   6]Confirm password: *
[  11]Mobile phone:
[   9]Security code: *
[  10]Type in the displayed security code.\n\nA security code is required to ensure that the user registration is done by a person and not by a program.\n\nBecause a program cannot read a number displayed in a graphical form, only a real person can register as a user.
