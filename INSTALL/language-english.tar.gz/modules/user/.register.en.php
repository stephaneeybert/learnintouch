[   0]User registration
[   1]The fields with a star * character are mandatory.
[   2]Email address: *
[   3]Firstname: *
[   4]Lastname: *
[   5]Password: *
[   6]Confirm password: *
[   7]I would like to receive your emails
[   8]You will receive an email containing your password.
[   9]Security code: *
[  10]Type in the displayed security code.\n\nA security code is required to ensure that the user registration is done by a person and not by a program.\n\nBecause a program cannot read a number displayed in a graphical form, only a real person can register as a user.
[  11]Type in this security code
[  12]Mobile phone:
[  13]I accept the
[  14]terms of service
[  15]Register
[  16]Your email address will need to be confirmed. After your registration, search in your email inbox for our email containing the confirmation link.
