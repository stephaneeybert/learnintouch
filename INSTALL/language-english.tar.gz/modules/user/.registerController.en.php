[   0]Your password from
[   1]Your password is:
[   2]You must accept the terms of service.
[   3]Your email address is:
[  33]The security code is required.
[  34]The security code is incorrect.
[  37]The email is required.
[  38]The email address format is invalid.
[  39]The firstname is required.
[  40]The lastname is required.
[  41]The password is required.
[  42]The two passwords must be identical.
[  43]The password must contain only alphanumerical characters, like:
[  44]The email address has an invalid suffix.
[  46]Someone has already picked this email address.\n\nYou must choose another email address.
[  50]The user has been registered.
