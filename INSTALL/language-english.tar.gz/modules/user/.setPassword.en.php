[   0]Change a password
[   2]User name:
[   3]To assign a new password to a user, type and confirm a password.
[   4]New Password:
[   5]Confirm password:
[   6]Type in a password for the user.
[   7]Type in the password again, to make sure you have typed it correctly.
[  20]The password is required.
[  21]The two passwords are not identical.\n\nYou must type an identical password in the two password fields.
[  10]Your new password has been updated at
[  11]Think about using a password hint to help you remember your password.\n\nYour passwor is now:
[  12]Kind Regards
[  43]The password must contain only alphanumerical characters, like:
