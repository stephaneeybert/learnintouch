[   0]Your password from
[   1]Your new password is:
[   2]Continue
[   5]An email containing a new password has been sent to:
[   3]Your email address is:
[   9]Password
[  10]Type in your email address...
[  11]Email address:
[  12]The email address is required.
[  13]The email address format is invalid.
[  14]Your email address is unknown.
