[   0]Delete a website
[   1]Name:
[   5]Domain name:
[   2]Delete the website?
