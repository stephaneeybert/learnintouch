[   0]Edit a website
[   1]Firstname:
[   2]Lastname:
[   3]Domain name: *
[   4]Email:
[   5]Package:
[   6]The system name is required.
[   7]The database name is required.
[   8]Database name: *
[   9]System name: *
[  10]Website name: *
[  12]The domain name is required.
[  13]The email address format is invalid.
[  14]The website name is required.
[  15]Disk space
[  16](Mb)
