[   0]The websites
[   1]Delete the website
[   2]Create a website
[   3]Name
[   4]Website
[   5]Duration
[   6]Edit the informations
[   7]Opening date
[   8]Module usage permissions
[   9]Termination date
[  10]Edit the address
[  11]The subscriptions
[  12]Disk space usage
[  13]Disk usage
[  14]Extend the disk space!
[  15]Package
[  16]Renew the subscriptions
[  17]Export the new invoices
[  18]Edit the options
