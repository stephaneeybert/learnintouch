[   0]Subscription
[   2]Website:
[   5]Opening date:
[   1]Termination date:
[   7](YYYY-MM-DD)
[   8]Auto renewal
[  13]Fee:
[  15]Duration:
[  17]The duration must be comprised between 1 and 12 months.
