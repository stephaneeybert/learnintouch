[   0]Subscription to the elearning platform and website management system of Thalasoft.com for the period of
[   1]to
[   2]for a monthly fee of
[   3]and a duration of
[   4]month(s).
