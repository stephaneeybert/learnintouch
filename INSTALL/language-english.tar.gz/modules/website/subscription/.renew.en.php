[   0]Renew the subscriptions
