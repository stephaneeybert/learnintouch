[   0]Delete a subscription
[   1]Termination date:
[   2]Website:
[   5]Opening date:
[  13]Fee:
[  15]Duration:
