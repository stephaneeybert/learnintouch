[   0]The subscriptions
[   1]Delete the subscription
[   2]Create a subscription
[   3]Website:
[   4]Opening date
[   5]Fee
[   6]Edit the subscription
[   7]Auto renewal
[   8]Generate an order
[   9]Termination date
[  10]Renew the subscription
[  15]Duration
