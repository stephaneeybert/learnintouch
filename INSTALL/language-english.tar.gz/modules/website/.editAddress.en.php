[   0]Website address
[   1]Postal box:
[   2]VAT number:
[  13]Address:
[  14]Address:
[  15]Zip Code:
[  16]City:
[  17]State:
[  18]Country:
[  19]Telephone:
[  20]Mobile phone:
[  21]Fax:
[  33]The mobile number must contain only digits.
[  34]The fax number must contain only digits.
[  36]The telephone number must contain only digits.
