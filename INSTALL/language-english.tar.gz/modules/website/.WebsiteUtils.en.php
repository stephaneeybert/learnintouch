[   0]The basic package
[   1]The standard package
[   2]The advanced package
