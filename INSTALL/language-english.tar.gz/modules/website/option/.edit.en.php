[   0]Website options
[   7]Website name:
[   9]Options
[   8]Select the options for the web site.\n\nThe options that are not selected won't be accessible by the web site.
