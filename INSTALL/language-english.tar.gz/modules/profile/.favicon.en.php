[   0]Upload a favicon file
[   3]File name:
[   2]Select a file:
[   7]Delete the file?
[  10]A favicon is a file displayed before the name of the web site in the browser.\n\nIt is also displayed before the name of the web site in the list of bookmarks of the browser.\n\nA favicon file is not exactly an image file.\n\nIt has a specific file format and must be named favicon.ico\n\nTo display a favicon, create a favicon.ico file and upload it to the server.\n\nThe image width must be a multiple of 8 and less than 256 and the image height must be less than 256.
