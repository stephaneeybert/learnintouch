[   0]The profile
[   1]The profile of the web site is a set of informations used to describe and identify the web site content.\n\nThese informations are also used to identify the web site when communicating with the users visiting the web site.\n\nThey are often used by search engines to reference the web site.\n\nIt is important that these informations be accurate.
[   2]Upload the website logo
[   3]Upload the web site favicon file
[   4]Name
[   5]Value
[   6]Upload the access map
[   7]Upload the iPhone/iPod application icon
[  10]The preferences
