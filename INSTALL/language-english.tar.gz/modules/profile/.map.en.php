[   0]Upload a map
[   3]Image name:
[   1]Image:
[   2]Select an image:
[   7]Delete the image?
[  10]The access map is used to help people locate the premises of the company or organisation.\n\nUsually such a map can be found in phone directory website.
