[   0]Upload a logo
[   1]Image:
[   2]Select an image:
[   3]Image name:
[   4]Image url:
[   7]Delete the image?
[  10]The web site logo is used to identify the web site.\n\nIt can, for example, be used in a signature, when sending an email to the users.
