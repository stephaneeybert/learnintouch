[   0]Upload an iPhone/iPod application logo
[   1]Image:
[   2]Select a file:
[   3]File name:
[   7]Delete the file?
[  10]An application logo is an image displayed as an icon in an iPhone or iPod.\n\nClicking on the image starts the application.\n\nThe image must have a .png format with a width of 57 and a heigth of 57.
