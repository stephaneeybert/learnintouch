[   0]Delete a category
[   1]Name:
[   5]Description:
[   2]Delete the category?
[   3]The category contains some documents.\n\nDelete the documents or remove them from their category, to be able to delete the category.
