[   0]Upload a document
[   3]File name:
[   2]Select a file:
[   8]There are currently no categories.\n\nPlease, create a category before uploading documents.
