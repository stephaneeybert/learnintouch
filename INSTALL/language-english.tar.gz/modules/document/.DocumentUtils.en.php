[   0]Document to download:
[   1]Download the document
[   2]Ref:
[   3]Download
[   4]Display all the documents:
[   5]By default, when no category has yet been selected by a visitor of the website, only the documents of the first category are displayed.\n\nBut it is possible to display all the documents instead of only the ones of the first category.
[   6]Hide the selector:
[   7]By default, a category selector is displayed on top of the list of documents.\n\nBut this selector can be hidden to prevent the selection of another category.
[   8]View
[   9]Issuu:
[  10]By default, the documents can only be downloaded.\n\nBut it is possible to view them directly on the website.\n\nYou need to register at www.issuu.com and go to the page http://www.issuu.com/smartlook\n\nFrom there, you just enter the domain name of your website and copy the code into the preference.\n\nAfter that, you must refresh the models of your website.
[  32]Number of documents per row:
[  33]The lists of documents can display several documents per row.\n\nThe number of documents per row can be modified.\n\nThe number of images per row can be modified.
