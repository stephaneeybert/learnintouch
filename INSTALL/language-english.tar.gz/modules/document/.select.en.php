[   0]Select a document
[   1]Category:
[   2]Document:
[   3]If choosing a document, then the link will point to one document offered for download.\n\nIf choosing a category, then the link will point to the category of documents, and the page will display all the documents of the category.\n\nChoose either a document or a category.
[   3]Choose a document or a category of documents.\n\nIf a document is chosen then a click on the html link will offer the document for download.\n\nIf, on the other hand, a category is chosen, then a click on the link will redirect to a page displaying all the documents of the category.
[   4]Choose a document OR a category of documents.
