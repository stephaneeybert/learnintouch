[   0]Edit a document
[   1]Hide:
[   2]A document can be stored into a category.\n\nThis offers an easier storage of the documents.
[   3]A short description of the document.\n\nThis can be a short memo about the document.
[   4]By default a document is published.\n\nA document must be published to be displayed on the web site.\n\nA published document can be downloaded by the visitors of the web site.\n\nBut a document can be hidden.\n\nA hidden document is not displayed on the website and cannot be downloaded by the visitors of the website.
[   5]Category:
[   6]Reference:
[   7]Description:
[   8]A reference to identify the document.\n\nThis can be a name or a sequence of numbers and/or letters.
[   9]File:
[  10]The filename of the document.
[  11]Secure the access:
[  12]By default, the users are not required to log in, in order to download a document.\n\nBut a document can be protected and its access reserved to the registered users of the website.\n\nIn that case, a user will have to log in before being able to download this document.
