[   0]Delete an RSS source
[   1]Language:
[   2]Delete the RSS source?
[   5]Url:
