[   0]Add an RSS source for a language
[   1]Url:
[   2]The url is the XML address pointing to the RSS source.\n\nIt the RSS source is available in several languages then there is a url for each language of the RSS source.
[   3]Title:
[   4]By default, the title is provided by the RSS source.\n\nBut is it possible to specify a title.\n\nIn that case, the specified title will be displayed instead of the one provided by the RSS source.
[  19]Language:
[  21]A language can be assigned to an RSS source.\n\nIf so, the RSS source is only displayed if its assigned language is the one chosen by the user visiting the web site.
