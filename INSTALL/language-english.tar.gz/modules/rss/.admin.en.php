[   0]An RSS source
[   1]Add an RSS source for a language
[   2]Title
[   3]Delete the RSS source
[   4]Language
[   5]Url
[   7]An RSS source allows the publication of news stories from external websites.\n\nIf the RSS source is available in several languages then it is possible to display the RSS source in these different languages.\n\nA url to the RSS source can be added for each language of the website.
[  13]For all languages
[  14]Close the window
[  15]for the language
[  22]Edit the RSS source
