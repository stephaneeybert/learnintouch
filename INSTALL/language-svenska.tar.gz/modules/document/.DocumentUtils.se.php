[   0]Dokument att ladda ner:
[   1]Ladda ner dokumentet
[   2]Ref:
[   3]Nerladdning
[   4]Visa alla dokument:
[   5]Som standard, när ingen kategori har valts av besökaren, visas bara dokumenten från första kategorin.\n\nDet är möjligt att visa alla dokumenten istället för bara de från första kategorin.
[   6]Göm väljaren:
[   7]Som standard, en kategoriväljare visas ovanför listan av dokument.\n\nMen denna väljare kan gömmas för att hindra valet av en annan kategori.
[   8]Visa
[   9]Issuu:
[  10]Som standard, dokumenten kan bara laddas ner.\n\nDet är möjligt att kunna se dem på webbsidan.\n\nDu måste gå till hemsidan www.issuu.com och gå till webbsidan http://www.issuu.com/smartlook\n\nDärifrån behöver du bara skriva in din hemsidas domännamn och kopiera koden i inställningar.\n\nEfter måste du uppdatera modulerna på din hemsida.
[  32]Antal dokument på rad:
[  33]Listan av dokument kan visa flera dokument per rad.\n\nAntalet dokument per rad kan ändras.\n\nAntalet bilder per rad kan ändras.
