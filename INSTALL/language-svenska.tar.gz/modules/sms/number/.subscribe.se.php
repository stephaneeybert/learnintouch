[   0]Prenumeration
[   1]Du kan lämna ett mobilnummer för att få meddelanden på sms
[   2]Nummer:
[   3]Register
[   4]Förnamn:
[   5]Efternamn:
[   6]Lista:
[   7]Det är möjligt att prenumerera på mer än en sms-lista
[   8]Ett nummer behövs.
[   9]Numret måste bestå av siffror
[  10]Detta nummer finns redan registrerat.
