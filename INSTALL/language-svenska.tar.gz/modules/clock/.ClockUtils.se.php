[   1]Format av datum:
[   2]Datumets språk:
[   3]Datumet kan visas i ett format där dag och månad skrivs i bokstäver.\n\nI sådana fall används standardspråket för att visa datum.\n\nDet är möjligt att byta språk av visningen av datum.\n\nNote that this language is not used by the web site administration interface.
[  10]Tid format:
[  27]Datum i nummer format:
[  32]Datumet i nummer används bara på webbsidan i administrationsgränssnitt. \n\nDatum i siffror används inte på sidorna på hemsidan.\n\nDet erbjuder administratörerna val av olika format av datum. \n\nDet finns ett Amerikanskt format eller eller Europeiskt format för visning av datum.
[  33]Det finns ett stort utbud av olika datum format.\n\nDet valda formatet av datum används för att visa datumet på hemsidan.\n \nDet används inte på administratörens sida.
[  35]Det finns flera olika format för tid.
