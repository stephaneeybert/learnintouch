[   0]Ladda upp en bild
[   6]Bild:
[   7]Radera bilden?
[  27]Ingen bild har angetts
[   2]Välj en bild:
[   3]Bildnamn:
