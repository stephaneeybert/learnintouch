[   0]Redigera en klient
[   6]Namn:
[   7]Beskrivning:
[   8]Url:
[   4]Klientens namn är begärt.
[  21]Ett url måste börja med sekvensen.
