[   0]Bildernas bredd:
[   1]Bildernas bredd då de visas i listan.
[   2]Bredd av bildens cykel (mall):
[   3]Bildens bredd då den visas i en cykel i en del av hemsidans mall.\n\nTill exempel, en banner som visas på sidan av hemsidans mall.
[   4]Bildens bredd (telefon):
[   5]Bildens bredd då den visas i listan på i en mobil.
[   6]Bildcykelns bredd (sida):
[   7]Bildens bredd då den visas i en cykel i en del av hemsidans sida.\n\nTill exempel bilder på en sida.
[  12]Bild cykelns hastighet
[  13]Hastigheten i vilken bildens cykel visas (sec)
