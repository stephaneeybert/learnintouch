[   0]Radera en klient
[   1]Namn:
[   2]Radera klienten?
[   3]Beskrivning:
[   5]Url:
