[   0]Form:
[   1]Detta är ett låtsas användar validations meddelande.
[   2]Email tomt fält:
[   3]Som standard visas inte tomma fält i svarsmailet. \n\nMen det är möjligt att visa dem.
[  22]Skriv in denna säkerhetskod.
[  23]Säkerhetskod: *
[  24]Skriv in det visade säkerhetskoden.\n\nEn säkerhetskod är nödvändig för att se till så att kontaktmeddelandet är skrivet av en person och inte en robot/program.\n\nDärför att ett program inte kan läsa av en kod som visas i en grafisk form, bara en person kan skriva ett kontaktmeddelande.
[  40]Bredd på formbilden:
[  41]Bredden på fomrbilden.
[  42]Bredden på formbilden i telefon:
[  43]Bredden på formbilden då den visas i en telefon eller mindre skärm.
