[   0]Fältet
[   1]är tomt.
[   2]är för långt.
[   3]är inte tillräckligt långt.
[   4]har ett för stort värde.
[   5]har ett för litet värde.
[   6]har en inkorrekt emailadress.
[   7]har en inkorrekt bankkort nummer.
[   8]har ett felaktigt datum.
[   9]är inte ett nummer.
[  10]Ett nytt formulär har skickats till
[  11]En av websidans besökare har fyllt i och skickat in en formulär.
[  12]Forumlärets innehåll lyder följande:
[  13]Med vänlig hälsning
[  14]Formulär:
[  33]Säkerhetskod är nödvändig.
[  34]säkerhetskoden är felaktig.
