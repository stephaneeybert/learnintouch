[   0]Send an email on automatic backup:
[   1]When a backup of the website is being done automatically, it is possible to send an email to the website email address.\n\nThe email contains a link to the page offering the backup file for download.\n\nThis reminds the website administrator that a backup has just been done.
[   2]Never
[   3]Weekly
[   4]Monthly
[   5]Always
