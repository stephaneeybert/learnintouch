[   0]Skicka tiding
[   1]Titel:
[   3]Lanseringsdatum:
[   4]Avsändarnamn:
[   5]Avsändaremail:
[   6]Mottagarnamn:
[   7]Mottagaremail:
[   8]Klicka på tidningens titel för att läsa. 
[  10]Mottagarens emailadress är nödvändig.
[  12]Avsändarens emailadress är nödvändig.
[  13]Detta mejl har skickats av 
[  14]Du kan signera tidningsutskicket
[  15]Du kan skriva in din e-postadress för att lämna din kontakt till tidningens mottagare.
[  16]Du kan skriva in namnet på tidningens mottagare.
[  17]Skriv in mottagarens emailadress
[  18]Med vänlig hälsning
[  19]En tidning har skickats till dig från 
[  20]Kära
[  23]Meddelande:
[  24]Du kan skriva ett meddelande.
[  38]Formatet på mottagarens emailadress är felaktig
[  39]Formatet på avsändarens emailadress är felaktig
[  44]Formatet på mottagarens emailadress har en felaktig symbol
[  45]Formatet på avsändarens emailadress har en felaktig symbol
