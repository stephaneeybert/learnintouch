[   0]Radera en redaktör
[   1]Förnamn:
[   6]Efternamn:
[   3]Email:
[   2]Radera redaktören?
[   5]Redaktören är länkad till vissa nyheter.nRadera dess nyheter för att kunna radera redaktören.
