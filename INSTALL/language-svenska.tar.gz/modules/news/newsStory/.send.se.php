[   0]Skicka nyhet
[   1]Rubrik:
[   2]Utdrag:
[   3]Lanseringsdatum:
[   4]Avsändanamn:
[   5]Avsändaremial:
[   6]Mottagarnamn:
[   7]Mottagaremail:
[   8]Klicka på tidningens titel för att läsa. 
[  10]Mottagarens emailadress är nödvändig.
[  12]Avsändarens emailadress är nödvändig.
[  13]Detta mejl har skickats av 
[  14]Du kan 
[  15]Du kan skriva in din e-postadress för att lämna din kontakt till mottagaren.
[  16]Du kan skriva in namnet på tidningens mottagare.
[  17]Skriv in mottagarens emailadress
[  18]Med vänlig hälsning
[  19]En tidning har skickats till dig från 
[  20]Kära
[  23]Meddelande:
[  24]Du kan skriva ett meddelande.
[  38]Mottagarens emailadress är felaktig
[  39]Avsändarens emailadress är felaktig
[  44]Mottagarens emailadess har en ogiltig symbol
[  45]Avsändarens emailadess har en ogiltig symbol
