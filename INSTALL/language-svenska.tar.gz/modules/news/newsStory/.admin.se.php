[   0]Nyheter
[   1]Skapa en nyhet
[   2]Redigera en artikel
[   3]Radera artikeln
[   4]Infoga eller radera en bild eller en multimedia-fil
[   5]Nyhetsblad:
[   6]Sidhuvud:
[   7]Redaktör:
[   8]Nyheter
[   9]Preferenser
[  10]Nyhetsbladen erbjuder publicerandet av nyheter.\n\nEtt nyhetsblad består av ett antal nyheter.\n\nNyheterna sorteras efter överskrift.\n\nVarje nyhet kan signeras av en redaktör.\n\nListan med nyheter kan filtreras genom att välja ett nyhetsbrev och/eller en överskrift och/eller en redaktör.
[  11]Infoga eller radera en ljud- eller multiedia-fil
[  12]Byt med nästa
[  13]Byt med föregående
[  14]Överskrifter
[  15]Nyhetsbladen
[  16]Redaktörerna
[  17]Preview the news story
[  18]Preview the newspaper
