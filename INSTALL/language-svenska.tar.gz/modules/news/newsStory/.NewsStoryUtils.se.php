[   1]Profil
[   2]Tillbaka
[   3]Skriv ut nyhet
[   4]Skicka nyhet
[   5]Felfungerande mediaspelare:
[   6]Det finns ett flertal mediaspelare på marknaden.\n\nVarje mediaspelare kan endast spela en viss typ av mediafiler.\n\nOm en mediaspelare är angedd kommer alla mediafiler spelas genom den mediaspelaren.\n\nOm ingen mediaspelare är angedd kommer den gissas utifrån varje mediafil.\n\nOm mediaspelaren inte kan spela mediafil kommer inget ljud höras och användaren kommer inte kunna lyssna på mediafilen.\n\nAnge en mediaspelare endast för att tvinga en särskild mediaspelare att användas.
[   7]Lyssna på nyheten
[   8]Click to see other pictures
[   9]Width of the news story images (phone):
[  10]The width for the images of a news story when they are displayed in a medium format on a phone or small screen mobile device.
[  11]Visa RSS-loggon:
[  12]Visa redaktörens mailaddress:
[  13]Visa redaktörens profil
[  14]Visa publiceringsdatumet i the news feed:
[  15]Dölj överskrifterna:
[  16]Antal nyheter i nyhets the news feed:
[  17]Starta ljudspelaren automatiskt:
[  18]Dölj publiceringsdatumet:
[  19]Antal kolumner:
[  20]Ljudspelaren kan startas automatiskt efter att sidan visats.\n\nEller kan den starta endast om besökaren trycker på 'Play'-knappen.
[  21]Ett nyhetsblads nyheter kan visas en eller flera kolumner.
[  22]Vid fel visas en nyhets publiceringsdatum under varje nyhets rubrik.\n\nMan detta datum kan döljas.
[  23]Vid fel visas nyheternas överskrifter i nyhetsbladen.\n\nMen dessa överskrifter kan döljas.\n\nNotera att om nyheterna i ett nyhetsblad visas i mer än en kolumn visas inte överskrifterna.
[  24]Vid fel visas ej redaktörens profil längst ned på nyheten.\n\nMan denna profil kan visas.
[  25]Vid fel visas ej redaktörens mailaddress.\n\nMen denna mailaddress kan visas för att låta läsarna kontakta redaktören.
[  26]I ett news feed, vid fel, visas ej en nyhets publiceringsdatum under varje nyhets rubrik.\n\nMen detta datum kan visas.
[  27]I ett news feed, vid fel, visas inte RSS-loggan.\n\nMen RSS-loggan kan visas.
[  28]Antal nyheter i ett news feed kan vara begränsat.
[  29]Width of the newspaper images:
[  30]Width of the news story small images:
[  31]The width for the images of a news story when they are displayed in a small format.
[  32]Width of the news story medium images:
[  33]The width for the images of a news story when they are displayed in a medium format.
[  34]Width of the news story large images:
[  35]The width for the images of a news story when they are displayed in a large format.
[  36]The width for the images of a newspaper.
[  37]Width of the newspaper images (phone):
[  38]The width for the images of a newspaper when they are displayed on a phone or small screen mobile device.
[  39]By
[  40]Display the media player in a popup window:
[  41]By default, the media player is displayed in the main browser window.\n\nBut it can instead be displayed in a popup window.
[  42]Display a preview of the images:
[  43]A series of images can be displayed for each news story.\n\nBy default, the images of a news story are displayed in a popup window.\n\nBut these images can also be displayed alongside the news story.\n\nThe images are then displayed in a small format as a preview of the larger images.
[  44]Click to view the picture
[  45]Group the paragraphs:
[  46]A news story can be composed of several paragraphs.\n\nBy default, the paragraphs are displayed one per page.\n\nBut it is possible to group all the paragraphs of a news story and display them together on one page.
[  47]Previous paragraph
[  48]Next paragraph
[  49]Hide the editor in the newspapers:
[  50]By default, the editor is displayed in the newspapers.\n\nBut the editor can be hidden.
[  51]Hide the editor in the news stories:
[  52]By default, the editor is displayed in the news stories.\n\nBut the editor can be hidden.
[  53]Display the first image:
[  54]By default, the news stories images are not displayed in newspaper.\n\nBut it is possible to display in the newspaper the first image of each news story.
[  55]CLick to read the news story
[  56]Display the newspaper links:
[  57]When displaying a newspaper, it is possible to display links to the other newspapers.\n\nThe links are displayed at the bottom of the newspaper content.
[  58]Hide the player in the newspaper:
[  59]When displaying a newspaper, by default an audio player is displayed for each news story that has an audio file.\n\nIt is possible to hide the audio player in the newspaper.\n\nNote that the audio player is also displayed when displaying just one news story.
[  60]Hide the player in the news story:
[  61]When displaying a news story, by default an audio player is displayed if the news story has an audio file.\n\nIt is possible to hide the audio player in the news story.\n\nNote that the audio player is also displayed when displaying the newspaper.
