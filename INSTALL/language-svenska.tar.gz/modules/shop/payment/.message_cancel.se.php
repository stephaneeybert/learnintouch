[   0]Klicka här för att se din order.
[   1]Köpet har INTE gått igenom\n\nDin beställning kontrolleras.
