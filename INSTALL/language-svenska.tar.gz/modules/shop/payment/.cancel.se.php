[   0]Betalningen har inte gått igenom eller avbrutits.\n\nDin beställning har inte accepterats. 
