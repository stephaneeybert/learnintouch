[   0]Transaktionen har gått igenom. \n\nDin beställning har gått igenom!
[   1]En ny beställning från
[   2]En beställning har betalats av
[   3]Du kan
[   4]visa ordning
[   5]har tagit emot din beställning!
[   6]Kära
[   7]Vi har tagit emot din beställning med denna referens
[   8]logga in på ditt konto 
[   9]Tack för ditt köp
[  10]Med vänlig hälsning
[  11]När du är inloggad kan du
[  12]Du kan se din beställning med denna emailadress och lösenord
[  13]Email:
[  14]Lösenord:
[  15]Se din beställning
[  16]byta lösenord
[  17]Beställningsreferensen:
[  18]Din beställning visas om några sekunder..
[  19]Betalningen har inte gått igenom.\n\nDin beställning väntar fortfarande på godkännande.
[  20]har betalats av 
[  21]Kunden kan kontaktas genom
