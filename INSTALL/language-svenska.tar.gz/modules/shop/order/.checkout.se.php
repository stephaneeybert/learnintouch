[   0]Din beställning
[   1]Förnamn: *
[   2]Efternamn: *
[   3]Email: *
[   4]Organisation:
[   5]Telefon:
[   6]Mobiltelefon:
[   7]Meddelande:
[   8]Skriv in beställningsinformationen.\n\nDe obligatoriska rutorna är markerade med *
[   9]V.g. skriv in ditt efternamn
[  10]V.g. skriv in en emailadress.
[  11]Formatet på emailadressen är inte giltig
[  12]V.g. skriv in ditt förnamn
[  13]Ett kontaktmeddelande har skickats till
[  14]Klicka här 
[  15]Vi har tagit emot ditt meddelande\n\nVår kundservice kontaktar dig snart
[  16]kontaktmeddelande från
[  17]för att läsa meddelandet.
[  18]Emailadressen har en ogiltig symbol
[  19]av
[  20]Meddelande :
[  21]till
[  22]Skriv in din säkerhetskod
[  23]Säkerhetskod: *
[  24]Skriv in säkerhetskoden som visas.\n\nSäkerhetskoden behövs för att kunna försäkra om att personen som skrivit meddelandet inte är en robot.\n\nEn robot kan inte se nummer i bilder, bara en person får skriva och posta meddelanden.
[  25]Skicka beställningen
[  26]Postbox:
[  27]Din varukorg är tom.
[  29]Om adressen för fakturan och mottagaren inte är samma, skriv då in mottagaradressen. Annars används faktureringsadressen. 
[  30]Adress:
[  32]Postkod:
[  33]Stad:
[  34]Kommun:
[  35]Land:
[  36]Faktureringsadress
[  37]Mottagaradress
[  38]Adressen behövs
[  39]Postkoden behövs.
[  41]Stad behövs.
[  42]Land behövs.
[  43]Du kan också lämna ett meddelande angående din beställning.
[  44]Säkerhetskoden behövs.
[  45]Säkerhetskoden stämmer inte
[  46]Klicka i rutan om mottagareadressen inte är samma som faktureringsadressen.
[  47]Fax:
[  48]Se din varukorg
