[   0]Orderbekräftelse
[   1]Förnamn:
[   2]Eftername:
[   3]Email:
[   4]Organisation:
[   5]Telefonummer:
[   6]Mobilnummer:
[   7]Meddelande:
[   8]Fortsätt till onlinebetalning med bankkort
[   9]Ref:
[  10]Avbryt beställning
[  11]Bekräfta beställning och fortsätt till betlaning
[  12]Present paketering
[  13]Din beställning är avbruten\n\nDu blir omdirigerad om några sekunder .. 
[  14]Vi kan inte ta emot beställningar i detta ögonblick. 
[  15]Fortsätt till försenad betalning med banköverföring
[  16]Av administrativa skäl kan vi inte ta emot beställningar för tillfället.
[  17]Postlåda:
[  18]E-postadressen har en ogiltigt symbol.
[  19]Mottagare
[  20]Kundkorgen är tom
[  21]Beställda varor
[  22]Fortsätt
[  23]Rabatt:
[  30]Adress:
[  32]Postkod:
[  33]Stad:
[  34]Kommun:
[  35]Land:
[  36]Fakturadress
[  37]Leveransadress
[  47]Fax:
[ 110]Fraktkostnader:
[ 111]Summa att betala:
[ 112]Summan för föremål:
[ 113]Totalt:
