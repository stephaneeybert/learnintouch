[   4]Lämna ett inlägg i gästboken
[   0]Användarnamnet för det här gästboksinlägget saknas.
[   1]Meddelandet har infogats.
[   2]Du måste logga in för att kunna lämna ett inlägg i gästboken.
[   5]Inläggets text är begärt.
[   6]Inlägg:
[   3]Email:
[  10]Förnamn:
[  11]Efternamn:
[   7]Textmeddelandet är begärt.
[   8]Ett namn eller en email är begärt.
[   9]Emailadressens format är ogiltigt.
[  12]Emailadressen har ett ogiltigt suffix.
