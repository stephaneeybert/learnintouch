[   0]Användarnamnet för det här gästboksinlägget saknas.
[   1]Meddelandet har infogats.
[   2]Du måste logga in för att kunna lämna ett inlägg i gästboken.
[   3]Email:
[   4]Lämna ett inlägg i gästboken
[   5]Inläggets text är begärt.
[   6]Inlägg:
[   7]Textmeddelandet är begärt.
[   8]Ett namn eller en email är begärt.
[   9]Emailadressens format är ogiltigt.
[  10]Förnamn:
[  11]Efternamn:
[  12]Emailadressen har ett ogiltigt symbol.
[  13]Förnamn:
[  14]Klicka här
[  15]Ett meddelande lagts till i gästboken
[  16]Ett nytt meddelande i gästboken
[  17]för att läsa meddelandet.
[  18]Skriv in säkerhetskoden som visas\n\nEn säkerhetskod krävs för att säkerställa att meddelandet läggs ut i gästboken av en person och inte av ett program.\n\nEftersom ett program inte kan läsa ett nummer som visas i en grafisk form kan bara en riktig person skicka ett kontaktmeddelande.
[  19]av
[  20]Meddelande :
[  21]från
[  22]Skriv in denna säkerhetskod
[  23]Skicka
[  33]Säkerhetskod är nödvändig.
[  34]Säkerhetskoden är felaktig
