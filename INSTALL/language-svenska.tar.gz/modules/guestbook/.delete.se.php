[   0]Radera ett inlägg från gästboken
[   1]Av:
[   2]Radera inlägget från gästboken?
[   3]Inlägg:
[   4]Datum:
