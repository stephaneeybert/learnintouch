[   0]Gästboksinlägg
[   1]Skickat av
[   6]på
[   2]Radera inlägget
[   3]Radera alla inlägg i gästboken
[   5]Preferenser
[   4]Gästboken är en samling av alla inlägg som är skrivna av de användare som besökt webbplatsen. Endast användarna kan skriva i gästboken. För att skriva ett inlägg i gästboken måste användaren först vara inloggad på webbplatsen. Gästboksinläggen kan endast raderas av administratörerna.
