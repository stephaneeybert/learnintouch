[   0]Tömma gästboken
[   2]Radera alla inlägg i gästboken?
