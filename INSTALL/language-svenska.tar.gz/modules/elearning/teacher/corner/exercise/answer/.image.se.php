[   0]Ladda upp ett foto
[    ]
[   1]Ett svar kan ha en bild.
[   2]Välj en bild:
[   3]Bildnamn:
[   4]Bekräfta åtgärd
[   6]Bild:
[   7]Ta bort bilden?
[   8]Ändra storlek på bredden:
[   9]När bilden laddas upp till servern kan den ändras till den angivna bredden.\n\nOm ingen bredd anges ändras inte storleken på bilden.\n\nStandardbredden tas från den större bildbredden i inställningarna.
[  11]Du har inte åtkomst till denna övning.
[  27]Ingen bild har valts.
