[   0]Ladda upp en ljudfil
[   1]Svaret kan vara en ljudfil.\n\nLjudfilen spelas genom att klicka på ljudfilsspelaren.\n\nEn ljudfil är en fil som kan streamas via Internet för att sända ljudinnehåll.
[   2]Kb.
[   3]Filnamn:
[   4]Bekräfta åtgärd
[   5]Välj fil:
[   6]Ljudfil:
[   7]Raddera ljudfil?
[   8]Avbryt kommando
[  11]Du har ingen åtkomst till denna övning.
[  27]Ingen ljudfil har valts.
