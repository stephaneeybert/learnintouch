[   0]Radera svar
[   1]Svar:
[   2]Ta bort svaret?
[   3]Detta svar har redan använts och har fått resultat.\n\nOm du raderar svaret raderas också det detaljerade resultat av svaret.\n\nResultaten av de andra svaren kommer inte att raderas, och träningsgraderna och poängen kommer att finnas kvar.
[  10]Avbryt kommando
[  11]Du kan inte radera detta svar.
