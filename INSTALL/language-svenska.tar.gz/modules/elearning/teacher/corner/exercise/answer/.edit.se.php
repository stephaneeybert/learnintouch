[   0]Redigera ett svar
[   2]Fråga:
[   4]Svar:
[   9]Du har ingen åtkomst till denna övning
[  10]Förklaring av fel:
[  11]Förklaringen kan vara specifik till varje svar. \n\nOm en förklaring ges som svar, överskrider den svaret som getts för frågan.\n\nEn förklaring till frågan kan visas under varje frågas resultat.\n\nDet kan ge deltagaren ytterligare information om frågans lösning och hjälpa hen att förstå sitt eventuella misstag.\n\nEtt exempel på en sådan förklaring kan lyda:\n\nKonduktör är en falsk vän. Även fast man kan tro att rätt svar är "le conducteur", så är det rätta svaret faktiskt "le contrôleur". \n\nFör att ta med deltagarens svar i förklaringstexten, använd sekvensen av tre frågetecken '???'.\n\nFörklaringen ser då ut såhär;\n\nKonduktör är en falsk vän. Även fast man kan tro att rätt svar är "???", så är det rätta svaret faktiskt "le contrôleur". 
[  15]Spara förklaringen
[  21]Bekräfta kommando
[  22]Avbryt kommando
