[   0]Radera en fråga
[   1]Fråga:
[   2]Radera frågan?
[   3]Frågan har redan använts och har fått ett resultat. \n\nRadera frågan raderar även det detaljerade resultatet.\n\nMen resultaten från de övriga frågorna kommer inte att raderas, och träningsgraderna och poängen kommer att sparas.
[  10]Avbryt kommando
[  11]Du har ingen åtkomst till denna fråga.
