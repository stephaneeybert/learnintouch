[   0]Kopiera en fråga
[   1]Fråga:
[   5]Poäng:
[   7]Kopiera frågan?
[  10]Avbryt kommando
[  11]Du har ingen åtkomst till denna övning.
