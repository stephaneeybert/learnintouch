[   0]Redigera en fråga
[   1]Poängantal måste vara 1 eller högre.
[   2]Sida med frågor:
[   3]Poäng:
[   4]Fråga:
[   5]Som standard ger varje rätt svar 1 poäng.\n\nDet är möjligt att ändra antal poäng för olika frågor.\n\nOm inget annat är angett, så ges 1 poäng.
[   6]Frågorna är grupperade på sidorna med frågor.\n\nVarje fråga består av en mening och eventuellt en bild, Flash-animering eller ljudfil.\n\nFrågorna kan visas i vald ordning.\n\nDet finns två olika sorters frågor.\n1- Flera vals-frågor\n2- Skriv svar-frågor\n\nOm en fråga har mer än ett möjligt svar är det en fler vals-fråga. Annars har det bara ett möjligt svar och då är det en skriv svar-fråga.\n\nFör att placera svaret inom frågan, och inte efter, sätt in en platsmarkör inom frågan.\n\nPlaceringsmarkören är sekvensen av tre frågetecken '???'.\n\nTill exempel kan en fråga skrivas som "Det är ??? bra'.\n\nObservera att platsmarkören inte krävs om svaret ligger efter frågan.\n\nFrågan 'Bilen är ???' behöver bara skrivas som 'Bilen är'\n\nFör skriv svar-frågor kan längden på typfältet anges med sekvensen av tre frågetecken.\n\nTill exempel skulle ett 10 tecken långt fält anges som ???10. Frågan skrivs som "bilen är ???10 i gatan".\n\nOm en fråga ska visas inom texten och inte nedan, visas bara svarsfältet i texten, och själva frågan kommer inte att visas.
[   7]En fråga är alltid en del av en sida med frågor.\n\nDet finns vanligtvis flera frågor per sida.\n
[   8]Tips:
[   9]En ledtråd kan visas med frågan för att hjälpa deltagaren att hitta lösningen på frågan.\n\nTipset kan vara att böja ett verb, en synonym, en kort mening, etc ...
[  10]Förklaring:
[  11]En förklaring till frågan kan visas under varje frågas resultat.\n\nDet kan ge deltagaren ytterligare information om frågans lösning och hjälpa hen förstå sitt möjliga misstag.\n\nEtt exempel på ett sådant förslag kan lyda:\n\nKonduktör är en falsk vän. Även fast man kan tro att rätt svar är "le conducteur", så är det rätta svaret faktiskt "le contrôleur". \n\nFör att ta med deltagarens svar i förklaringstexten, använd sekvensen av tre frågetecken '???'.\n\nExemplet ser då ut såhär;\n\nKonduktör är en falsk vän. Även fast man kan tro att rätt svar är "???", så är det rätta svaret faktiskt "le contrôleur". 
[  12]Skapa två svar (Sant/Falskt):
[  13]Det är möjligt att skapa två svar som heter "Sant" och "Falskt" samt  ange vilken av de två som är lösningen.\n\nDetta gör det möjligt att snabbt skapa Sant/Falskt frågor.
[  14]Lösning:
[  15]Spara förklaringen
[  16]Sant
[  17]Falskt
[  18]Antalet ord, för ett skrivet textsvar, måste vara större eller lika med 1.
[  19]Antal ord:
[  20]Om frågetypen är en text att skriva in, är det möjligt att ange hur många ord texten ska innehålla.\n\nDetta ger deltagaren en uppfattning om storleken på den text som ska skrivas in.\n\nDetta används bara om frågan är en text som ska skrivas in.
[  21]Bekräfta kommando
[  22]Avbryt kommando
[  23]Du har ingen behörighet för denna uppgift
