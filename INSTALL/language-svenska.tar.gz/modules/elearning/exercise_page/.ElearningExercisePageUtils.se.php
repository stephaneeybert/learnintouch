[   0]Sida
[   1]sidor kvar
[   2]Framfart:
[   3]Klicka för att ta bort släpt svar
[   4]i övningen
[   5]En tips som hjälper dig
[   6]Dina svar är alla rätt!
[   7]Dina svar är alla felaktiga.
[   8]Dina svar är delvis korrekt.
[   9]Lösning:
