[   0]Sök en uppgift
[   3]Gå till uppgift
[   5]Kurs
[   6]För session
[  10]Skriv ut reslutat
[  12]Se videon
[  13]Klicka för att se videon
[  14]Uppgift:
[  80]Sicka uppgift
[  91]Gör uppgift
[ 112]Skriv ut uppgift
[ 135]Resultat
[ 136]Poäng
[ 145]Ingen prenumeration har hittats
[ 186]Skriv ut grafen av kursresultatet. 
