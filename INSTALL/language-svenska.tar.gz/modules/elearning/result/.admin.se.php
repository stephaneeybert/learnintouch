[   0]The test results
[   1]Grade:
[   2]Delete all the results of the test
[   3]Delete the result
[   4]Name
[   5]Test
[   8]Since:
[   9]Test:
[  15]Next
[  16]Previous
[  17]Questions/Answers
[  43]One week
[  44]One month
[  45]Three months
[  46]Six months
[  47]One year
[  48]Since:
[  70]Search:
[  71]It can become tedious to navigate in the list of results to find a particular result.\n\nTo avoid this, it is possible to type in all or part of the name of a person and do a search based on the typed in text.\n\nThe search result will display all the persons matching the searched text.
