[   0]Test namn:
[   1]Grade:
[   2]Resultatet av din övning på
[   3]Datum:
[   4]Beskrivning:
[   5]En övning från 
[   6]gjorts
[   7]Besökaren
[   8]har gjort testet
[   9]Besökaren kan kontaktas på
[  11]Klicka här
[  14]Övningen hade en löptid av
[  15]Övningen avslutades i
[  16]Besökaren har lämnat ett meddelande:
[  17]Övningsresultat
[  19]Kurs globala betyg
[  20]Kurs betyg
[  21]Poäng(er)
[  22]poäng(er) för
[  23]Klass:
[  24]Deltagaren:
[  25]Gör övningen
[  26]rätta svar av
[  27]frågor
[  28]Kommentar:
[  29]Du har inte svarat
[  30]Du har svarat
[  31]Rätt svar(er) av
