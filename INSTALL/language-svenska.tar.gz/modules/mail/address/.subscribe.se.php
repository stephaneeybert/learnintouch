[   0]Prenumeration
[   1]Du kan lämna en epostadress för att få meddelanden på din email
[   2]Email: *
[   3]Prenumerera
[   4]Förnamn:
[   5]Efternamn:
[   6]Lista:
[   7]Det är möjligt att prenumerera på mer än en email-lista
[   8]En epostadress behövs.
[   9]Epostadressens format är felaktig
[  10]Epostadressen innehåller en felaktig symbol
