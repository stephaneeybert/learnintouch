[   0]Tack!\n\nDin emailadress har registrerats. 
[   1]Förnamn
[   2]Efternamn
[   3]Emailadress
[   4]Listan av mail, emailadresser och email historik i administrations interface kan visa ett valt antal saker per sida.
[   5]Radera gamla email:
[   6]Gamla email kan automatiskt raderas efter en vald tidpunkt.\n\nOm ingen tidpunkt valts kommer de att sparas för evigt. \n\nGenom att radera gamla email kan man spara plats på hårddisken. \n\nDenna tidsperiod är skriven i månader.
[   7]Visa bara admin mail.
[   8]Antal saker per sida:
[   9]Bekräftelse av registrering:
[  10]Signature:
[  11]Visning av signature:
[  12]Visa loggan:
[  13]När en besökare har registrerat sin emailadress visas ett bekräftelsemeddelande.\n\nDetta bekräftelsemeddelande kan ändras.
[  14]Samla emailadresser:
[  15]det är möjligt att samla alla emailadresser som skrivits in under deras besök. \n\nTill exempel, om en besökare skickar en nyhetshistoria i ett email kan mottagarens och avsändarens emailadresser sparas i listan.\n\nDessa emailadresser är då sparade till listan över emailadresser.\n\nVar god notera att emailadresser som inte själva registrerats av deras ägare då sparas i denna lista.\n\nBesökaren vet inte om att deras emailadress sparats och lagts till en lista.
[  16]Som standard visas alla email i en lista.\n\nMen det är möjligt att bara visa emails skrivna av admin.\n\nemail skrivna av andra admin visas inte i listan.
[  17]lösenordet
[  18]Användare auto login:
[  19]När man lägger upp en länk till inloggningssidan är det möjligt att förutbestämma användarnman- och lösenordsfälten, så användaren inte behöver skriva in dem.\n\nGenom att klicka på länken hamnar användaren på inloggningssidan där fälten redan innehåller besökarens användarnamn och lösenord utan att själv behöva skriva in det.
[  21]Nästa uppgift
[  22]Bredden av bilden
[  23]bredden på bilden
[  24]bredden på bilden i telefon:
[  25]Bredden på bilden då den visas i en telefon
[  30]The html editor:
[  31]Det finns flera olika html editors man kan använda för att redigera email.\n\nVar god välj html editor.
[  32]Innova
[  33]CKEditor
[  50]Signaturen är bifogad i mailet.\n\nDetta erbjuder ett enkelt sätt att signera alla email med samma signatur.
[  51]signaturen kan visas i email sidfot.
[  52]Websidans logga kan visas bredvid signaturen.
