[   0]Hänvisare:
[   1]Skicka ett mejl vid mottagandet av meddelande
[   2]Bekräftelse meddelande
[   3]Kommentar meddelande
[   4]Ett skräddarsytt kommentars meddelande kan visas ovanför formuläret
[   5]Registrera en emailadress
[   6]När en besökare skickar ett meddelande måste hen lämna en emailadress.\n\nEmailadressen visas tillsammans med meddelandet.\n\nDet är också möjligt att addera emailadressen till mejllistan under Mejl.\n\nAlla emailadresser som lämnats av besökare registreras i emaillistan och kan användas senare.\n\nPå så sätt kan emaillistan växa tillsammans med införskaffade emailadresser allteftersom besökare skickar meddelanden.
[   7]Radera gamla meddelanden
[   8]Gamla meddelanden kan raderas efter en specifik tidsperiod \n\nDetta för att undvika hämmning i kontaktsystemet med gamla bearbetade meddelanden.\n\nEtt kontaktmeddelande är, oavsett dess status, automatiskt och permanent raderat efter den satta tidsperioden.\n\nTidsperioden bestäms i månader
[   9]Inkludera meddelandet:
[  10]Som standard innehåller inte mejlet som skickas till webbsidans emailadress, besökarens meddelande.\n\nMejlet innehåller bara en länk till meddelandet som hålles i systemet. \n\nDet är möjligt att inkludera i mejlet, besökarens meddelande. \n\nPå detta sätt är det möjligt att omedelbart kunna läsa besökarens meddelande.
[  11]Bekräftelse sida
[  12]När besökaren skickar ett meddelande visas ett bekräftelsemeddelande.\n\nDet är möjligt att visa en bekräftelsesida på webbsidan istället.\n\nI sådana fall visas bekräftelsesidan istället för det standardiserade bekräftelsemeddelandet.\n\nWebbsidan kan därför visa en mer komplicerad bekräftelse istället för ett simpelt bekräftelsemeddelande.\n \nBekräftelsesidan kan därför visa, till exempel, en adress, en karta eller bild.
[  13]Fråga inte efter säkerhetskod
[  14]När en besökare skickar ett kontaktmeddelande frågas hen att skriva in en säkerhetskod.\n\nDå säkerhetskoden visas i en bild kan bara en människa se koden.\n\nDetta säkerhetsåtgärd hindrar automatiska meddelanden från webbrobotar. \n\nDet är inte en bra idé att ta bort denna säkerhetsåtgärd.
[  15]Formulär för emailadress
[  16]Det är möjligt att skicka innehållet av ett formulär till en emailadress. \n\nDen specifierade emailaddressen mottar ett emejl varje gång ett formulär är ifyllt av en besökare.\n\nOm ingen emailadress är specifierad skickas dem istället till webbsidans emailadress.\n\nFör att på rätt sätt kunna ansluta ett formulär till dess inkorg, måste attributet "aktion" ha etiketten "formulär" som motsvarar varandra.
[  17]Som i:
[  18]\ndär det valfria kontaktMottagareMejl och kontaktBekräftleseMejl variabler är den emailadressen som formuläret är skickad till och bekräftlsemeddelandet visas till webbsidans besökare (??)
[  19]Hänvisare kommentar:
[  21]Till
[  22]Kontaktmeddelande från
[  23]Ett kontaktmeddelande har skickats till
[  24]av
[  25]Klicka här
[  26]för att läsa meddelandet.
[  27]Meddelande:
[  28]Nummer av kontaktmeddelande per sida:
[  29]Kontaktmeddelande listan kan i administratorns gränssnitt visa ett valt antal meddelanden per sida.
[  30]Kommentaren som visas över listan av hänvisare kan bestämmas. \n\nDetta tillåter visningen av en mer meningsfull kommentar i kontaktformuläret.
[  31]När ett meddelande skrivits av en besökare kan ett mejl skickas till webbsidans emailadress.\n\nDet här är för att underrätta administratören att ett kontaktmeddelande har tagits emot.
[  32]Efter att en besökare har skickat ett meddelande, skickas ett bekräftelse meddelande till avsändaren.\n\nBekräftelsemeddelandet kan ändras.
[  33]Hur hittade du oss?
