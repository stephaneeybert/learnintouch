[   0]Kontakt meddelande
[   1]Förnamn:
[   2]Efternamn:
[   3]Email:
[   4]Organisation:
[   5]Telephon:
[   6]Ämne:
[   7]Meddelande:
[   8]Skriv in din emailadress och meddleande.\nDe fält markerade med * måste fyllas i
[   9]hänvisare:
[  10]emailadress är nödvändig.
[  11]Emailadressens format är inkorrekt.
[  12]Ett meddelande är nödvändigt.
[  13]Hur fick du veta om oss?
[  14]Skicka
[  15]Vi har tagit emot ditt meddelande.\n\nVår kundtjänst kommer att kontakta dig inom kort.
[  18]Email-adressen har en otillåten symbol.
[  22]Skriv in denna säkerhetskod
[  23]Säkerhetskod: *
[  24]Skriv in den visade säkerhetskoden.\n\nEn säkerhetskod krävs för att säkerställa att kontaktmeddelandet är upplagt av en person och inte av ett program.\n\nEftersom ett program inte kan läsa ett nummer som visas i en grafisk form kan bara en riktig person skicka ett kontaktmeddelande.
[  33]Säkerhetskoden är nödvändig.
[  34]Säkerhetskoden är felaktig.
