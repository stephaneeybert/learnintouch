[   0]Formuläret har mottagits.\n\nTack för din medverkan!
[   1]Ett nytt formulär har skickats till
[   2]En besökare på webbsidan har skickat in ett formulär. 
[   3]Formulärets innehåll lyder följande:
[   4]Med vänlig hälsning
