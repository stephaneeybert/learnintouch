[   0]Bredden av bilderna:
[   1]Bildernas bredd då de visas i listan
[   2]Visa alla länkar:
[   3]Som standard visas bara länkarna från den första kategorin upp om en kategori inte valts av en besökare.\n\nMen det är möjligt att visa alla länkar istället för bara de i första kategorin.
[   4]Bredden av bilderna (telefon)
[   5]Bredden av bilderna då de visas i en telefon eller mindre skärm
[   6]Göm väljaren:
[   7]Som standard visas en kategori väljare över listan med länkar.\n\nMen denna väljare kan gömas för att hindra en annan kategori från att väljas.
[   8]bredden på bilden cykel (mall):
[   9]Bredden på bilden då den visas i en cykel i en mall på hemsidan.\n\nTill exempel, en banner som visas på hemsidans sida.
[  10]Bredden på bilden cykel (sida):
[  11]Bredden på bilden då den visas i en cykel på en sida på hemsidan. \n\nTill exempel, bilder på en sida.
[  12]Hastighet av bildens cykel:
[  13]Hastigheten av bildens cykel skriven i sekunder
