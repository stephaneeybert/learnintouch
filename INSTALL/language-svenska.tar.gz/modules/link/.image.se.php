[   0]Ladda upp en bild
[   6]Bild:
[   3]Bildnamn:
[   2]Välj en bild:
[   7]Radera bilden?
