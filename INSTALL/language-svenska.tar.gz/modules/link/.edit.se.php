[   0]Redigera en länk
[   6]Namn:
[   7]Beskrivning:
[   5]Kategori:
[   8]Url:
[   9]Länkens kategori är begärd.
[   4]Länkens namn är begärd.
[   1]Länkens url är begärd.
[  21]Url ogiltig.
