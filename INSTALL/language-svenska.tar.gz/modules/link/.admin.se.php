[   0]Favoritlänkarna
[   1]Skapa en länk
[   2]Redigera länken
[   3]Radera länken
[   4]Namn
[   5]Beskrivning
[   6]Kategorier
[   7]Infoga en bild
[  12]Bild
[   8]Url
[   9]Kategori:
[  10]Byt med nästa
[  11]Byt med föregående
[  13]Favoritlänkarna är webbaddresserna till dina föredragna webbplatser. Varje länk har ett namn och en webbaddress. En länk kan också ha en bild.  Länkarna är placerade i kategorier.
