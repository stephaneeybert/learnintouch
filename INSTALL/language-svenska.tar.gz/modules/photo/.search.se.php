[   0]Sök
[   5]Referens:
[  13]Text:
[  14]Det är möjligt att söka på ett fotoalbum med ett visst textinnehåll.\n\nI sökresultatet visas fotoalbum vars namn, händelse eller plats innehåller den inskrivna texten.
[  15]Det går att söka efter ett fotoalbum med hjälp av en foto referens.
[  16]Det är möjligt att söka efter fotoalbum som har publicerats under en viss tid.
[  21]Välj...
[  29]Tillbaka till listan med fotoalbum
[  43]En vecka
[  44]En månad
[  45]Tre månader
[  46]Sex månader
[  47]Ett år
[  48]Sedan:
