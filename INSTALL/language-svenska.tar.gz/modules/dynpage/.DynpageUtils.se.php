[    ]
[   0]Hemsida:
[   1]Hemsida under konstruktion:
[   2]Innan publiceringen av webbsidan rådas det att visa ett meddelande på första sidan för att meddela besökare att hemsidan är under konstruktion. \n\nDetta meddelande kan också visas under större underhållsarbeten av hemsidan.
[   3]Hemsidans konstruktions meddelande:
[   4]Detta meddelandet visas på hemsidans första sida för att meddela besökarna att hemsidan är under konstruktion. \n\nStandard meddelandet erbjuden av systemet kan ändras här.
[   5]Denna hemsida är för nuvarande under konstruktion. Var god kom tillbaka senare..
[   6]Meny
[   7]Använd sidonamnet som titel:
[   8]Titeln visas i webbläsarfönstret och används som bokmärke. Som standard är titeln specifierad en gång för hemsidan i refernsmodulen.\n\nDet är också möjligt att använda olika namn för varje fönster\n\nI sådana fall används hemsidans namn som titel.
[   9]Säkerställ tillträde:
[  10]Som standard, alla hemsidans publicerade sidor kan besökas av alla användare och besökare.\n\nDet är möjligt att aktivera säkerhetstillträdet av sidorna på webbsidan.\n\nI sådana fall kan sidorna som är säkrade inte längre nås av besökare.\n\nDe kan endast besökas av inloggade användare. \n\nDetta tillåter åtkomst av vissa eller alla sidorna enbart för inloggade användare.\n\nVar god växla inte besökare, användare och administratörer med varandra.\n\nAnvändare är endast dem som registrerats sig i systemet.
[  11]Säkerhetstillträdet till sidorna är inte aktiverat.\n\nFör att kunna tillämpa säkerhetstillträde måste säkerhetstillträde aktiveras.\n\nSäkerhetstillträdet kan aktiveras i preferenser i webbsidans modul.
[  12]Säkerhetstillträdet är inte aktiverad!
[  13]html redigerare:
[  14]Det finns flera html redigerare som kan användas för att redigera hemsidan. \n\nVar god välj valfri html redigerare. 
[  15]Innova
[  16]CKEditor
[  17]Mallmodell:
[  18]Som standard, webbsidorna visas i den aktiva mallmodellen.\n\nDet är möjligt att specifiera en mallmodell i vilken sidorna alltid visas i. 
[  19]Mallmodell (telefon):
[  20]Som standard, visas sidorna i den aktiva mallmodellen när de visas i en telefon eller på en mindre skärm. \n\nDet är möjligt att välja en mallmodell i vilken sidorna alltid visas i.
[  21]Bildbredd:
[  22]Bredden av en bild.
[  23]Bildbredd i telefon:
[  24]Bildbredden i en telefon eller på en mindre skärm.
