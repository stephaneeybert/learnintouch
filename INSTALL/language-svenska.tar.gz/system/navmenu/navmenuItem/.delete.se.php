[   0]Ta bort objekt
[   1]Namn
[   5]Beskrivning
[   2]Ta bort detta objekt
