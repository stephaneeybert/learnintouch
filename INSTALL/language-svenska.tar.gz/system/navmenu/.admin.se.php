[   0]Navigeringsmeny
[   1]Lägg till språk till menyn
[   2]Ändra meny
[   3]Ta bort språket från menyn
[   4]Språk
[   5]Språk
[   6]Beskrivning
[   7]Navigeringsmenyn erbjuder besökare att navigera runt på webben.\n\nEn navigeringsmeny är uppbyggd av flera objekt, varje objekt pekar till en webbsida eller till en webb.\n\nVarje del är representerat av text eller bild.
[   8]Lägg till eller ta bort bild
[   9]Välj språk
[  10]Objekt
[  11]Url
[  12]Lägg till objekt
[  13]For all languages
[  14]Stäng fönster
[  15]för språket
[  16]Lägg till separator
[  17]Language:
[  18]Lägg till objekt
[  19]Insert or delete a second image
[  20]Use a Flash navigation menu
[  22]Ändra objekt
[  23]Ta bort objekt
[  30]Byt med nästa
[  31]Byt med föregående
