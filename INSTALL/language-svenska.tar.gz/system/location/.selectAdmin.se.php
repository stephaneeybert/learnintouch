[   0]Välj en destination
[   6]Land:
[   3]Län:
[   4]Kommun
[   5]Postort
[   1]Välj land,län och kommun och slutligen postort.
