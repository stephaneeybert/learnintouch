[   0]Bjud in dina vänner
[   2]Notera att dina vänners e-postadress inte kommer att sparas.
[   3]E-postadress: *
[   4]Lösenord: *
[   5]Visa kontakter
[   6]Din väns uppgifter kunde inte hämtas. Var god kontrollera att uppgifterna stämmer, eller försök igen senare.
[   7]Din väns uppgifter kunde inte hämtas. Var god försök igen senare.
[   8]Service: *
[   9]E-postadress krävs.
[  10]Meddelande krävs.
[  11]Du kan bjuda in dina vänner till hemsidan genom att skicka ett meddelande.
[  12]Lösenord krävs.
[  13]markera/avmarkera alla kontakter
[  14]Skicka meddelandet
[  15]Minst en kontakt måste markeras.
[  16]Inbjudan har skickats till följande valda e-postadresser:
[  17]Meddelande: *
[  18]Ämne:
[  19]Välj högst
[  20]kontakter.
