[   0]Epostadressen eller lösenordet är inte korrekt.
[   1]Ingen kontakt kunde hämtas
