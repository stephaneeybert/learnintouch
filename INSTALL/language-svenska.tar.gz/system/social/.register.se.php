[   0]Andvändar registration
[   1]Skriv in din email för att fullborda din registrering
[   2]E-postadress: *
[   3]Jag skulle vilja få era mejl
[   4]epostadress krävs
[   5]Formatet av epostadress är inte giltigt
[   6]Register...
[   7]Förnamn krävs
[   8]Efternamn krävs
[   9]Förnamn: *
[  10]Efternamn: *
[  11]Du loggas in med ditt facebook-konto.
[  12]Du loggas in med ditt Linked-in-konto.
[  13]Du loggas in med ditt Google-konto.
[  14]Du loggas in med ditt Twitter-konto.
