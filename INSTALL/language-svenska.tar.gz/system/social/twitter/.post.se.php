[   4]Posta ett meddelande på Twitter
[   6]Meddelande:
[   7]Meddelande krävs.
[  23]Skicka
