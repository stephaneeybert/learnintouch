[   0]Bildgruppen
[   4]Bildgrupp
[   5]Inställningar
[   3]Skapa den valda bildgruppen
[   2]Välj en bildgrupp
[   1]
