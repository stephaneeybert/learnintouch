[   0]Den valda bildgruppen
[   4]Standard bildgrupp
[   5]Lägg till eller ta bort bild
[   3]Vald bildgrupp
[   2]Ladda upp bild
[   1]Att skapa en egen bildgrupp, ladda upp en bildfil för varje bildgrupp.\n\nOm bildgrupp icke är komplett så används standardbilder som ersättning för de saknade bilderna.
