[   0]Ladda upp bild
[   6]Bild
[   7]Ta bort bild
[  27]Ingen bild vald
[   2]Välj en bild
[   3]Bildnamn
