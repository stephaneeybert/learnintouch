[   0]Webbsidans administrator
[   1]Profil
[   4]Administratorer
[   5]Kundreferenser
[   6]Gästbok
[   7]Användare
[   9]Favorit länkar
[  10]Klicka för hjälp
[  11]Fotoalbum
[  12]Websida backupen
[  16]Nyheter
[  17]Webbsidor
[  18]Språk
[  19]Anställda
[  20]Mejl
[  21]SMS
[  24]Platform för kurser
[  25]Webbsidorna
[  26]Kontaktmeddelande
[  28]Dokument
[  30]Butik
[  33]Mallar
[  34]Flash intro
[  35]Besöksstatistik
[  36]Datum och tid
[  51]Denna sida visar huvudmenyn för administratorns verktyg\n\nHemsidan är uppbyggd av flera moduler. \n\nVarje modul på hemsidan är representerad av en ikon
[ 102]Administratorn är personen som uppdaterar och skapar webbsidan. \n\nHemsidan är uppbyggd av moduler. \n\nAdministratorn kan bara ändra en modul om hen har tillåtelse
[ 103]Användarna är de som kan logga in på hemsidan\n\nDe har registrerat sig själva eller blivit tillagda av en administrator. \n\nDe kan logga in på hemsidan med ett användarnamn och lösenord. \n\nNär hen är inloggad kan hen se skyddat innehåll. 
[ 105]Webbsidorna som är skapade med en html redigerare visas i mallarna. \n\nEn webbsida kan bestå av text och bilder. \n\nWebbsidans sidor kan lagras i olika kataloger. 
[ 107]Hemsidans innehåll kan visas på olika språk\n\nEn inloggad användare kan välja vilket språk hen vill se hemsidan på.\n\nEtt språk kan avaktiveras om det inte används.
[ 108]Hemsidans profil består av beskrivande information för att identifiera hemsidans innehåll.\n\nSamma information används också för att identifiera hemsidan då användare kommunicerar på hemsidan. 
[ 109]Anställda är de personer som jobbar på ditt företag\n\nDina anställda behöver inte vara administratörer på din webbsida. \n\nDe kan vara vilka du vill, partners, sponsorer, vänner..\n\nDe har alla varsin profil och kan ha ett foto. 
[ 110]Gästboken är listan på meddelanden skrivna av användarna som besöker hemsidan.\n\nBara inloggade användare kan använda gästboken.\n\nFör att kunna skriva i gästboken måste användaren vara inloggad.
[ 111]Favoritlänkarna är webbadresserna till dina favorit hemsidor.\n\nVarje länk har ett namn och en webbadress.\n\nEn länk kan också ha en bild.
[ 112]Kundreferenser är namnen på hemsidorna skapade av dina klienter som du kan visa på din hemsida som en reference av din service eller aktivitet. \n\nEn kundreferens kan också ha en bild. 
[ 113]Kursplattformen används för att skapa kurser, lektioner och uppgifter.\n\nDen tillåter deltagare att se över sina lektioner och göra uppgifter.\n\nDeras resultat registreras automatiskt. \n\nDet förenklar kommunikationen mellan deltagare och deras lärare.
[ 114]Massmejlingsystemet kan skicka mejl till en eller flera användare på hemsidan.\n\nEtt mejl kan skickas till en lista av användare eller alla användare. \n\nMejlet kan innehålla information specifikt till varje användare, såsom namn, emailadress etc..
[ 115]Fotoalbumet tillåter visning av bilder. \n\nBilderna är lagrade i album och kan visas som bildspel.
[ 116]Tidningen tilllåter publicering av nyheter.\n\nEn tidning är uppbyggd av serier av nyheter uppvisade med rubriker.\n\nPubliceringen av nyheter kan schemaläggas.
[ 118]En komplett backup av hemsidan kan skapas och nedladdas.\n\nDetta möjliggör en säker omhändertagande av hemsidan.\n\nEn automatisk backup av hela hemsidans data är gjord daligen. 
[ 119]Dokument är filer av olika typer som är lagrade i webbsidan och kan laddas ner.\n\nNär dokumentet har lagrats på hemsidan skapas en länk för att få tillgång. \n\nAnvändarna kan ladda ned dokumentet genom att klicka på länken.
[ 120]Hemsidorna som använder detta innehålls lednings system
[ 121]Övervakning av hemsida
[ 123]Kontaktmeddelanden är meddelanden mottagna av användarna på din hemsida.\n\nDessa meddelanden är oftast första kontakt\n\nDet är att föredra att användarna använder denna form för att kontakta dig istället för att publicera din emailadress på hemsidan.
[ 124]Hemsidan mallar beskriver det generella innehållet och layout på din hemsida.\n\nMallarna består av navigations element, såsom knappar, menyer och verktygsfält.\n\nMallarna kan vara på olika språk.\n\nHemsidan kan använda flera mallar aktiverade av användarnavigation.
[ 125]Hemsidan kan ha en Flash introduktion.\n\nFlash introduktionen visas innan hemsidans sidor.\n\nFlash introduktionen kan också visas i ett pop upp fönster.
[ 126]Hemsidans statistik håller räkningen på hur många som användare och besök på hemsidan.\n\nEn användare kan besöka hemsidan flera gånger.\n\nStatistik kan visa vilken sida på hemsidan som besökts mest.\n\nDet kan också visa var besökarna kommer ifrån och på så sätt bättre bestämma vilka sponsorer, reklam etc som ska användas.
[ 127]Webbsidans tid och datum kan visas i olika format\n\nValt format av datum visas på hemsidans sidor.
[ 133]Butiken tillåter säljning online. \n\nBesökarna kan köpa och betala säkert online
[ 134]SMS systemet kan skicka meddelanden till en eller flera användare.\n\nMeddelande kan skickas till en lista av användare eller till alla användare.\n\nMeddelandet kan innehålla information specifikt till varje användare, såsom namn, emailadress etc..
[ 135]Formulär
[ 136]Anpassade formulär tillåter skapandet av formulär anpassade till speciella behov.\n\nDet är därför möjligt att skapa formulär som begär specifik information av besökare på hemsidan.
